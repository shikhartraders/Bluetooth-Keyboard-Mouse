import android.bluetooth.BluetoothHidDevice

fun main() {
    val methods = BluetoothHidDevice::class.java.methods
    for (m in methods) {
        if (m.name == "registerApp") {
            println(m.parameterTypes.map { it.name })
        }
    }
}
