import android.bluetooth.BluetoothHidDeviceAppQosSettings
fun main() {
    val clazz = BluetoothHidDeviceAppQosSettings::class.java
    for (f in clazz.fields) {
        println("${f.name} = ${f.get(null)}")
    }
}
