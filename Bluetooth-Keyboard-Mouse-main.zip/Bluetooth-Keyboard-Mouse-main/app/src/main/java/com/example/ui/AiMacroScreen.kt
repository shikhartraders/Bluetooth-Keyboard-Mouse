package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiMacroScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel) {
    var prompt by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }
    var isRunning by remember { mutableStateOf(false) }
    var macroActions by remember { mutableStateOf<List<MacroAction>>(emptyList()) }
    var errorText by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("What do you want to automate?") },
                placeholder = { Text("e.g. Open notepad and type hello world") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Button(
                    onClick = {
                        if (prompt.isNotBlank()) {
                            isGenerating = true
                            errorText = null
                            coroutineScope.launch {
                                try {
                                    val actions = generateMacro(prompt)
                                    macroActions = actions
                                } catch (e: Exception) {
                                    errorText = e.message ?: "Failed to generate macro"
                                } finally {
                                    isGenerating = false
                                }
                            }
                        }
                    },
                    enabled = !isGenerating && !isRunning && prompt.isNotBlank()
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text("Generate Macro")
                }

                Button(
                    onClick = {
                        if (macroActions.isNotEmpty()) {
                            isRunning = true
                            coroutineScope.launch(Dispatchers.IO) {
                                try {
                                    for (action in macroActions) {
                                        when (action.action) {
                                            "delay" -> delay(action.delayMs ?: 500L)
                                            "keypress" -> {
                                                bluetoothViewModel.sendKeyboardReport(
                                                    action.modifiers?.toByte() ?: 0,
                                                    action.keycode?.toByte() ?: 0
                                                )
                                                delay(50) // Small delay between key presses
                                                bluetoothViewModel.sendKeyboardReport(0, 0) // release
                                                delay(50)
                                            }
                                        }
                                    }
                                } finally {
                                    isRunning = false
                                }
                            }
                        }
                    },
                    enabled = macroActions.isNotEmpty() && !isRunning,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    if (isRunning) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onSecondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Running...")
                    } else {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Run")
                    }
                }
            }

            if (errorText != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(errorText!!, color = MaterialTheme.colorScheme.error)
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            if (macroActions.isNotEmpty()) {
                Text("Generated Actions:", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                    items(macroActions) { action ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            PaddingValues(8.dp)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(action.action.uppercase(), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                if (action.action == "keypress") {
                                    Text(action.text ?: "keycode ${action.keycode}")
                                } else {
                                    Text("${action.delayMs} ms")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class MacroAction(
    val action: String,
    val keycode: Int? = null,
    val modifiers: Int? = null,
    val text: String? = null,
    val delayMs: Long? = null
)

suspend fun generateMacro(prompt: String): List<MacroAction> = withContext(Dispatchers.IO) {
    val apiKey = BuildConfig.GEMINI_API_KEY
    if (apiKey.isBlank()) {
        throw Exception("Gemini API Key is not set in Secrets panel.")
    }
    
    val schemaJson = buildJsonObject {
        put("type", "ARRAY")
        putJsonObject("items") {
            put("type", "OBJECT")
            putJsonObject("properties") {
                putJsonObject("action") {
                    put("type", "STRING")
                    put("description", "The action type: 'keypress' or 'delay'")
                }
                putJsonObject("keycode") {
                    put("type", "INTEGER")
                    put("description", "The HID usage ID (keycode) to press, e.g., 4 for 'A', 40 for 'Enter'.")
                }
                putJsonObject("modifiers") {
                    put("type", "INTEGER")
                    put("description", "The modifier bitmask (Ctrl=1, Shift=2, Alt=4, GUI=8). 0 if none.")
                }
                putJsonObject("text") {
                    put("type", "STRING")
                    put("description", "For debugging or reading, the text or key name.")
                }
                putJsonObject("delayMs") {
                    put("type", "INTEGER")
                    put("description", "The delay in milliseconds if action is 'delay'.")
                }
            }
            putJsonArray("required") {
                add("action")
            }
        }
    }

    val request = GenerateContentRequest(
        contents = listOf(Content(
            parts = listOf(Part(text = prompt))
        )),
        generationConfig = GenerationConfig(
            responseFormat = ResponseFormat(
                text = ResponseFormatText(
                    mimeType = "application/json",
                    schema = schemaJson
                )
            ),
            temperature = 0.2f
        ),
        systemInstruction = Content(
            parts = listOf(Part(text = "You are an expert Bluetooth HID Macro Compiler. Your job is to translate a user's natural language request into a precise sequence of automated keyboard actions. Rules: 1. Break down the user's intent into logical steps. 2. Insert a 'delay' action between actions that require the computer to process something (e.g., waiting 500ms after hitting GUI key, or waiting 1500ms for an app to launch). 3. Modifiers (Ctrl=1, Shift=2, Alt=4, GUI=8) must be applied to the 'keypress' action they belong to, not sent as separate keypresses. 4. Use standard USB HID Keyboard Usage IDs (e.g. 4=a..29=z, 40=Enter, 44=Space). 5. Make sure text is broken down into individual keypresses with appropriate Shift modifier if capitalized."))
        )
    )

    try {
        val response = RetrofitClient.service.generateContent(apiKey, request)
        val textResponseRaw = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: throw Exception("No response text")
        val textResponse = textResponseRaw.replace(Regex("```(json)?"), "").trim()
        
        val jsonArray = Json.parseToJsonElement(textResponse).jsonArray
        val actions = mutableListOf<MacroAction>()
        
        for (element in jsonArray) {
            val obj = element.jsonObject
            val actionType = obj["action"]?.jsonPrimitive?.content ?: "delay"
            val keycode = obj["keycode"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()
            val modifiers = obj["modifiers"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()
            val text = obj["text"]?.jsonPrimitive?.contentOrNull
            val delayMs = obj["delayMs"]?.jsonPrimitive?.contentOrNull?.toLongOrNull()
            
            actions.add(MacroAction(actionType, keycode, modifiers, text, delayMs))
        }
        return@withContext actions
    } catch (e: Exception) {
        throw Exception("Error parsing response: ${e.message}")
    }
}
