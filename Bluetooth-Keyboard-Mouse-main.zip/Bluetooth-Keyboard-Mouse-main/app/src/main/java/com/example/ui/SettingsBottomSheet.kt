package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("Controls", "Mouse", "Keyboard", "Display")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(modifier = Modifier.fillMaxHeight(0.9f)) {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.Transparent
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title) }
                    )
                }
            }

            Box(modifier = Modifier.weight(1f).padding(16.dp)) {
                when (selectedTabIndex) {
                    0 -> ControlsSettingsTab()
                    1 -> MouseSettingsTab()
                    2 -> KeyboardSettingsTab()
                    3 -> DisplaySettingsTab()
                }
            }
        }
    }
}

@Composable
fun ControlsSettingsTab() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        SettingsSwitchRow("Show media control buttons", false)
        SettingsSwitchRow("Show shortcuts", true)
        SettingsSwitchRow("Show Android navigation buttons", true)
    }
}

@Composable
fun MouseSettingsTab() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Air mouse", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        SettingsSwitchRow("Use Air Mouse", false)
        SettingsSliderRow("Air mouse sensitivity")
        
        Spacer(Modifier.height(16.dp))
        Text("Touch pad", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        SettingsSwitchRow("Touch pad mouse clicks", true)
        SettingsItemRow("Display mouse buttons", "Bottom")
        SettingsItemRow("Mouse buttons", "Left, Right")
        SettingsSliderRow("Pointer speed")
        SettingsItemRow("Scroll bar", "Default")
    }
}

@Composable
fun KeyboardSettingsTab() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        SettingsItemRow("Keyboard language", "English US")
        SettingsItemRow("Show text input bar", "When keyboard is active")
        SettingsItemRow("Volume up button", "Volume up")
        SettingsItemRow("Volume down button", "Volume down")
    }
}

@Composable
fun DisplaySettingsTab() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        SettingsItemRow("Theme color", "Default")
        SettingsItemRow("Design", "Light")
        SettingsSwitchRow("Tron style", false)
        SettingsSwitchRow("Start in full screen mode", false)
        SettingsSwitchRow("Keep screen on", false)
        SettingsSwitchRow("Show app over lock screen", true)
        SettingsSwitchRow("Touch vibrations", true)
    }
}

@Composable
fun SettingsSwitchRow(title: String, initialChecked: Boolean) {
    var checked by remember { mutableStateOf(initialChecked) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = { checked = it })
    }
}

@Composable
fun SettingsItemRow(title: String, subtitle: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
    }
}

@Composable
fun SettingsSliderRow(title: String) {
    var value by remember { mutableStateOf(0.5f) }
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Slider(value = value, onValueChange = { value = it })
    }
}
