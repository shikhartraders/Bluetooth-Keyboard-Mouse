package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun MultimediaScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top media controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MediaControlButton(icon = Icons.Default.VolumeDown, modifier = Modifier.weight(1f))
            MediaControlButton(icon = Icons.Default.VolumeMute, modifier = Modifier.weight(1f))
            MediaControlButton(icon = Icons.Default.VolumeUp, modifier = Modifier.weight(1f))
        }
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MediaControlButton(icon = Icons.Default.SkipPrevious, modifier = Modifier.weight(1f))
            MediaControlButton(icon = Icons.Default.SkipNext, modifier = Modifier.weight(1f))
            MediaControlButton(icon = Icons.Default.FastRewind, modifier = Modifier.weight(1f))
            MediaControlButton(icon = Icons.Default.FastForward, modifier = Modifier.weight(1f))
        }

        // Trackpad Area
        TrackpadArea(modifier = Modifier.weight(1f))
        
        // D-Pad
        DPadArea()
        
        // Play/Pause Button
        Button(
            onClick = { /* TODO */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8BC34A))
        ) {
            Text("PLAY/PAUSE", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        
        // Bottom Navigation Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BottomNavButton(text = "BACK", modifier = Modifier.weight(1f))
            BottomNavButton(text = "HOME", modifier = Modifier.weight(1f))
            BottomNavButton(text = "MENU", modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun MediaControlButton(icon: ImageVector, modifier: Modifier = Modifier) {
    Button(
        onClick = { /* TODO */ },
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(0.dp)
    ) {
        Icon(icon, contentDescription = null)
    }
}

@Composable
fun BottomNavButton(text: String, modifier: Modifier = Modifier) {
    Button(
        onClick = { /* TODO */ },
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
    ) {
        Text(text, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun DPadArea() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(
            onClick = { /* TODO */ },
            modifier = Modifier.size(80.dp, 60.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up")
        }
        
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { /* TODO */ },
                modifier = Modifier.size(80.dp, 60.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Left")
            }
            
            Button(
                onClick = { /* TODO */ },
                modifier = Modifier.size(80.dp, 60.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("OK", fontWeight = FontWeight.Bold)
            }
            
            Button(
                onClick = { /* TODO */ },
                modifier = Modifier.size(80.dp, 60.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Right")
            }
        }
        
        Button(
            onClick = { /* TODO */ },
            modifier = Modifier.size(80.dp, 60.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down")
        }
    }
}
