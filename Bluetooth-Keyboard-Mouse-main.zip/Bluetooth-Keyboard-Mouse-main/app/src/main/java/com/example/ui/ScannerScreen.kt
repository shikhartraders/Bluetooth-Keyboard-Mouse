package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

@Composable
fun ScannerScreen(navController: NavController) {
    val context = LocalContext.current
    var scanResult by remember { mutableStateOf<String?>(null) }
    var isScanning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (scanResult == null && !isScanning) {
            Button(onClick = {
                isScanning = true
                val options = GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(com.google.mlkit.vision.barcode.common.Barcode.FORMAT_ALL_FORMATS)
                    .build()
                val scanner = GmsBarcodeScanning.getClient(context, options)
                
                scanner.startScan()
                    .addOnSuccessListener { barcode ->
                        scanResult = barcode.rawValue
                        isScanning = false
                    }
                    .addOnCanceledListener {
                        isScanning = false
                    }
                    .addOnFailureListener {
                        scanResult = "Failed to scan"
                        isScanning = false
                    }
            }) {
                Text("Start Scan")
            }
        } else if (isScanning) {
            CircularProgressIndicator()
            Spacer(modifier = Modifier.height(16.dp))
            Text("Scanning...")
        } else {
            Text("Result:", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Text(scanResult ?: "", style = MaterialTheme.typography.bodyLarge)
            
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    scanResult?.let {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, it)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share via"))
                    }
                }) {
                    Text("Share")
                }
                
                if (scanResult?.startsWith("http") == true) {
                    Button(onClick = {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(scanResult))
                        context.startActivity(browserIntent)
                    }) {
                        Text("Open in Browser")
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(onClick = { scanResult = null }) {
                Text("Scan Again")
            }
        }
    }
}
