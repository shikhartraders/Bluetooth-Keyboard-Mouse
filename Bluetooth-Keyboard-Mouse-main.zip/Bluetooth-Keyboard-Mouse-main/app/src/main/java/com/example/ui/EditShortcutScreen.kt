package com.example.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditShortcutScreen(navController: NavController) {
    var shortcutName by remember { mutableStateOf("Copy") }
    var selectedSize by remember { mutableStateOf("MEDIUM") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit shortcut") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                },
                actions = {
                    TextButton(onClick = { navController.popBackStack() }) {
                        Text("SAVE", color = MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { /* TODO */ }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Ctrl + C",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                textAlign = TextAlign.Center
            )
            
            // Mock Keyboard layout
            KeyboardLayout(modifier = Modifier.weight(1f))
            
            // Bottom section
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                OutlinedTextField(
                    value = shortcutName,
                    onValueChange = { shortcutName = it },
                    label = { Text("Shortcut name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    val sizes = listOf("SMALL", "MEDIUM", "LARGE")
                    sizes.forEach { size ->
                        TextButton(
                            onClick = { selectedSize = size },
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Text(
                                text = size,
                                color = if (selectedSize == size) MaterialTheme.colorScheme.primary else Color.Gray,
                                fontWeight = if (selectedSize == size) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KeyboardLayout(modifier: Modifier = Modifier) {
    // Just a visual representation of a keyboard
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val row1 = listOf("ESC", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9")
        val row2 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row3 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
        val row4 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L")
        val row5 = listOf("Z", "X", "C", "V", "B", "N", "M")

        KeyboardRow(row1)
        KeyboardRow(row2)
        KeyboardRow(row3)
        KeyboardRow(row4)
        KeyboardRow(row5, specialKey = "C")
    }
}

@Composable
fun KeyboardRow(keys: List<String>, specialKey: String? = null) {
    val view = LocalView.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        keys.forEach { key ->
            val isSelected = key == specialKey
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(2.dp)
                    .aspectRatio(1f)
                    .border(
                        1.dp,
                        if (isSelected) MaterialTheme.colorScheme.primary else Color.DarkGray,
                        RoundedCornerShape(8.dp)
                    )
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    )
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { 
                        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = key,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray,
                    fontSize = 12.sp
                )
            }
        }
    }
}
