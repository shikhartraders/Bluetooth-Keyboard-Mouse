package com.example.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures

@Composable
fun MouseKeyboardScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel, showInputBar: Boolean = false) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TrackpadArea(
            modifier = Modifier.weight(1f),
            onMove = { dx, dy -> bluetoothViewModel.sendMouseReport(dx.toInt(), dy.toInt(), false, false, 0) },
            onClick = { bluetoothViewModel.sendMouseReport(0, 0, true, false, 0); bluetoothViewModel.sendMouseReport(0, 0, false, false, 0) }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Mouse Buttons (Left, Right)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MouseClickButton(
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendMouseReport(0, 0, true, false, 0); bluetoothViewModel.sendMouseReport(0, 0, false, false, 0) }
            )
            MouseClickButton(
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendMouseReport(0, 0, false, true, 0); bluetoothViewModel.sendMouseReport(0, 0, false, false, 0) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        CustomShortcutsArea(bluetoothViewModel)

        if (showInputBar) {
            Spacer(modifier = Modifier.height(8.dp))
            TextInputBar(bluetoothViewModel)
        }
    }
}

@Composable
fun MouseClickButton(modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF3B7CA6)) // Exact shade from screenshot
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                onClick()
            }
    )
}

@Composable
fun TrackpadArea(modifier: Modifier = Modifier, onMove: (Float, Float) -> Unit = { _, _ -> }, onClick: () -> Unit = {}) {
    val trackpadColor = Color(0xFF004975) // Exact shade from screenshot
    val iconColor = Color.White
    val view = LocalView.current
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(trackpadColor)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        onClick()
                    }
                )
            }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onMove(dragAmount.x, dragAmount.y)
                }
            }
    ) {
        Icon(
            imageVector = Icons.Default.Mouse,
            contentDescription = "Mouse",
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp),
            tint = iconColor.copy(alpha = 0.8f)
        )
        
        // Scrollbar area
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp)
                .fillMaxHeight(0.8f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Scroll Up", tint = iconColor)
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .weight(1f)
                    .padding(vertical = 8.dp)
                    .background(iconColor, RoundedCornerShape(1.dp))
            )
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Scroll Down", tint = iconColor)
        }
    }
}

@Composable
fun CustomShortcutsArea(bluetoothViewModel: BluetoothViewModel) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ShortcutButton(text = "Undo", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0x01, 0x1D); bluetoothViewModel.sendKeyboardReport(0, 0) }) // Ctrl+Z
            ShortcutButton(text = "Redo", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0x01, 0x1C); bluetoothViewModel.sendKeyboardReport(0, 0) }) // Ctrl+Y
            ShortcutButton(text = "Copy", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0x01, 0x06); bluetoothViewModel.sendKeyboardReport(0, 0) }) // Ctrl+C
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ShortcutButton(text = "Paste", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0x01, 0x19); bluetoothViewModel.sendKeyboardReport(0, 0) }) // Ctrl+V
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ShortcutButton(text = "←", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0, 0x50); bluetoothViewModel.sendKeyboardReport(0, 0) }) // Left
            ShortcutButton(text = "→", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0, 0x4F); bluetoothViewModel.sendKeyboardReport(0, 0) }) // Right
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ShortcutButton(text = "Unlock Back", modifier = Modifier.weight(1.5f), onClick = {})
            ShortcutButton(text = "Home", modifier = Modifier.weight(1f), onClick = {})
            ShortcutButton(text = "Menu", modifier = Modifier.weight(1f), onClick = {})
        }
    }
}

@Composable
fun ShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .height(48.dp)
            .background(Color(0xFF4A88B0), RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                onClick()
                // You'd also need a way to release the key if we wanted true key up/down
            }
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Normal,
            fontSize = 18.sp
        )
    }
}

@Composable
fun TextInputBar(bluetoothViewModel: BluetoothViewModel) {
    var text by remember { mutableStateOf("") }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MaterialTheme.colorScheme.surface),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .weight(0.3f)
                .fillMaxHeight()
                .background(Color(0xFFD6E8F4), RoundedCornerShape(28.dp))
                .clickable { },
            contentAlignment = Alignment.Center
        ) {
            Text("Direct", color = Color(0xFF3B7CA6), fontSize = 16.sp)
        }
        
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            placeholder = { Text("Enter...") },
            modifier = Modifier
                .weight(0.5f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(8.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.Gray,
                focusedBorderColor = Color.Gray
            )
        )
        
        IconButton(onClick = { /* Toggle Password visibility */ }) {
            Icon(Icons.Default.Visibility, contentDescription = "Show Password", tint = Color.Gray)
        }
        IconButton(onClick = { /* Change Language */ }) {
            Icon(Icons.Default.Language, contentDescription = "Language", tint = Color(0xFF3B7CA6))
        }
    }
}
