package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import android.view.HapticFeedbackConstants

@Composable
fun NumpadScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val keys = listOf(
            listOf("NumLock", "/", "*", "-"),
            listOf("7", "8", "9", "+"),
            listOf("4", "5", "6", ""),
            listOf("1", "2", "3", "Enter"),
            listOf("0", "", ".", "")
        )

        keys.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { key ->
                    if (key.isNotEmpty()) {
                        NumpadButton(
                            text = key,
                            modifier = Modifier
                                .weight(if (key == "0") 2f else 1f)
                                .height(64.dp),
                            onClick = {
                                // Provide keycodes mapping if needed, else simulate generic click
                                bluetoothViewModel.sendKeyboardReport(0, 0x1E) // Generic placeholder
                                bluetoothViewModel.sendKeyboardReport(0, 0)
                            }
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun NumpadButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF3B7CA6))
            .clickable {
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
    }
}
