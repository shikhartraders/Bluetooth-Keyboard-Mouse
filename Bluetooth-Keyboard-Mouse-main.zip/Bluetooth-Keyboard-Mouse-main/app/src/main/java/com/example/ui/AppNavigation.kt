package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch

import androidx.lifecycle.viewmodel.compose.viewModel
import android.Manifest
import android.annotation.SuppressLint
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.ui.BluetoothStatus

sealed class Screen(val route: String, val title: String) {
    object MouseKeyboard : Screen("mouse_keyboard", "Mouse / Keyboard")
    object Multimedia : Screen("multimedia", "Multimedia")
    object Shortcuts : Screen("shortcuts", "Manage shortcuts")
    object EditShortcut : Screen("edit_shortcut", "Edit shortcut")
    object Numpad : Screen("numpad", "Numpad")
    object PcKeyboard : Screen("pc_keyboard", "PC keyboard")
    object Scanner : Screen("scanner", "Code scanner")
    object AiMacro : Screen("ai_macro", "AI Macro")
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(bluetoothViewModel: BluetoothViewModel = viewModel()) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    
    val uiState by bluetoothViewModel.uiState.collectAsState()
    
    var showDeviceDialog by remember { mutableStateOf(false) }

    val permissionsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            bluetoothViewModel.checkBluetoothStatus()
        }
    }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            permissions.add(Manifest.permission.BLUETOOTH)
            permissions.add(Manifest.permission.BLUETOOTH_ADMIN)
        }
        permissionsLauncher.launch(permissions.toTypedArray())
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    
    var showInputBar by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(16.dp))
                Text(
                    "Bluetooth Keyboard &\nMouse",
                    modifier = Modifier.padding(16.dp),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Divider()
                
                Text(
                    "Controls",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontSize = 14.sp,
                    color = Color.Gray
                )
                
                NavigationDrawerItem(
                    label = { Text("Mouse / Keyboard") },
                    selected = currentRoute == Screen.MouseKeyboard.route,
                    onClick = {
                        navController.navigate(Screen.MouseKeyboard.route) {
                            popUpTo(navController.graph.startDestinationId)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Default.Mouse, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Multimedia") },
                    selected = currentRoute == Screen.Multimedia.route,
                    onClick = {
                        navController.navigate(Screen.Multimedia.route) {
                            popUpTo(navController.graph.startDestinationId)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Default.PlayCircleFilled, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("PC keyboard") },
                    selected = currentRoute == Screen.PcKeyboard.route,
                    onClick = {
                        navController.navigate(Screen.PcKeyboard.route) {
                            popUpTo(navController.graph.startDestinationId)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Default.Keyboard, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Numpad") },
                    selected = currentRoute == Screen.Numpad.route,
                    onClick = {
                        navController.navigate(Screen.Numpad.route) {
                            popUpTo(navController.graph.startDestinationId)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(painterResource(android.R.drawable.ic_dialog_dialer), contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Presenter") },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(painterResource(android.R.drawable.ic_menu_camera), contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Code scanner") },
                    selected = currentRoute == Screen.Scanner.route,
                    onClick = {
                        navController.navigate(Screen.Scanner.route) {
                            popUpTo(navController.graph.startDestinationId)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(painterResource(android.R.drawable.ic_menu_search), contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    label = { Text("AI Macro") },
                    selected = currentRoute == Screen.AiMacro.route,
                    onClick = {
                        navController.navigate(Screen.AiMacro.route) {
                            popUpTo(navController.graph.startDestinationId)
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Default.Star, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                Divider(modifier = Modifier.padding(vertical = 8.dp))
                
                Text(
                    "Custom layouts",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontSize = 14.sp,
                    color = Color.Gray
                )
                
                NavigationDrawerItem(
                    label = { Text("Custom layout") },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(painterResource(android.R.drawable.ic_input_add), contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                
                NavigationDrawerItem(
                    label = { Text("Manage layouts") },
                    selected = currentRoute == Screen.Shortcuts.route,
                    onClick = {
                        navController.navigate(Screen.Shortcuts.route)
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                Divider(modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    "Configuration",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontSize = 14.sp,
                    color = Color.Gray
                )

                NavigationDrawerItem(
                    label = { Text("Bluetooth devices") },
                    selected = false,
                    onClick = { 
                        showDeviceDialog = true 
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(painterResource(android.R.drawable.ic_menu_compass), contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    label = { Text("Feedback") },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(painterResource(android.R.drawable.ic_dialog_info), contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    label = { Text("Upgrade to the Pro version") },
                    selected = false,
                    onClick = { scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.Star, contentDescription = null) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                if (currentRoute != Screen.Shortcuts.route && currentRoute != Screen.EditShortcut.route) {
                    TopAppBar(
                        title = {
                            Column(modifier = Modifier.clickable { showDeviceDialog = true }) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val title = when (currentRoute) {
                                        Screen.MouseKeyboard.route -> "Mouse / Keyboard"
                                        Screen.Multimedia.route -> "Multimedia"
                                        Screen.Numpad.route -> "Numpad"
                                        Screen.PcKeyboard.route -> "PC keyboard"
                                        Screen.Scanner.route -> "Code scanner"
                                        Screen.AiMacro.route -> "AI Macro"
                                        else -> "Bluetooth Keyboard"
                                    }
                                    Text(
                                        text = title,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 20.sp
                                    )
                                    if (currentRoute == Screen.Multimedia.route) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(Icons.Default.Star, contentDescription = "Favorite", modifier = Modifier.size(18.dp))
                                    }
                                }
                                val statusText = when (uiState.status) {
                                    BluetoothStatus.CONNECTED -> "${uiState.connectedDevice?.name ?: "Unknown Device"} conn..."
                                    BluetoothStatus.CONNECTING -> "Connecting..."
                                    BluetoothStatus.DISCONNECTED -> "Not connected"
                                    BluetoothStatus.DISABLED -> "Bluetooth disabled"
                                    BluetoothStatus.NOT_SUPPORTED -> "Bluetooth not supported"
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(statusText, fontSize = 14.sp, color = Color.Gray)
                                    Icon(painterResource(android.R.drawable.arrow_down_float), contentDescription = "Dropdown", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu")
                            }
                        },
                        actions = {
                            IconButton(onClick = { showInputBar = !showInputBar }) {
                                Icon(Icons.Default.Keyboard, contentDescription = "Keyboard", tint = Color.Gray)
                            }
                            IconButton(onClick = { showSettings = true }) {
                                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.Gray)
                            }
                            if (showSettings) {
                                SettingsBottomSheet(onDismiss = { showSettings = false })
                            }
                        }
                    )
                }
            }
        ) { innerPadding ->
            Column(modifier = Modifier.padding(innerPadding)) {
                NavHost(
                    navController = navController,
                    startDestination = Screen.MouseKeyboard.route,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(Screen.MouseKeyboard.route) {
                        MouseKeyboardScreen(navController = navController, bluetoothViewModel = bluetoothViewModel, showInputBar = showInputBar)
                    }
                    composable(Screen.Multimedia.route) {
                        MultimediaScreen(navController = navController)
                    }
                    composable(Screen.Shortcuts.route) {
                        ShortcutsScreen(navController = navController)
                    }
                    composable(Screen.EditShortcut.route) {
                        EditShortcutScreen(navController = navController)
                    }
                    composable(Screen.Numpad.route) {
                        NumpadScreen(navController = navController, bluetoothViewModel = bluetoothViewModel)
                    }
                    composable(Screen.PcKeyboard.route) {
                        PcKeyboardScreen(navController = navController, bluetoothViewModel = bluetoothViewModel)
                    }
                    composable(Screen.Scanner.route) {
                        ScannerScreen(navController = navController)
                    }
                    composable(Screen.AiMacro.route) {
                        AiMacroScreen(navController = navController, bluetoothViewModel = bluetoothViewModel)
                    }
                }
            }

            if (showDeviceDialog) {
                BluetoothConnectionDialog(
                    uiState = uiState,
                    onDismiss = { showDeviceDialog = false },
                    onConnect = { device -> 
                        bluetoothViewModel.connectToDevice(device)
                        showDeviceDialog = false
                    },
                    onDisconnect = { bluetoothViewModel.disconnect() },
                    onRefresh = { bluetoothViewModel.checkBluetoothStatus() },
                    onStartScan = { bluetoothViewModel.startScanning() },
                    onStopScan = { bluetoothViewModel.stopScanning() }
                )
            }
        }
    }
}
