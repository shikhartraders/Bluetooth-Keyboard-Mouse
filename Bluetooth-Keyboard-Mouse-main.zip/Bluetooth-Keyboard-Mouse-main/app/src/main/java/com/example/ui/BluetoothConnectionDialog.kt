package com.example.ui

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

@SuppressLint("MissingPermission")
@Composable
fun BluetoothConnectionDialog(
    uiState: BluetoothUiState,
    onDismiss: () -> Unit,
    onConnect: (BluetoothDevice) -> Unit,
    onDisconnect: () -> Unit,
    onRefresh: () -> Unit,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Bluetooth Devices",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                if (uiState.status == BluetoothStatus.NOT_SUPPORTED) {
                    Text("Bluetooth is not supported on this device.")
                } else if (uiState.status == BluetoothStatus.DISABLED) {
                    Text("Bluetooth is disabled. Please enable it in your device settings.")
                } else {
                    LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
                        if (uiState.status == BluetoothStatus.CONNECTED && uiState.connectedDevice != null) {
                            item {
                                Text("Connected Device:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                DeviceItem(
                                    device = uiState.connectedDevice,
                                    isConnected = true,
                                    onClick = { onDisconnect() }
                                )
                                Divider(modifier = Modifier.padding(vertical = 8.dp))
                            }
                        }
                        
                        item {
                            Text("Paired Devices:", style = MaterialTheme.typography.labelMedium)
                        }
                        if (uiState.pairedDevices.isEmpty()) {
                            item {
                                Text("No paired devices found.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
                            }
                        } else {
                            items(uiState.pairedDevices) { device ->
                                if (device.address != uiState.connectedDevice?.address) {
                                    DeviceItem(
                                        device = device,
                                        isConnected = false,
                                        onClick = { onConnect(device) }
                                    )
                                }
                            }
                        }
                        
                        item {
                            Divider(modifier = Modifier.padding(vertical = 8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Available Devices:", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                                if (uiState.isScanning) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                }
                            }
                        }
                        
                        if (uiState.scannedDevices.isEmpty()) {
                            item {
                                Text(if (uiState.isScanning) "Scanning..." else "No devices found.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
                            }
                        } else {
                            items(uiState.scannedDevices.filter { scannedDevice -> 
                                // Don't show already paired or connected devices in available
                                uiState.pairedDevices.none { it.address == scannedDevice.address } &&
                                uiState.connectedDevice?.address != scannedDevice.address
                            }) { device ->
                                DeviceItem(
                                    device = device,
                                    isConnected = false,
                                    onClick = { onConnect(device) }
                                )
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (uiState.status != BluetoothStatus.NOT_SUPPORTED && uiState.status != BluetoothStatus.DISABLED) {
                        TextButton(onClick = { if (uiState.isScanning) onStopScan() else onStartScan() }) {
                            Text(if (uiState.isScanning) "STOP SCAN" else "SCAN")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    TextButton(onClick = onRefresh) {
                        Text("REFRESH")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = {
                        if (uiState.isScanning) onStopScan()
                        onDismiss()
                    }) {
                        Text("CLOSE")
                    }
                }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun DeviceItem(device: BluetoothDevice, isConnected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isConnected) Icons.Default.BluetoothConnected else Icons.Default.Bluetooth,
            contentDescription = null,
            tint = if (isConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(text = device.name ?: "Unknown Device", fontWeight = if (isConnected) FontWeight.Bold else FontWeight.Normal)
            Text(text = device.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
