package com.example.ui

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class HidMacroPayload(val macro_sequence: List<HidMacroAction>)

@Serializable
data class HidMacroAction(
    val action_type: String,
    val key: String? = null,
    val modifiers: List<String>? = null,
    val duration_ms: Long? = null
)

class HidMacroExecutor {
    private val TAG = "HidMacroExecutor"

    private val modifierMap = mapOf(
        "ctrl" to 0x01,
        "shift" to 0x02,
        "alt" to 0x04,
        "gui" to 0x08,
        "left_ctrl" to 0x01,
        "left_shift" to 0x02,
        "left_alt" to 0x04,
        "left_gui" to 0x08,
        "right_ctrl" to 0x10,
        "right_shift" to 0x20,
        "right_alt" to 0x40,
        "right_gui" to 0x80
    )

    private val keyMap = mapOf(
        "enter" to 0x28,
        "esc" to 0x29,
        "backspace" to 0x2A,
        "tab" to 0x2B,
        "space" to 0x2C,
        "-" to 0x2D,
        "=" to 0x2E,
        "[" to 0x2F,
        "]" to 0x30,
        "\\" to 0x31,
        ";" to 0x33,
        "'" to 0x34,
        "`" to 0x35,
        "," to 0x36,
        "." to 0x37,
        "/" to 0x38,
        "caps_lock" to 0x39,
        "f1" to 0x3A,
        "f2" to 0x3B,
        "f3" to 0x3C,
        "f4" to 0x3D,
        "f5" to 0x3E,
        "f6" to 0x3F,
        "f7" to 0x40,
        "f8" to 0x41,
        "f9" to 0x42,
        "f10" to 0x43,
        "f11" to 0x44,
        "f12" to 0x45,
        "print_screen" to 0x46,
        "scroll_lock" to 0x47,
        "pause" to 0x48,
        "insert" to 0x49,
        "home" to 0x4A,
        "page_up" to 0x4B,
        "delete" to 0x4C,
        "end" to 0x4D,
        "page_down" to 0x4E,
        "right" to 0x4F,
        "left" to 0x50,
        "down" to 0x51,
        "up" to 0x52,
        "a" to 0x04, "b" to 0x05, "c" to 0x06, "d" to 0x07, "e" to 0x08,
        "f" to 0x09, "g" to 0x0A, "h" to 0x0B, "i" to 0x0C, "j" to 0x0D,
        "k" to 0x0E, "l" to 0x0F, "m" to 0x10, "n" to 0x11, "o" to 0x12,
        "p" to 0x13, "q" to 0x14, "r" to 0x15, "s" to 0x16, "t" to 0x17,
        "u" to 0x18, "v" to 0x19, "w" to 0x1A, "x" to 0x1B, "y" to 0x1C, "z" to 0x1D,
        "1" to 0x1E, "2" to 0x1F, "3" to 0x20, "4" to 0x21, "5" to 0x22,
        "6" to 0x23, "7" to 0x24, "8" to 0x25, "9" to 0x26, "0" to 0x27
    )

    private val json = Json { ignoreUnknownKeys = true }

    @SuppressLint("MissingPermission")
    suspend fun executeMacro(
        jsonString: String,
        hidDevice: BluetoothHidDevice,
        targetDevice: BluetoothDevice,
        hostId: Byte
    ) = withContext(Dispatchers.IO) {
        try {
            val payload = json.decodeFromString<HidMacroPayload>(jsonString)
            for (action in payload.macro_sequence) {
                when (action.action_type.lowercase()) {
                    "delay" -> {
                        val duration = action.duration_ms ?: 500L
                        Log.d(TAG, "Delaying for $duration ms")
                        delay(duration)
                    }
                    "keypress" -> {
                        var modifierByte = 0
                        action.modifiers?.forEach { mod ->
                            modifierByte = modifierByte or (modifierMap[mod.lowercase()] ?: 0)
                        }

                        val keyString = action.key?.lowercase()
                        val keyByte = keyMap[keyString] ?: 0

                        if (keyByte == 0 && keyString != null) {
                            Log.w(TAG, "Unknown key: $keyString")
                        }

                        Log.d(TAG, "Sending keypress: $keyString with modifiers: $modifierByte")
                        val report = ByteArray(8)
                        report[0] = modifierByte.toByte()
                        report[1] = 0x00
                        report[2] = keyByte.toByte()
                        
                        hidDevice.sendReport(targetDevice, hostId.toInt(), report)
                        
                        // Short delay before release
                        delay(30)
                        
                        // Release keys
                        val releaseReport = ByteArray(8)
                        hidDevice.sendReport(targetDevice, hostId.toInt(), releaseReport)
                        
                        // Short delay between actions
                        delay(20)
                    }
                    else -> {
                        Log.w(TAG, "Unknown action type: ${action.action_type}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing macro", e)
        }
    }
}
