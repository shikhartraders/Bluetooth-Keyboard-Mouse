import re
with open("app/src/main/java/com/example/ui/AppNavigation.kt", "r") as f:
    code = f.read()

# Add Screen.Terms
screen_terms = """    object Terms : Screen("terms")\n}"""
code = code.replace("}", screen_terms, 1)

# Add to NavHost
nav_composable = """                    composable(Screen.InfoHelp.route) {
                        InfoHelpScreen(navController = navController)
                    }
                    composable(Screen.Terms.route) {
                        TermsAndConditionsScreen(navController = navController)
                    }"""
code = code.replace("""                    composable(Screen.InfoHelp.route) {
                        InfoHelpScreen(navController = navController)
                    }""", nav_composable)

with open("app/src/main/java/com/example/ui/AppNavigation.kt", "w") as f:
    f.write(code)
