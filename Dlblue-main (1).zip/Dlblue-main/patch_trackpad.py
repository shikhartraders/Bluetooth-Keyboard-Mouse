import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# 1. Update TrackpadArea signature
old_sig = """fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {},
    onMiddleClick: () -> Unit = {},
    pointerSpeed: Float = 1.2f
)"""

new_sig = """fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {},
    onMiddleClick: () -> Unit = {},
    onThreeFingerSwipe: (dx: Float, dy: Float) -> Unit = { _, _ -> },
    pointerSpeed: Float = 1.2f
)"""

if old_sig in code:
    code = code.replace(old_sig, new_sig)
    print("Replaced TrackpadArea signature")
else:
    print("Could not find TrackpadArea signature")

# 2. Update TrackpadArea implementation to track 3 fingers
old_3_finger = """                            if (activePointers.size >= 3) {
                                isThreeFingers = true
                            } else if (activePointers.size == 2) {"""

new_3_finger = """                            if (activePointers.size >= 3) {
                                isThreeFingers = true
                                val currentX = activePointers.map { it.position.x }.average().toFloat()
                                val currentY = activePointers.map { it.position.y }.average().toFloat()
                                
                                val dx = currentX - lastX
                                val dy = currentY - lastY
                                
                                if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                                
                                leftoverX += dx
                                leftoverY += dy
                                
                                val swipeThreshold = 50f
                                if (kotlin.math.abs(leftoverX) > swipeThreshold || kotlin.math.abs(leftoverY) > swipeThreshold) {
                                    onThreeFingerSwipe(leftoverX, leftoverY)
                                    leftoverX = 0f
                                    leftoverY = 0f
                                }
                                
                                lastX = currentX
                                lastY = currentY
                            } else if (activePointers.size == 2) {"""

if old_3_finger in code:
    code = code.replace(old_3_finger, new_3_finger)
    print("Replaced 3 finger logic")
else:
    print("Could not find 3 finger logic")

# 3. Handle it in MouseKeyboardScreen call
old_call = """            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            },
            pointerSpeed = pointerSpeed"""

new_call = """            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            },
            onThreeFingerSwipe = { dx, dy ->
                if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                    if (dx > 0) {
                        // Swipe Right: Switch Desktop Right (Win + Ctrl + Right Arrow)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x09, 0x4F)
                    } else {
                        // Swipe Left: Switch Desktop Left (Win + Ctrl + Left Arrow)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x09, 0x50)
                    }
                } else {
                    if (dy > 0) {
                        // Swipe Down: Show Desktop (Win + D)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x08, 0x07)
                    } else {
                        // Swipe Up: Task View (Win + Tab)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x08, 0x2B)
                    }
                }
            },
            pointerSpeed = pointerSpeed"""

if old_call in code:
    code = code.replace(old_call, new_call)
    print("Replaced TrackpadArea call")
else:
    print("Could not find TrackpadArea call")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
