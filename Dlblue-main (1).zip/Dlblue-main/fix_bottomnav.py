import re

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()

# Update signature
code = code.replace("""fun BottomNavButton(text: String, modifier: Modifier = Modifier) {""", """fun BottomNavButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {""")

# Update Button inside BottomNavButton
code = code.replace("""Button(
        onClick = { view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_PRESS) },""", """Button(
        onClick = { view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_PRESS); onClick() },""")

# Update usages
code = code.replace("""BottomNavButton(text = "BACK", modifier = Modifier.weight(1f))""", """BottomNavButton(text = "BACK", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0, 0x29); bluetoothViewModel.sendKeyboardReport(0, 0) })""")
code = code.replace("""BottomNavButton(text = "HOME", modifier = Modifier.weight(1f))""", """BottomNavButton(text = "HOME", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0, 0x4A); bluetoothViewModel.sendKeyboardReport(0, 0) })""")
code = code.replace("""BottomNavButton(text = "MENU", modifier = Modifier.weight(1f))""", """BottomNavButton(text = "MENU", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReport(0, 0x65); bluetoothViewModel.sendKeyboardReport(0, 0) })""")

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "w") as f:
    f.write(code)

