import urllib.request
import os

code = """package com.example.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.input.pointer.pointerInput

@Composable
fun MouseKeyboardScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel, showInputBar: Boolean = false) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TrackpadArea(
            modifier = Modifier.weight(1f),
            onReport = { dx, dy, left, right, middle, wheel, hwheel ->
                bluetoothViewModel.sendMouseReport(dx, dy, left, right, middle, wheel, hwheel)
            },
            onClick = { bluetoothViewModel.sendMouseClick() },
            onRightClick = { bluetoothViewModel.sendRightMouseClick() },
            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Mouse Buttons (Left, Middle, Right)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MouseClickButton(
                text = "L",
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendMouseClick() }
            )
            MouseClickButton(
                text = "M",
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { 
                    bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                    bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
                }
            )
            MouseClickButton(
                text = "R",
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendRightMouseClick() }
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        ControlPanels(bluetoothViewModel)
    }
}

@Composable
fun MouseClickButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF3B7CA6))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    }
}

@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {},
    onMiddleClick: () -> Unit = {}
) {
    val trackpadColor = Color(0xFF004975)
    val iconColor = Color.White
    val view = LocalView.current
    
    var lastTapTime by remember { mutableLongStateOf(0L) }
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(trackpadColor)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val downEvent = awaitFirstDown(requireUnconsumed = false)
                        val startTime = System.currentTimeMillis()
                        
                        var isTwoFingers = false
                        var isThreeFingers = false
                        var isDragging = false
                        var moved = false
                        
                        var lastX = downEvent.position.x
                        var lastY = downEvent.position.y
                        
                        var leftoverX = 0f
                        var leftoverY = 0f
                        var wheelLeftoverY = 0f
                        var wheelLeftoverX = 0f
                        
                        val tapTimeout = 200L
                        val dragTimeout = 250L
                        
                        if (startTime - lastTapTime < dragTimeout) {
                            isDragging = true
                            onReport(0, 0, true, false, false, 0, 0)
                        }
                        
                        do {
                            val event = awaitPointerEvent()
                            val pointers = event.changes
                            
                            val activePointers = pointers.filter { it.pressed }
                            
                            if (activePointers.size >= 3) {
                                isThreeFingers = true
                            } else if (activePointers.size == 2) {
                                isTwoFingers = true
                                val currentX = (activePointers[0].position.x + activePointers[1].position.x) / 2
                                val currentY = (activePointers[0].position.y + activePointers[1].position.y) / 2
                                
                                val dx = currentX - lastX
                                val dy = currentY - lastY
                                
                                if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                                
                                wheelLeftoverY += dy
                                wheelLeftoverX += dx
                                
                                val wheel = -(wheelLeftoverY / 15f).toInt()
                                val hwheel = (wheelLeftoverX / 15f).toInt()
                                
                                if (wheel != 0 || hwheel != 0) {
                                    onReport(0, 0, false, false, false, wheel, hwheel)
                                    wheelLeftoverY += wheel * 15f
                                    wheelLeftoverX -= hwheel * 15f
                                }
                                
                                lastX = currentX
                                lastY = currentY
                                
                            } else if (activePointers.size == 1) {
                                val currentX = activePointers[0].position.x
                                val currentY = activePointers[0].position.y
                                val dx = currentX - lastX
                                val dy = currentY - lastY
                                
                                if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                                
                                val dist = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                val accel = (dist / 10f).coerceIn(1.0f, 4.0f)
                                val baseSensitivity = 1.2f
                                
                                leftoverX += dx * baseSensitivity * accel
                                leftoverY += dy * baseSensitivity * accel
                                
                                val outX = leftoverX.toInt()
                                val outY = leftoverY.toInt()
                                
                                if (outX != 0 || outY != 0) {
                                    onReport(outX, outY, isDragging, false, false, 0, 0)
                                    leftoverX -= outX
                                    leftoverY -= outY
                                }
                                lastX = currentX
                                lastY = currentY
                            }
                            
                            pointers.forEach { it.consume() }
                        } while (event.changes.any { it.pressed })
                        
                        val endTime = System.currentTimeMillis()
                        
                        if (isDragging) {
                            onReport(0, 0, false, false, false, 0, 0)
                            lastTapTime = 0L
                        } else if (!moved && endTime - startTime < tapTimeout) {
                            if (isThreeFingers) {
                                onMiddleClick()
                            } else if (isTwoFingers) {
                                onRightClick()
                            } else {
                                lastTapTime = endTime
                                onClick()
                            }
                        }
                    }
                }
            }
    ) {
        Icon(
            imageVector = Icons.Default.Mouse,
            contentDescription = "Mouse",
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp),
            tint = iconColor.copy(alpha = 0.8f)
        )
    }
}

@Composable
fun TextInputBar(bluetoothViewModel: BluetoothViewModel) {
    var text by remember { mutableStateOf("") }
    
    fun charToHid(c: Char): Pair<Byte, Byte>? {
        val shift: Byte = 0x02
        return when (c) {
            in 'a'..'z' -> Pair(0.toByte(), (c - 'a' + 0x04).toByte())
            in 'A'..'Z' -> Pair(shift, (c - 'A' + 0x04).toByte())
            in '1'..'9' -> Pair(0.toByte(), (c - '1' + 0x1E).toByte())
            '0' -> Pair(0.toByte(), 0x27)
            ' ' -> Pair(0.toByte(), 0x2C)
            '\n' -> Pair(0.toByte(), 0x28)
            '-' -> Pair(0.toByte(), 0x2D)
            '=' -> Pair(0.toByte(), 0x2E)
            '[' -> Pair(0.toByte(), 0x2F)
            ']' -> Pair(0.toByte(), 0x30)
            '\\' -> Pair(0.toByte(), 0x31)
            ';' -> Pair(0.toByte(), 0x33)
            '\'' -> Pair(0.toByte(), 0x34)
            '`' -> Pair(0.toByte(), 0x35)
            ',' -> Pair(0.toByte(), 0x36)
            '.' -> Pair(0.toByte(), 0x37)
            '/' -> Pair(0.toByte(), 0x38)
            '!' -> Pair(shift, 0x1E)
            '@' -> Pair(shift, 0x1F)
            '#' -> Pair(shift, 0x20)
            '$' -> Pair(shift, 0x21)
            '%' -> Pair(shift, 0x22)
            '^' -> Pair(shift, 0x23)
            '&' -> Pair(shift, 0x24)
            '*' -> Pair(shift, 0x25)
            '(' -> Pair(shift, 0x26)
            ')' -> Pair(shift, 0x27)
            '_' -> Pair(shift, 0x2D)
            '+' -> Pair(shift, 0x2E)
            '{' -> Pair(shift, 0x2F)
            '}' -> Pair(shift, 0x30)
            '|' -> Pair(shift, 0x31)
            ':' -> Pair(shift, 0x33)
            '"' -> Pair(shift, 0x34)
            '~' -> Pair(shift, 0x35)
            '<' -> Pair(shift, 0x36)
            '>' -> Pair(shift, 0x37)
            '?' -> Pair(shift, 0x38)
            else -> null
        }
    }
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MaterialTheme.colorScheme.surface),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .weight(0.3f)
                .fillMaxHeight()
                .background(Color(0xFFD6E8F4), RoundedCornerShape(28.dp))
                .clickable { },
            contentAlignment = Alignment.Center
        ) {
            Text("Direct", color = Color(0xFF3B7CA6), fontSize = 16.sp)
        }
        
        OutlinedTextField(
            value = text,
            onValueChange = { newText -> 
                if (newText.length > text.length) {
                    val added = newText.substring(text.length)
                    added.forEach { c ->
                        charToHid(c)?.let { (mod, key) ->
                            bluetoothViewModel.sendKeyboardReportWithRelease(mod, key)
                        }
                    }
                } else if (newText.length < text.length) {
                    repeat(text.length - newText.length) {
                        bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2A) // Backspace
                    }
                }
                text = newText
            },
            placeholder = { Text("Enter...") },
            modifier = Modifier
                .weight(0.5f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(8.dp),
            keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Done),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.Gray,
                focusedBorderColor = Color.Gray
            )
        )
        
        IconButton(onClick = { text = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
        }
    }
}

@Composable
fun ControlPanels(bluetoothViewModel: BluetoothViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Keyboard", "Numpad", "Media")
    
    Column(modifier = Modifier.fillMaxWidth().height(250.dp)) {
        TabRow(selectedTabIndex = selectedTab, containerColor = Color.Transparent) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold) }
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                0 -> FullKeyboardPanel(bluetoothViewModel)
                1 -> NumpadPanel(bluetoothViewModel)
                2 -> MediaPanel(bluetoothViewModel)
            }
        }
    }
}

@Composable
fun FullKeyboardPanel(bluetoothViewModel: BluetoothViewModel) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Esc", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29) }
            privateShortcutButton("Tab", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2B) }
            privateShortcutButton("Caps", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x39) }
            privateShortcutButton("Shift", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x02, 0) }
            privateShortcutButton("Ctrl", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0) }
            privateShortcutButton("Alt", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x04, 0) }
            privateShortcutButton("Win", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x08, 0) }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("F1", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3A) }
            privateShortcutButton("F2", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3B) }
            privateShortcutButton("F3", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3C) }
            privateShortcutButton("F4", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3D) }
            privateShortcutButton("F5", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3E) }
            privateShortcutButton("PrtSc", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x46) }
            privateShortcutButton("Ins", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x49) }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Home", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4A) }
            privateShortcutButton("End", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4D) }
            privateShortcutButton("PgUp", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4B) }
            privateShortcutButton("PgDn", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4E) }
            privateShortcutButton("Del", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4C) }
            privateShortcutButton("Bksp", modifier = Modifier.weight(1.5f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2A) }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Space", modifier = Modifier.weight(2f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2C) }
            privateShortcutButton("Enter", modifier = Modifier.weight(1.5f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x28) }
            privateShortcutButton("↑", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x52) }
            privateShortcutButton("↓", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x51) }
            privateShortcutButton("←", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) }
            privateShortcutButton("→", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) }
        }
        Spacer(modifier = Modifier.height(4.dp))
        TextInputBar(bluetoothViewModel)
    }
}

@Composable
fun NumpadPanel(bluetoothViewModel: BluetoothViewModel) {
    val keys = listOf(
        listOf("Num", "/", "*", "-"),
        listOf("7", "8", "9", "+"),
        listOf("4", "5", "6", "+"),
        listOf("1", "2", "3", "Ent"),
        listOf("0", "0", ".", "Ent")
    )
    
    val codes = mapOf(
        "Num" to 0x53, "/" to 0x54, "*" to 0x55, "-" to 0x56,
        "7" to 0x5F, "8" to 0x60, "9" to 0x61, "+" to 0x57,
        "4" to 0x5C, "5" to 0x5D, "6" to 0x5E,
        "1" to 0x59, "2" to 0x5A, "3" to 0x5B, "Ent" to 0x58,
        "0" to 0x62, "." to 0x63
    )

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        keys.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.distinct().forEach { key ->
                    val weight = row.count { it == key }.toFloat()
                    privateShortcutButton(key, modifier = Modifier.weight(weight).fillMaxHeight()) {
                        codes[key]?.let { bluetoothViewModel.sendKeyboardReportWithRelease(0, it.toByte()) }
                    }
                }
            }
        }
    }
}

@Composable
fun MediaPanel(bluetoothViewModel: BluetoothViewModel) {
    val keys = listOf(
        listOf("Prev" to 0x00B6, "Play/Pause" to 0x00CD, "Stop" to 0x00B7, "Next" to 0x00B5),
        listOf("Vol -" to 0x00EA, "Mute" to 0x00E2, "Vol +" to 0x00E9),
        listOf("Home" to 0x0223, "Back" to 0x0224, "Fwd" to 0x0225, "Refresh" to 0x0227),
        listOf("Search" to 0x0221, "Calc" to 0x0192, "Email" to 0x018A, "Browser" to 0x0196)
    )
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, code) ->
                    privateShortcutButton(label, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        bluetoothViewModel.sendMediaReport(code)
                    }
                }
            }
        }
    }
}

@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF3B7CA6))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
"""

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

