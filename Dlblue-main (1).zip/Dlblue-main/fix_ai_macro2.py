import re

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "r") as f:
    code = f.read()

old_code = """                                            "keypress" -> {
                                                bluetoothViewModel.sendKeyboardReport(
                                                    action.modifiers?.toByte() ?: 0,
                                                    action.keycode?.toByte() ?: 0
                                                )
                                                delay(50) // Small delay between key presses
                                            }"""

new_code = """                                            "keypress" -> {
                                                bluetoothViewModel.sendKeyboardReportWithRelease(
                                                    action.modifiers?.toByte() ?: 0,
                                                    action.keycode?.toByte() ?: 0
                                                )
                                                delay(50) // Small delay between key presses
                                            }"""

code = code.replace(old_code, new_code)

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "w") as f:
    f.write(code)
