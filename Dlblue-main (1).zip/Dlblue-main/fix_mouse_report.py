import re

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

# Change sendMouseReport signature and implementation
old_sig = "fun sendMouseReport(dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, wheel: Int) {"
new_sig = "fun sendMouseReport(dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) {"

# replace signature and implementation
code = re.sub(
    r'fun sendMouseReport\(dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, wheel: Int\) \{.*?hidDevice\?\.sendReport\(connectedDevice, 1, report\).*?\}',
    """fun sendMouseReport(dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean = false, wheel: Int = 0, hwheel: Int = 0) {
        if (connectedDevice == null || hidDevice == null) return
        var buttons = 0
        if (leftClick) buttons = buttons or 1
        if (rightClick) buttons = buttons or 2
        if (middleClick) buttons = buttons or 4
        
        val report = byteArrayOf(
            buttons.toByte(),
            dx.coerceIn(-127, 127).toByte(),
            dy.coerceIn(-127, 127).toByte(),
            wheel.coerceIn(-127, 127).toByte(),
            hwheel.coerceIn(-127, 127).toByte()
        )
        
        try {
            hidDevice?.sendReport(connectedDevice, 1, report)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send mouse report: ${e.message}")
        }
    }""",
    code, flags=re.DOTALL
)

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)

