import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

code = code.replace("""        TrackpadArea(
            modifier = Modifier.weight(1f),
            onMove = { dx, dy -> bluetoothViewModel.sendMouseReport(dx.toInt(), dy.toInt(), false, false, 0) },
            onClick = { bluetoothViewModel.sendMouseReport(0, 0, true, false, 0); bluetoothViewModel.sendMouseReport(0, 0, false, false, 0) },
            onScroll = { dy -> bluetoothViewModel.sendMouseReport(0, 0, false, false, (-dy / 10).toInt()) }
        )""", """        TrackpadArea(
            modifier = Modifier.weight(1f),
            onMove = { dx, dy -> bluetoothViewModel.sendMouseReport(dx, dy, false, false, 0) },
            onClick = { bluetoothViewModel.sendMouseReport(0, 0, true, false, 0); bluetoothViewModel.sendMouseReport(0, 0, false, false, 0) },
            onScroll = { wheel -> bluetoothViewModel.sendMouseReport(0, 0, false, false, wheel) }
        )""")

code = code.replace("""fun TrackpadArea(modifier: Modifier = Modifier, onMove: (Float, Float) -> Unit = { _, _ -> }, onClick: () -> Unit = {}, onScroll: (Float) -> Unit = {}) {""", """fun TrackpadArea(modifier: Modifier = Modifier, onMove: (Int, Int) -> Unit = { _, _ -> }, onClick: () -> Unit = {}, onScroll: (Int) -> Unit = {}) {""")

code = code.replace("""                .pointerInput(Unit) {
                    var isScrolling = false
                    detectDragGestures(
                        onDragStart = { offset ->
                            isScrolling = offset.x >= scrollThreshold
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            if (isScrolling) {
                                onScroll(dragAmount.y)
                            } else {
                                onMove(dragAmount.x, dragAmount.y)
                            }
                        }
                    )
                }""", """                .pointerInput(Unit) {
                    var isScrolling = false
                    var leftoverX = 0f
                    var leftoverY = 0f
                    var leftoverScroll = 0f
                    detectDragGestures(
                        onDragStart = { offset ->
                            isScrolling = offset.x >= scrollThreshold
                            leftoverX = 0f
                            leftoverY = 0f
                            leftoverScroll = 0f
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            if (isScrolling) {
                                leftoverScroll += dragAmount.y
                                val wheel = (-leftoverScroll / 10).toInt()
                                if (wheel != 0) {
                                    onScroll(wheel)
                                    leftoverScroll -= (-wheel * 10f)
                                }
                            } else {
                                leftoverX += dragAmount.x
                                leftoverY += dragAmount.y
                                val dx = leftoverX.toInt()
                                val dy = leftoverY.toInt()
                                if (dx != 0 || dy != 0) {
                                    onMove(dx, dy)
                                    leftoverX -= dx
                                    leftoverY -= dy
                                }
                            }
                        }
                    )
                }""")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

