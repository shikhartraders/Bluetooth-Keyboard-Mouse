import re

with open("app/src/main/java/com/example/ui/ShortcutsScreen.kt", "r") as f:
    code = f.read()

# Make ShortcutButton private or rename it. We will rename it in ShortcutsScreen to ManageShortcutButton.
code = code.replace("ShortcutButton(", "ManageShortcutButton(")
code = code.replace("fun ShortcutButton(", "fun ManageShortcutButton(")

with open("app/src/main/java/com/example/ui/ShortcutsScreen.kt", "w") as f:
    f.write(code)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()
code = code.replace("fun ShortcutButton(", "private fun ShortcutButton(")
with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

