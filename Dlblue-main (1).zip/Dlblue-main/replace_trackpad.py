import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

new_trackpad = """@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (Int, Int, Boolean, Boolean, Int) -> Unit = { _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {}
) {
    val trackpadColor = Color(0xFF004975)
    val iconColor = Color.White
    val view = LocalView.current
    
    var lastTapTime by remember { mutableStateOf(0L) }
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(trackpadColor)
            .pointerInput(Unit) {
                androidx.compose.foundation.gestures.awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startTime = System.currentTimeMillis()
                    var isTwoFingers = false
                    var isDragging = false
                    var moved = false
                    
                    var lastX = down.position.x
                    var lastY = down.position.y
                    var leftoverX = 0f
                    var leftoverY = 0f
                    
                    // Double tap to drag
                    if (startTime - lastTapTime < 250) {
                        isDragging = true
                        onReport(0, 0, true, false, 0) // Left click down
                    }
                    
                    do {
                        val event = awaitPointerEvent()
                        val pointers = event.changes
                        
                        if (pointers.size >= 2) {
                            isTwoFingers = true
                            val currentX = pointers[0].position.x
                            val currentY = pointers[0].position.y
                            val dx = currentX - lastX
                            val dy = currentY - lastY
                            if (kotlin.math.abs(dx) > 2f || kotlin.math.abs(dy) > 2f) moved = true
                            
                            leftoverY += dy
                            val wheel = -(leftoverY / 20f).toInt() // Smoother scrolling
                            if (wheel != 0) {
                                onReport(0, 0, false, false, wheel)
                                leftoverY += wheel * 20f
                            }
                            lastX = currentX
                            lastY = currentY
                        } else if (pointers.size == 1) {
                            val currentX = pointers[0].position.x
                            val currentY = pointers[0].position.y
                            val dx = currentX - lastX
                            val dy = currentY - lastY
                            
                            if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                            
                            val dist = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                            val accel = (dist / 10f).coerceIn(1.0f, 3.0f)
                            val baseSensitivity = 1.2f
                            
                            leftoverX += dx * baseSensitivity * accel
                            leftoverY += dy * baseSensitivity * accel
                            
                            val outX = leftoverX.toInt()
                            val outY = leftoverY.toInt()
                            
                            if (outX != 0 || outY != 0) {
                                onReport(outX, outY, isDragging, false, 0)
                                leftoverX -= outX
                                leftoverY -= outY
                            }
                            lastX = currentX
                            lastY = currentY
                        }
                        pointers.forEach { it.consume() }
                    } while (event.changes.any { it.pressed })
                    
                    val endTime = System.currentTimeMillis()
                    if (isDragging) {
                        onReport(0, 0, false, false, 0) // Release left click
                    } else if (!moved && endTime - startTime < 200) {
                        if (isTwoFingers) {
                            onRightClick()
                        } else {
                            lastTapTime = endTime
                            onClick()
                        }
                    }
                }
            }
    ) {
        Icon(
            imageVector = androidx.compose.material.icons.Icons.Default.Mouse,
            contentDescription = "Mouse",
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp),
            tint = iconColor.copy(alpha = 0.8f)
        )
    }
}
"""

# Replace TrackpadArea
code = re.sub(r'@Composable\s*fun TrackpadArea.*?\}\s*\}', new_trackpad, code, flags=re.DOTALL)

# Update MouseKeyboardScreen to use new TrackpadArea
new_trackpad_call = """        TrackpadArea(
            modifier = Modifier.weight(1f),
            onReport = { dx, dy, left, right, wheel ->
                bluetoothViewModel.sendMouseReport(dx, dy, left, right, wheel)
            },
            onClick = { bluetoothViewModel.sendMouseClick() },
            onRightClick = { bluetoothViewModel.sendRightMouseClick() }
        )"""
code = re.sub(r'        TrackpadArea\(.*?onScroll = \{.*?\}\s*\)', new_trackpad_call, code, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
