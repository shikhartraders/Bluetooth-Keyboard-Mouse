with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

split_str = "} \n else {"
if "} \n else {" not in code:
    split_str = "} \n else {"
    if split_str not in code:
        pass

# The regex replacement for TrackpadArea earlier missed removing some code. Let's find exactly what to remove.
# We will just parse the file and keep everything up to the first custom Shortcuts area, then append the rest cleanly.
