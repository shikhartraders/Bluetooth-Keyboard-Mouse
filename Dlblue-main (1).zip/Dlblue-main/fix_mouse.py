import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Lines 201 to 251 are orphaned code that shouldn't be there.
# Let's clean up the whole file structure starting from TrackpadArea.

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code.split("} \n else {")[0] + "\n")
