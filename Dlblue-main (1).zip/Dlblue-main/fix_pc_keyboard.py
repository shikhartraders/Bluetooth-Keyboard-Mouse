import re

with open("app/src/main/java/com/example/ui/PcKeyboardScreen.kt", "r") as f:
    code = f.read()

new_button_click = """
                            val keyCode = keyMap[key] ?: 0
                            var modifier: Byte = 0
                            var finalKeyCode = keyCode.toByte()
                            when (key) {
                                "Ctrl" -> { modifier = 0x01; finalKeyCode = 0 }
                                "Shift" -> { modifier = 0x02; finalKeyCode = 0 }
                                "Alt" -> { modifier = 0x04; finalKeyCode = 0 }
                                "Win" -> { modifier = 0x08; finalKeyCode = 0 }
                            }
                            if (finalKeyCode != 0.toByte() || modifier != 0.toByte()) {
                                bluetoothViewModel.sendKeyboardReportWithRelease(modifier, finalKeyCode)
                            }
"""

code = re.sub(
    r'val keyCode = keyMap\[key\] \?: 0\s+if \(keyCode != 0\) \{\s+bluetoothViewModel\.sendKeyboardReportWithRelease\(0, keyCode\.toByte\(\)\)\s+\}',
    new_button_click.strip(),
    code
)

with open("app/src/main/java/com/example/ui/PcKeyboardScreen.kt", "w") as f:
    f.write(code)
