import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    code = f.read()

code = re.sub(r'bluetoothViewModel\?\.sendMediaReport\(0x40\) // Volume Up', r'bluetoothViewModel?.sendMediaReport(0x00E9) // Volume Up', code)
code = re.sub(r'bluetoothViewModel\?\.sendMediaReport\(0x20\) // Volume Down', r'bluetoothViewModel?.sendMediaReport(0x00EA) // Volume Down', code)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(code)
