import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Let's add state for modifiers in FullKeyboardPanel
old_full = """fun FullKeyboardPanel(bluetoothViewModel: BluetoothViewModel) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {"""

new_full = """fun FullKeyboardPanel(bluetoothViewModel: BluetoothViewModel) {
    var activeModifiers by remember { mutableStateOf(0) }
    
    fun toggleModifier(mod: Int) {
        activeModifiers = activeModifiers xor mod
    }
    
    fun sendKey(key: Int) {
        bluetoothViewModel.sendKeyboardReportWithRelease(activeModifiers.toByte(), key.toByte())
        activeModifiers = 0 // Reset modifiers after a keypress
    }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {"""

if old_full in code:
    code = code.replace(old_full, new_full)
    print("Replaced FullKeyboardPanel start")
else:
    print("Could not find FullKeyboardPanel start")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
