import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Hoist activeModifiers to MouseKeyboardScreen
old_mouse = """fun MouseKeyboardScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel, showInputBar: Boolean = false) {
    Column("""
new_mouse = """fun MouseKeyboardScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel, showInputBar: Boolean = false) {
    var activeModifiers by remember { mutableStateOf(0) }
    
    fun toggleModifier(mod: Int) {
        activeModifiers = activeModifiers xor mod
    }
    
    fun resetModifiers() {
        activeModifiers = 0
    }
    
    Column("""

if old_mouse in code:
    code = code.replace(old_mouse, new_mouse)
    print("Replaced MouseKeyboardScreen")
else:
    print("Could not find MouseKeyboardScreen")

# Update TrackpadArea to pass modifiers? No.

# Update ControlPanels signature
old_control = """fun ControlPanels(bluetoothViewModel: BluetoothViewModel) {"""
new_control = """fun ControlPanels(bluetoothViewModel: BluetoothViewModel, activeModifiers: Int, toggleModifier: (Int) -> Unit, resetModifiers: () -> Unit) {"""
code = code.replace(old_control, new_control)

# Update ControlPanels call in MouseKeyboardScreen
old_call = """        ControlPanels(bluetoothViewModel)"""
new_call = """        ControlPanels(bluetoothViewModel, activeModifiers, ::toggleModifier, ::resetModifiers)"""
code = code.replace(old_call, new_call)

# Update FullKeyboardPanel signature
old_full = """fun FullKeyboardPanel(bluetoothViewModel: BluetoothViewModel) {
    var activeModifiers by remember { mutableStateOf(0) }
    
    fun toggleModifier(mod: Int) {
        activeModifiers = activeModifiers xor mod
    }
    
    fun sendKey(key: Int) {
        bluetoothViewModel.sendKeyboardReportWithRelease(activeModifiers.toByte(), key.toByte())
        activeModifiers = 0 // Reset modifiers after a keypress
    }"""
new_full = """fun FullKeyboardPanel(bluetoothViewModel: BluetoothViewModel, activeModifiers: Int, toggleModifier: (Int) -> Unit, resetModifiers: () -> Unit) {
    fun sendKey(key: Int) {
        bluetoothViewModel.sendKeyboardReportWithRelease(activeModifiers.toByte(), key.toByte())
        resetModifiers() // Reset modifiers after a keypress
    }"""
code = code.replace(old_full, new_full)

# Update FullKeyboardPanel call in ControlPanels
code = code.replace("0 -> FullKeyboardPanel(bluetoothViewModel)", "0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, toggleModifier, resetModifiers)")

# Update TextInputBar signature
old_text = """fun TextInputBar(bluetoothViewModel: BluetoothViewModel) {"""
new_text = """fun TextInputBar(bluetoothViewModel: BluetoothViewModel, activeModifiers: Int = 0, resetModifiers: () -> Unit = {}) {"""
code = code.replace(old_text, new_text)

# Update TextInputBar call in FullKeyboardPanel
code = code.replace("TextInputBar(bluetoothViewModel)", "TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)")

# Update TextInputBar onValueChange
old_onval = """                    added.forEach { c ->
                        charToHid(c)?.let { (mod, key) ->
                            bluetoothViewModel.sendKeyboardReportWithRelease(mod, key)
                        }
                    }"""
new_onval = """                    added.forEach { c ->
                        charToHid(c)?.let { (mod, key) ->
                            val combinedMod = (mod.toInt() or activeModifiers).toByte()
                            bluetoothViewModel.sendKeyboardReportWithRelease(combinedMod, key)
                            if (activeModifiers != 0) resetModifiers()
                        }
                    }"""
code = code.replace(old_onval, new_onval)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
