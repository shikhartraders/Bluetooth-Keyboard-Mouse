with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Fix newline
code = code.replace("'' -> Pair(0.toByte(), 0x28)", r"'\n' -> Pair(0.toByte(), 0x28)")
# Fix backslash
code = code.replace(r"    '\' -> Pair(0.toByte(), 0x31)", r"    '\\' -> Pair(0.toByte(), 0x31)")
# Fix quote
code = code.replace("''' -> Pair(0.toByte(), 0x34)", r"'\'' -> Pair(0.toByte(), 0x34)")

# Fix syntax error at end if there's any
# The compiler also said line 363 Expecting a top level declaration. Let's see if there is an extra bracket.
