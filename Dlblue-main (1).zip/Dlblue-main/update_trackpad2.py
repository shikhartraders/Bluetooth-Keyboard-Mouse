import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

new_pointer_input = """                .pointerInput(Unit) {
                    var isScrolling = false
                    var leftoverX = 0f
                    var leftoverY = 0f
                    var leftoverScroll = 0f
                    
                    // Acceleration factor for smooth and responsive movement
                    val baseSensitivity = 1.2f
                    val maxAcceleration = 2.5f

                    detectDragGestures(
                        onDragStart = { offset ->
                            isScrolling = offset.x >= scrollThreshold
                            leftoverX = 0f
                            leftoverY = 0f
                            leftoverScroll = 0f
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            
                            val dragMagnitude = kotlin.math.sqrt((dragAmount.x * dragAmount.x + dragAmount.y * dragAmount.y).toDouble()).toFloat()
                            
                            // Prevent accidental micro-triggers (jitter deadzone)
                            if (dragMagnitude < 0.3f) return@detectDragGestures

                            if (isScrolling) {
                                leftoverScroll += dragAmount.y
                                // Adjust scroll sensitivity
                                val wheel = (-leftoverScroll / 12).toInt() // Smoother scrolling
                                if (wheel != 0) {
                                    onScroll(wheel)
                                    leftoverScroll -= (-wheel * 12f)
                                }
                            } else {
                                // Apply smooth non-linear acceleration
                                val accelFactor = (dragMagnitude / 10f).coerceIn(1.0f, maxAcceleration)
                                val currentSensitivity = baseSensitivity * accelFactor
                                
                                leftoverX += dragAmount.x * currentSensitivity
                                leftoverY += dragAmount.y * currentSensitivity
                                
                                val dx = leftoverX.toInt()
                                val dy = leftoverY.toInt()
                                
                                if (dx != 0 || dy != 0) {
                                    onMove(dx, dy)
                                    leftoverX -= dx
                                    leftoverY -= dy
                                }
                            }
                        }
                    )
                }"""

# Need to replace the old pointerInput block
code = re.sub(r'\.pointerInput\(Unit\)\s*\{.*?\}\s*\)\s*\}\s*\)\s*\{\s*Icon\(', 
              new_pointer_input + "\n        ) {\n        Icon(", code, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
