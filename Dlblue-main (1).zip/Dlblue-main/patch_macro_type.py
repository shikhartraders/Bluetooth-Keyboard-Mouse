import re

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "r") as f:
    content = f.read()

# Add type_text to schema
old_schema = """                putJsonObject("action") {
                    put("type", "STRING")
                    put("description", "The action type: 'keypress' or 'delay'")
                }"""
new_schema = """                putJsonObject("action") {
                    put("type", "STRING")
                    put("description", "The action type: 'keypress', 'delay', or 'type_text'")
                }
                putJsonObject("text_to_type") {
                    put("type", "STRING")
                    put("description", "The text to type if action is 'type_text'.")
                }"""
if old_schema in content:
    content = content.replace(old_schema, new_schema)
    print("Replaced schema")

# Add text_to_type to MacroAction data class
old_dataclass = """data class MacroAction(
    val action: String,
    val keycode: Int? = null,
    val modifiers: Int? = null,
    val text: String? = null,
    val delayMs: Long? = null
)"""
new_dataclass = """data class MacroAction(
    val action: String,
    val keycode: Int? = null,
    val modifiers: Int? = null,
    val text: String? = null,
    val delayMs: Long? = null,
    val text_to_type: String? = null
)"""
if old_dataclass in content:
    content = content.replace(old_dataclass, new_dataclass)
    print("Replaced dataclass")

# Parse text_to_type
old_parse = """            val text = obj["text"]?.jsonPrimitive?.contentOrNull
            val delayMs = obj["delayMs"]?.jsonPrimitive?.contentOrNull?.toLongOrNull()
            
            actions.add(MacroAction(actionType, keycode, modifiers, text, delayMs))"""
new_parse = """            val text = obj["text"]?.jsonPrimitive?.contentOrNull
            val delayMs = obj["delayMs"]?.jsonPrimitive?.contentOrNull?.toLongOrNull()
            val text_to_type = obj["text_to_type"]?.jsonPrimitive?.contentOrNull
            
            actions.add(MacroAction(actionType, keycode, modifiers, text, delayMs, text_to_type))"""
if old_parse in content:
    content = content.replace(old_parse, new_parse)
    print("Replaced parse")

# UI update
old_ui = """                                if (action.action == "keypress") {
                                    Text(action.text ?: "keycode ${action.keycode}")
                                } else {
                                    Text("${action.delayMs} ms")
                                }"""
new_ui = """                                if (action.action == "keypress") {
                                    Text(action.text ?: "keycode ${action.keycode}")
                                } else if (action.action == "type_text") {
                                    Text(action.text_to_type ?: "")
                                } else {
                                    Text("${action.delayMs} ms")
                                }"""
if old_ui in content:
    content = content.replace(old_ui, new_ui)
    print("Replaced UI")

# System instruction update
old_inst = """5. Make sure text is broken down into individual keypresses with appropriate Shift modifier if capitalized."""
new_inst = """5. For typing out strings, URLs, or long text, use the 'type_text' action and put the string in 'text_to_type'. Use 'keypress' for specific shortcuts (like GUI+R, Enter, Esc)."""
if old_inst in content:
    content = content.replace(old_inst, new_inst)
    print("Replaced sys inst")

# Execution update
old_exec = """                                        when (action.action) {
                                            "delay" -> delay(action.delayMs ?: 500L)
                                            "keypress" -> {
                                                bluetoothViewModel.sendKeyboardReportWithRelease(
                                                    action.modifiers?.toByte() ?: 0,
                                                    action.keycode?.toByte() ?: 0
                                                )
                                                delay(100) // Small delay between key presses
                                            }
                                        }"""
new_exec = """                                        when (action.action) {
                                            "delay" -> delay(action.delayMs ?: 500L)
                                            "keypress" -> {
                                                bluetoothViewModel.sendKeyboardReportWithRelease(
                                                    action.modifiers?.toByte() ?: 0,
                                                    action.keycode?.toByte() ?: 0
                                                )
                                                delay(100) // Small delay between key presses
                                            }
                                            "type_text" -> {
                                                val str = action.text_to_type ?: ""
                                                for (char in str) {
                                                    var mod: Byte = 0
                                                    var kc: Byte = 0
                                                    when (char.lowercaseChar()) {
                                                        in 'a'..'z' -> kc = (char.lowercaseChar() - 'a' + 4).toByte()
                                                        in '1'..'9' -> kc = (char - '1' + 30).toByte()
                                                        '0' -> kc = 39.toByte()
                                                        ' ' -> kc = 44.toByte()
                                                        '-' -> kc = 45.toByte()
                                                        '=' -> kc = 46.toByte()
                                                        '[' -> kc = 47.toByte()
                                                        ']' -> kc = 48.toByte()
                                                        '\\\\' -> kc = 49.toByte()
                                                        ';' -> kc = 51.toByte()
                                                        '\\'' -> kc = 52.toByte()
                                                        '`' -> kc = 53.toByte()
                                                        ',' -> kc = 54.toByte()
                                                        '.' -> kc = 55.toByte()
                                                        '/' -> kc = 56.toByte()
                                                    }
                                                    if (char.isUpperCase() || char in listOf('!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '{', '}', '|', ':', '"', '<', '>', '?')) {
                                                        mod = 2 // Shift
                                                        if (char == '!') kc = 30.toByte()
                                                        if (char == '@') kc = 31.toByte()
                                                        if (char == '#') kc = 32.toByte()
                                                        if (char == '$') kc = 33.toByte()
                                                        if (char == '%') kc = 34.toByte()
                                                        if (char == '^') kc = 35.toByte()
                                                        if (char == '&') kc = 36.toByte()
                                                        if (char == '*') kc = 37.toByte()
                                                        if (char == '(') kc = 38.toByte()
                                                        if (char == ')') kc = 39.toByte()
                                                        if (char == '_') kc = 45.toByte()
                                                        if (char == '+') kc = 46.toByte()
                                                        if (char == '{') kc = 47.toByte()
                                                        if (char == '}') kc = 48.toByte()
                                                        if (char == '|') kc = 49.toByte()
                                                        if (char == ':') kc = 51.toByte()
                                                        if (char == '"') kc = 52.toByte()
                                                        if (char == '<') kc = 54.toByte()
                                                        if (char == '>') kc = 55.toByte()
                                                        if (char == '?') kc = 56.toByte()
                                                    }
                                                    if (kc > 0) {
                                                        bluetoothViewModel.sendKeyboardReportWithRelease(mod, kc)
                                                        delay(50)
                                                    }
                                                }
                                            }
                                        }"""
if old_exec in content:
    content = content.replace(old_exec, new_exec)
    print("Replaced exec")

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "w") as f:
    f.write(content)
