import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Fix syntax error caused by extra '}'
code = code.replace("""    fun sendKeyboardReport(modifier: Byte, keycode: Byte) {
        classicHidDevice?.sendKeyboardReport(modifier, keycode)
    }
    }

    fun sendKeyboardReportWithRelease(modifier: Byte, keycode: Byte) {""", """    fun sendKeyboardReport(modifier: Byte, keycode: Byte) {
        classicHidDevice?.sendKeyboardReport(modifier, keycode)
    }

    fun sendKeyboardReportWithRelease(modifier: Byte, keycode: Byte) {""")

# Make sure the class isn't closed too early
code = re.sub(
    r'(\s*classicHidDevice\?\.sendMouseReport\(0, 0, false, false, 0\)\s*\})\s*\}(\s*\})',
    r'\1\2',
    code
)

# And that enum class is at the end properly
with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)

