import re

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

# Replace sendMouseReport
code = re.sub(
    r'hidDevice\?\.sendReport\(connectedDevice, \d+, report\)\s*\} catch \(e: Exception\) \{\s*Log\.e\(TAG, "Failed to send mouse report',
    r'hidDevice?.sendReport(connectedDevice, 2, report)\n        } catch (e: Exception) {\n            Log.e(TAG, "Failed to send mouse report', code)

# Replace sendKeyboardReport
code = re.sub(
    r'hidDevice\?\.sendReport\(connectedDevice, \d+, report\)\s*\} catch \(e: Exception\) \{\s*Log\.e\(TAG, "Failed to send keyboard report',
    r'hidDevice?.sendReport(connectedDevice, 1, report)\n        } catch (e: Exception) {\n            Log.e(TAG, "Failed to send keyboard report', code)

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)
