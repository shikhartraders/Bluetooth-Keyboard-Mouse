with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Add missing @Composable for TextInputBar
code = code.replace("fun TextInputBar", "@Composable\nfun TextInputBar")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
