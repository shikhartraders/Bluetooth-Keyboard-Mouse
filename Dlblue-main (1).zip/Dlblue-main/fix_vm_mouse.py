import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

code = re.sub(
    r'fun sendMouseReport\(dx: Int, dy: Int, leftClick: Boolean = false, rightClick: Boolean = false, wheel: Int = 0\) \{.*?\}',
    """fun sendMouseReport(dx: Int, dy: Int, leftClick: Boolean = false, rightClick: Boolean = false, middleClick: Boolean = false, wheel: Int = 0, hwheel: Int = 0) {
        classicHidDevice?.sendMouseReport(dx, dy, leftClick, rightClick, middleClick, wheel, hwheel)
    }""",
    code, flags=re.DOTALL
)

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)

