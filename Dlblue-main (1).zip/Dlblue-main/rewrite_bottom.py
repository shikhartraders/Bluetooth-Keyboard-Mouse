import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# I will replace CustomShortcutsArea and TextInputBar entirely.
# First, let's inject a new Composable called ControlPanels
# It will have Tabs for "Keyboard", "Numpad", "Media"

control_panels = """
@Composable
fun ControlPanels(bluetoothViewModel: BluetoothViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Keyboard", "Numpad", "Media")
    
    Column(modifier = Modifier.fillMaxWidth().height(250.dp)) {
        TabRow(selectedTabIndex = selectedTab, containerColor = Color.Transparent) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold) }
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                0 -> FullKeyboardPanel(bluetoothViewModel)
                1 -> NumpadPanel(bluetoothViewModel)
                2 -> MediaPanel(bluetoothViewModel)
            }
        }
    }
}

@Composable
fun FullKeyboardPanel(bluetoothViewModel: BluetoothViewModel) {
    // Basic implementation of requested keys. For brevity, grouping them.
    // In a real app this would be a complex grid or custom input method.
    // We will provide a grid of common keys and a text field for typing.
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Esc", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29) }
            privateShortcutButton("Tab", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2B) }
            privateShortcutButton("Caps", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x39) }
            privateShortcutButton("Shift", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x02, 0) }
            privateShortcutButton("Ctrl", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0) }
            privateShortcutButton("Alt", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x04, 0) }
            privateShortcutButton("Win", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x08, 0) }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("F1", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3A) }
            privateShortcutButton("F2", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3B) }
            privateShortcutButton("F3", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3C) }
            privateShortcutButton("F4", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3D) }
            privateShortcutButton("F5", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3E) }
            privateShortcutButton("PrtSc", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x46) }
            privateShortcutButton("Ins", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x49) }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Home", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4A) }
            privateShortcutButton("End", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4D) }
            privateShortcutButton("PgUp", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4B) }
            privateShortcutButton("PgDn", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4E) }
            privateShortcutButton("Del", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4C) }
            privateShortcutButton("Bksp", modifier = Modifier.weight(1.5f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2A) }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Space", modifier = Modifier.weight(2f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2C) }
            privateShortcutButton("Enter", modifier = Modifier.weight(1.5f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x28) }
            privateShortcutButton("↑", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x52) }
            privateShortcutButton("↓", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x51) }
            privateShortcutButton("←", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) }
            privateShortcutButton("→", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) }
        }
        Spacer(modifier = Modifier.height(4.dp))
        TextInputBar(bluetoothViewModel)
    }
}

@Composable
fun NumpadPanel(bluetoothViewModel: BluetoothViewModel) {
    val keys = listOf(
        listOf("Num", "/", "*", "-"),
        listOf("7", "8", "9", "+"),
        listOf("4", "5", "6", "+"),
        listOf("1", "2", "3", "Ent"),
        listOf("0", "0", ".", "Ent")
    )
    
    val codes = mapOf(
        "Num" to 0x53, "/" to 0x54, "*" to 0x55, "-" to 0x56,
        "7" to 0x5F, "8" to 0x60, "9" to 0x61, "+" to 0x57,
        "4" to 0x5C, "5" to 0x5D, "6" to 0x5E,
        "1" to 0x59, "2" to 0x5A, "3" to 0x5B, "Ent" to 0x58,
        "0" to 0x62, "." to 0x63
    )

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        keys.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.distinct().forEach { key ->
                    val weight = row.count { it == key }.toFloat()
                    privateShortcutButton(key, modifier = Modifier.weight(weight).fillMaxHeight()) {
                        codes[key]?.let { bluetoothViewModel.sendKeyboardReportWithRelease(0, it.toByte()) }
                    }
                }
            }
        }
    }
}

@Composable
fun MediaPanel(bluetoothViewModel: BluetoothViewModel) {
    val keys = listOf(
        listOf("Prev" to 0x00B6, "Play/Pause" to 0x00CD, "Stop" to 0x00B7, "Next" to 0x00B5),
        listOf("Vol -" to 0x00EA, "Mute" to 0x00E2, "Vol +" to 0x00E9),
        listOf("Home" to 0x0223, "Back" to 0x0224, "Fwd" to 0x0225, "Refresh" to 0x0227),
        listOf("Search" to 0x0221, "Calc" to 0x0192, "Email" to 0x018A, "Browser" to 0x0196)
    )
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, code) ->
                    privateShortcutButton(label, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        bluetoothViewModel.sendMediaReport(code)
                    }
                }
            }
        }
    }
}
"""

# add TabRow imports
code = "import androidx.compose.material3.TabRow\nimport androidx.compose.material3.Tab\n" + code

# Replace the Mouse buttons with a 3 button layout (Left, Middle, Right)
mouse_buttons_old = """        // Mouse Buttons (Left, Right)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MouseClickButton(
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendMouseClick() }
            )
            MouseClickButton(
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendRightMouseClick() }
            )
        }"""
        
mouse_buttons_new = """        // Mouse Buttons (Left, Middle, Right)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MouseClickButton(
                text = "L",
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendMouseClick() }
            )
            MouseClickButton(
                text = "M",
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { 
                    bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                    bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
                }
            )
            MouseClickButton(
                text = "R",
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendRightMouseClick() }
            )
        }"""
        
code = code.replace(mouse_buttons_old, mouse_buttons_new)

# Modify MouseClickButton to take text
code = re.sub(
    r'@Composable\s*fun MouseClickButton\(modifier: Modifier = Modifier, onClick: \(\) -> Unit = \{\}\) \{.*?\}',
    """@Composable
fun MouseClickButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF3B7CA6))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    }
}""",
    code, flags=re.DOTALL
)

# replace CustomShortcutsArea call and TextInputBar call
code = re.sub(r'CustomShortcutsArea\(bluetoothViewModel\).*?if \(showInputBar\) \{.*?TextInputBar\(bluetoothViewModel\).*?\}', 'ControlPanels(bluetoothViewModel)', code, flags=re.DOTALL)

# Delete CustomShortcutsArea function
code = re.sub(r'@Composable\s*fun CustomShortcutsArea.*?\}', '', code, flags=re.DOTALL)

code += "\n" + control_panels

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
