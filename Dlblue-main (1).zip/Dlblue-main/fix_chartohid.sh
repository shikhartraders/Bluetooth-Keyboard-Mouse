# First remove everything between fun charToHid and else -> null
awk '
/fun charToHid/ {
    print "    fun charToHid(c: Char): Pair<Byte, Byte>? {"
    print "        val shift: Byte = 0x02"
    print "        return when (c) {"
    print "            in \x27a\x27..\x27z\x27 -> Pair(0.toByte(), (c - \x27a\x27 + 0x04).toByte())"
    print "            in \x27A\x27..\x27Z\x27 -> Pair(shift, (c - \x27A\x27 + 0x04).toByte())"
    print "            in \x271\x27..\x279\x27 -> Pair(0.toByte(), (c - \x271\x27 + 0x1E).toByte())"
    print "            \x270\x27 -> Pair(0.toByte(), 0x27)"
    print "            \x27 \x27 -> Pair(0.toByte(), 0x2C)"
    print "            \x27\\n\x27 -> Pair(0.toByte(), 0x28)"
    print "            \x27-\x27 -> Pair(0.toByte(), 0x2D)"
    print "            \x27=\x27 -> Pair(0.toByte(), 0x2E)"
    print "            \x27[\x27 -> Pair(0.toByte(), 0x2F)"
    print "            \x27]\x27 -> Pair(0.toByte(), 0x30)"
    print "            \x27\\\\\x27 -> Pair(0.toByte(), 0x31)"
    print "            \x27;\x27 -> Pair(0.toByte(), 0x33)"
    print "            \x27\\\'\x27 -> Pair(0.toByte(), 0x34)"
    print "            \x27`\x27 -> Pair(0.toByte(), 0x35)"
    print "            \x27,\x27 -> Pair(0.toByte(), 0x36)"
    print "            \x27.\x27 -> Pair(0.toByte(), 0x37)"
    print "            \x27/\x27 -> Pair(0.toByte(), 0x38)"
    print "            \x27!\x27 -> Pair(shift, 0x1E)"
    print "            \x27@\x27 -> Pair(shift, 0x1F)"
    print "            \x27#\x27 -> Pair(shift, 0x20)"
    print "            \x27$\x27 -> Pair(shift, 0x21)"
    print "            \x27%\x27 -> Pair(shift, 0x22)"
    print "            \x27^\x27 -> Pair(shift, 0x23)"
    print "            \x27&\x27 -> Pair(shift, 0x24)"
    print "            \x27*\x27 -> Pair(shift, 0x25)"
    print "            \x27(\x27 -> Pair(shift, 0x26)"
    print "            \x27)\x27 -> Pair(shift, 0x27)"
    print "            \x27_\x27 -> Pair(shift, 0x2D)"
    print "            \x27+\x27 -> Pair(shift, 0x2E)"
    print "            \x27{\x27 -> Pair(shift, 0x2F)"
    print "            \x27}\x27 -> Pair(shift, 0x30)"
    print "            \x27|\x27 -> Pair(shift, 0x31)"
    print "            \x27:\x27 -> Pair(shift, 0x33)"
    print "            \x27\"\x27 -> Pair(shift, 0x34)"
    print "            \x27~\x27 -> Pair(shift, 0x35)"
    print "            \x27<\x27 -> Pair(shift, 0x36)"
    print "            \x27>\x27 -> Pair(shift, 0x37)"
    print "            \x27?\x27 -> Pair(shift, 0x38)"
    print "            else -> null"
    print "        }"
    print "    }"
    in_block = 1
    next
}
/else -> null/ && in_block {
    # Skip until we see the closing braces for charToHid
    getline
    getline
    in_block = 0
    next
}
!in_block { print }
' app/src/main/java/com/example/ui/MouseKeyboardScreen.kt > temp.kt

mv temp.kt app/src/main/java/com/example/ui/MouseKeyboardScreen.kt
