def analyze_webp(filename):
    # Just output it as base64 so I can decode it locally or use a tool.
    pass
