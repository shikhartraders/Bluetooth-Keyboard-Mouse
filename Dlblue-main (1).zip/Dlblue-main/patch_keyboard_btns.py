import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

old_btn = """fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = context.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
    val hapticEnabled = prefs.getBoolean("touchVibrations", true)
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF558AB2))
            .clickable { """

new_btn = """fun privateShortcutButton(text: String, modifier: Modifier = Modifier, isActive: Boolean = false, onClick: () -> Unit = {}) {
    val view = LocalView.current
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = context.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
    val hapticEnabled = prefs.getBoolean("touchVibrations", true)
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isActive) Color(0xFF005080) else Color(0xFF558AB2))
            .clickable { """

if old_btn in code:
    code = code.replace(old_btn, new_btn)
    print("Replaced privateShortcutButton")
else:
    print("Could not find privateShortcutButton")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
