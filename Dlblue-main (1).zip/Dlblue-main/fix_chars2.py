import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "''' -> Pair(0.toByte(), 0x34)" in line:
        lines[i] = "            '\\'' -> Pair(0.toByte(), 0x34)\n"
    if "'\\' -> Pair(0.toByte(), 0x31)" in line:
        lines[i] = "            '\\\\' -> Pair(0.toByte(), 0x31)\n"

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.writelines(lines)
