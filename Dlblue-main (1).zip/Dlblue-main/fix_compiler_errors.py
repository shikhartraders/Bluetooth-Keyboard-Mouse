import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if line.startswith("fun privateShortcutButton") and i < 100:
        # Skip the duplicate at line 86
        skip = True
    
    if skip:
        if line.strip() == "}":
            # wait, privateShortcutButton might be multi-line. Let's see how many lines it is.
            # Actually, I know it was at line 86.
            pass
        
with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Replace the first instance of privateShortcutButton that is near line 86
# But wait, it's safer to just delete from line 85 to 101 or something.
