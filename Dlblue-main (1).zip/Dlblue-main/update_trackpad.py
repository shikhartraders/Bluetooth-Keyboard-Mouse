import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

new_pointer_input = """                .pointerInput(Unit) {
                    var isScrolling = false
                    var leftoverX = 0f
                    var leftoverY = 0f
                    var leftoverScroll = 0f
                    
                    // Acceleration factor for smooth and responsive movement
                    val sensitivity = 1.5f
                    val acceleration = 1.2f

                    detectDragGestures(
                        onDragStart = { offset ->
                            isScrolling = offset.x >= scrollThreshold
                            leftoverX = 0f
                            leftoverY = 0f
                            leftoverScroll = 0f
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            if (isScrolling) {
                                leftoverScroll += dragAmount.y
                                // Adjust scroll sensitivity
                                val wheel = (-leftoverScroll / 8).toInt()
                                if (wheel != 0) {
                                    onScroll(wheel)
                                    leftoverScroll -= (-wheel * 8f)
                                }
                            } else {
                                // Apply acceleration based on drag velocity/magnitude
                                val dragMagnitude = kotlin.math.sqrt((dragAmount.x * dragAmount.x + dragAmount.y * dragAmount.y).toDouble()).toFloat()
                                val currentAccel = if (dragMagnitude > 10f) acceleration else 1.0f
                                
                                leftoverX += dragAmount.x * sensitivity * currentAccel
                                leftoverY += dragAmount.y * sensitivity * currentAccel
                                
                                val dx = leftoverX.toInt()
                                val dy = leftoverY.toInt()
                                
                                if (dx != 0 || dy != 0) {
                                    onMove(dx, dy)
                                    leftoverX -= dx
                                    leftoverY -= dy
                                }
                            }
                        }
                    )
                }"""

# Need to replace the old pointerInput block
code = re.sub(r'\.pointerInput\(Unit\)\s*\{.*?\}\s*\)\s*\}\s*\)\s*\{\s*Icon\(', 
              new_pointer_input + "\n        ) {\n        Icon(", code, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
