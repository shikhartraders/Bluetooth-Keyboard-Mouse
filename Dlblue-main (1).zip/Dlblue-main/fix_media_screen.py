import re

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()

# Replace previous button values
# Volume Down
code = code.replace("bluetoothViewModel.sendMediaReport(0x20)", "bluetoothViewModel.sendMediaReport(0xEA)")
# Mute
code = code.replace("bluetoothViewModel.sendMediaReport(0x10)", "bluetoothViewModel.sendMediaReport(0xE2)")
# Volume Up
code = code.replace("bluetoothViewModel.sendMediaReport(0x40)", "bluetoothViewModel.sendMediaReport(0xE9)")
# SkipPrevious (FastRewind usually shares this in simple layouts, or use 0xB6)
code = code.replace("Icons.Default.SkipPrevious, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0x02)", "Icons.Default.SkipPrevious, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB6)")
# SkipNext
code = code.replace("Icons.Default.SkipNext, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0x01)", "Icons.Default.SkipNext, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB5)")
# FastRewind -> we will map it to Prev as well or maybe Search? Let's just use B6 for rew and B5 for fwd
code = code.replace("Icons.Default.FastRewind, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0x02)", "Icons.Default.FastRewind, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB6)")
code = code.replace("Icons.Default.FastForward, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0x01)", "Icons.Default.FastForward, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB5)")
# Play/Pause
code = code.replace("bluetoothViewModel.sendMediaReport(0x08)", "bluetoothViewModel.sendMediaReport(0xCD)")

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "w") as f:
    f.write(code)
