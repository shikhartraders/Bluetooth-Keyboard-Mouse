import re

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "r") as f:
    code = f.read()

# Pass bluetoothViewModel to DisplaySettingsTab
code = code.replace("3 -> DisplaySettingsTab()", "3 -> DisplaySettingsTab(bluetoothViewModel)")
code = code.replace("fun DisplaySettingsTab() {", "fun DisplaySettingsTab(bluetoothViewModel: BluetoothViewModel) {")

# Update Touch vibrations switch
code = code.replace("SettingsSwitchRow(\"Touch vibrations\", true)",
                    "SettingsSwitchRow(\"Touch vibrations\", checked = bluetoothViewModel.touchVibrations.value, onCheckedChange = { bluetoothViewModel.setTouchVibrations(it) })")

# Change SettingsSwitchRow definition
code = code.replace("fun SettingsSwitchRow(title: String, initialChecked: Boolean) {\n    var checked by remember { mutableStateOf(initialChecked) }",
                    "fun SettingsSwitchRow(title: String, checked: Boolean = false, onCheckedChange: (Boolean) -> Unit = {}) {\n")

# Need to update other uses of SettingsSwitchRow to pass checked/onCheckedChange if they don't already?
# No, wait, they only passed `initialChecked: Boolean` before. Now they pass `checked` as positional. But they didn't have a state! They will just be static if I don't use a local state.
# Let's fix SettingsSwitchRow to support both, or just change all to local state if onCheckedChange is empty?
# Better yet, let's redefine it properly.
