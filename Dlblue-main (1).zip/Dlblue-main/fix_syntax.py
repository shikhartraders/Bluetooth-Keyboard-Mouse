import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

code = code.replace(".androidx.compose.ui.input.pointer.pointerInteropFilter", ".pointerInteropFilter")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
