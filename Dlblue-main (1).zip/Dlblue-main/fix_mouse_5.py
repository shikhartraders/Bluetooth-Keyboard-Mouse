import re
with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Fix awaitEachGesture and awaitFirstDown
code = code.replace("androidx.compose.foundation.gestures.awaitEachGesture {", "awaitPointerEventScope {\n                    while(true) {")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
