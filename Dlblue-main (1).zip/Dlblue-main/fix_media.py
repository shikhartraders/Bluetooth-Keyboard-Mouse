import re

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

# Replace Consumer Control descriptor
old_consumer = """        // Consumer Control
        0x05, 0x0C, // Usage Page (Consumer)
        0x09, 0x01, // Usage (Consumer Control)
        0xA1.toByte(), 0x01, // Collection (Application)
        0x85.toByte(), 0x03, // Report Id (3)
        0x15, 0x00, // Logical Minimum (0)
        0x25, 0x01, // Logical Maximum (1)
        0x75, 0x01, // Report Size (1)
        0x95.toByte(), 0x07, // Report Count (7)
        0x09, 0xB5.toByte(), // Usage (Scan Next Track)
        0x09, 0xB6.toByte(), // Usage (Scan Previous Track)
        0x09, 0xB7.toByte(), // Usage (Stop)
        0x09, 0xCD.toByte(), // Usage (Play/Pause)
        0x09, 0xE2.toByte(), // Usage (Mute)
        0x09, 0xEA.toByte(), // Usage (Volume Down)
        0x09, 0xE9.toByte(), // Usage (Volume Up)
        0x81.toByte(), 0x02, // Input (Data, Variable, Absolute)
        0x95.toByte(), 0x01, // Report Count (1)
        0x75, 0x01, // Report Size (1)
        0x81.toByte(), 0x03, // Input (Constant) - Padding bit
        0xC0.toByte() // End Collection"""

new_consumer = """        // Consumer Control
        0x05, 0x0C, // Usage Page (Consumer)
        0x09, 0x01, // Usage (Consumer Control)
        0xA1.toByte(), 0x01, // Collection (Application)
        0x85.toByte(), 0x03, // Report Id (3)
        0x15, 0x00, // Logical Minimum (0)
        0x26, 0xFF.toByte(), 0x03, // Logical Maximum (0x03FF)
        0x19, 0x00, // Usage Minimum (0)
        0x2A, 0xFF.toByte(), 0x03, // Usage Maximum (0x03FF)
        0x75, 0x10, // Report Size (16 bits)
        0x95.toByte(), 0x01, // Report Count (1)
        0x81.toByte(), 0x00, // Input (Data, Array, Absolute)
        0xC0.toByte() // End Collection"""

code = code.replace(old_consumer, new_consumer)

# Replace sendMediaReport
old_send = """    fun sendMediaReport(key: Int) {
        if (connectedDevice == null || hidDevice == null) return
        
        val report = byteArrayOf(key.toByte())
        
        try {
            hidDevice?.sendReport(connectedDevice, 3, report)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send media report: ${e.message}")
        }
    }"""

new_send = """    fun sendMediaReport(key: Int) {
        if (connectedDevice == null || hidDevice == null) return
        
        val report = byteArrayOf(
            (key and 0xFF).toByte(),
            ((key shr 8) and 0xFF).toByte()
        )
        
        try {
            hidDevice?.sendReport(connectedDevice, 3, report)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send media report: ${e.message}")
        }
    }"""

code = code.replace(old_send, new_send)

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)
