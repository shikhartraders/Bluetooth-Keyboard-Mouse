import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# I will find all instances of @Composable fun privateShortcutButton and keep only one.
parts = code.split("@Composable\nfun privateShortcutButton")
if len(parts) > 2:
    # There are multiple
    new_code = parts[0] + "@Composable\nfun privateShortcutButton" + parts[1]
    with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
        f.write(new_code)
