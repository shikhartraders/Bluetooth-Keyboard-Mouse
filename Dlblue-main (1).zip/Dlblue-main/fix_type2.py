import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Fix the references to variables aren't supported yet error
# Kotlin doesn't like passing local functions like `::resetModifiers` or `toggleModifier` if they capture local vars.
# Wait, the error is: `Argument type mismatch: actual type is 'Unit', but 'Function0<Unit>' was expected.`
# And: `Function invocation 'resetModifiers()' expected.`
# And earlier: `References to variables aren't supported yet`

old_control_call = """        ControlPanels(bluetoothViewModel, activeModifiers, ::toggleModifier, ::resetModifiers)"""
new_control_call = """        ControlPanels(bluetoothViewModel, activeModifiers, { toggleModifier(it) }, { resetModifiers() })"""
code = code.replace(old_control_call, new_control_call)

old_full_call = """0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, toggleModifier, resetModifiers)"""
new_full_call = """0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, toggleModifier, resetModifiers)"""

old_text_call = """        TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)"""
new_text_call = """        TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)"""

old_call1 = """TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)"""
new_call1 = """TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)"""
# wait what line is 116?
# Ah:
code = code.replace("TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers())", "TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)")
code = code.replace("TextInputBar(bluetoothViewModel, activeModifiers, ::resetModifiers)", "TextInputBar(bluetoothViewModel, activeModifiers, { resetModifiers() })")
code = code.replace("TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)", "TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)") # ?

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
