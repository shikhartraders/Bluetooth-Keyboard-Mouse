with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    lines = f.readlines()

# find end of TrackpadArea
for i in range(len(lines)):
    if "fun CustomShortcutsArea" in lines[i]:
        lines.insert(i-1, "    }\n")
        break

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.writelines(lines)
