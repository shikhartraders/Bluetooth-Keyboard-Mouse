import re
with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Remove second MouseClickButton
parts = code.split("fun MouseClickButton")
if len(parts) > 2:
    # re-assemble without the last one
    new_code = parts[0] + "fun MouseClickButton" + parts[1]
    
    # Actually, parts[2] contains the body of the second MouseClickButton, up to the next @Composable
    # Let's use regex
    new_code = re.sub(r'@Composable\s*fun MouseClickButton.*?\{\s*\}\s*\}', '', code, flags=re.DOTALL)
    
    with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
        f.write(new_code)
