import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Add invertScroll state
if "val invertScroll" not in code:
    code = code.replace("val touchVibrations = androidx.compose.runtime.mutableStateOf(prefs.getBoolean(\"touchVibrations\", true))",
                        "val touchVibrations = androidx.compose.runtime.mutableStateOf(prefs.getBoolean(\"touchVibrations\", true))\n    val invertScroll = androidx.compose.runtime.mutableStateOf(prefs.getBoolean(\"invertScroll\", true))\n    fun setInvertScroll(enabled: Boolean) {\n        invertScroll.value = enabled\n        prefs.edit().putBoolean(\"invertScroll\", enabled).apply()\n    }")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "r") as f:
    code = f.read()

# Replace "Scroll bar" -> "Natural scrolling (Invert)"
code = code.replace("SettingsItemRow(\"Scroll bar\", \"Default\")",
                    "SettingsSwitchRow(\"Natural scrolling (Reverse direction)\", checked = bluetoothViewModel.invertScroll.value, onCheckedChange = { bluetoothViewModel.setInvertScroll(it) })")

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "w") as f:
    f.write(code)
