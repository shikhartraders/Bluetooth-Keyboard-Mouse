with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    code = f.read()

code = code.replace("override fun dispatchKeyEvent", '@android.annotation.SuppressLint("RestrictedApi")\n    override fun dispatchKeyEvent')

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(code)
