import re
with open("app/build.gradle.kts", "r") as f:
    code = f.read()

code = code.replace("implementation(libs.androidx.core.ktx)", "implementation(libs.androidx.core.ktx)\n    implementation(libs.androidx.core.splashscreen)")

with open("app/build.gradle.kts", "w") as f:
    f.write(code)
