import re

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

# Replace reportMap
report_map_new = """    private val reportMap = byteArrayOf(
        // Keyboard (Report ID 1)
        0x05, 0x01, // Usage Page (Generic Desktop)
        0x09, 0x06, // Usage (Keyboard)
        0xA1.toByte(), 0x01, // Collection (Application)
        0x85.toByte(), 0x01, // Report Id (1)
        // Modifiers
        0x05, 0x07, // Usage Page (Key Codes)
        0x19, 0xE0.toByte(), // Usage Minimum (224)
        0x29, 0xE7.toByte(), // Usage Maximum (231)
        0x15, 0x00, // Logical Minimum (0)
        0x25, 0x01, // Logical Maximum (1)
        0x75, 0x01, // Report Size (1)
        0x95.toByte(), 0x08, // Report Count (8)
        0x81.toByte(), 0x02, // Input (Data, Variable, Absolute)
        // Reserved byte
        0x95.toByte(), 0x01, // Report Count (1)
        0x75, 0x08, // Report Size (8)
        0x81.toByte(), 0x01, // Input (Constant)
        // LED report (Output)
        0x95.toByte(), 0x05, // Report Count (5)
        0x75, 0x01, // Report Size (1)
        0x05, 0x08, // Usage Page (LEDs)
        0x19, 0x01, // Usage Minimum (1)
        0x29, 0x05, // Usage Maximum (5)
        0x91.toByte(), 0x02, // Output (Data, Variable, Absolute)
        0x95.toByte(), 0x01, // Report Count (1)
        0x75, 0x03, // Report Size (3)
        0x91.toByte(), 0x01, // Output (Constant)
        // Key arrays (6 bytes)
        0x95.toByte(), 0x06, // Report Count (6)
        0x75, 0x08, // Report Size (8)
        0x15, 0x00, // Logical Minimum (0)
        0x26, 0xFF.toByte(), 0x00, // Logical Maximum (255)
        0x05, 0x07, // Usage Page (Key Codes)
        0x19, 0x00, // Usage Minimum (0)
        0x29, 0xFF.toByte(), // Usage Maximum (255)
        0x81.toByte(), 0x00, // Input (Data, Array)
        0xC0.toByte(), // End Collection

        // Mouse (Report ID 2)
        0x05, 0x01, // Usage Page (Generic Desktop)
        0x09, 0x02, // Usage (Mouse)
        0xA1.toByte(), 0x01, // Collection (Application)
        0x85.toByte(), 0x02, // Report Id (2)
        0x09, 0x01, // Usage (Pointer)
        0xA1.toByte(), 0x00, // Collection (Physical)
        // Buttons
        0x05, 0x09, // Usage Page (Button)
        0x19, 0x01, // Usage Minimum (Button 1)
        0x29, 0x05, // Usage Maximum (Button 5)
        0x15, 0x00, // Logical Minimum (0)
        0x25, 0x01, // Logical Maximum (1)
        0x95.toByte(), 0x05, // Report Count (5)
        0x75, 0x01, // Report Size (1)
        0x81.toByte(), 0x02, // Input (Data, Variable, Absolute)
        // Padding
        0x95.toByte(), 0x01, // Report Count (1)
        0x75, 0x03, // Report Size (3)
        0x81.toByte(), 0x03, // Input (Constant)
        // X, Y
        0x05, 0x01, // Usage Page (Generic Desktop)
        0x09, 0x30, // Usage (X)
        0x09, 0x31, // Usage (Y)
        0x15, 0x81.toByte(), // Logical Minimum (-127)
        0x25, 0x7F, // Logical Maximum (127)
        0x75, 0x08, // Report Size (8)
        0x95.toByte(), 0x02, // Report Count (2)
        0x81.toByte(), 0x06, // Input (Data, Variable, Relative)
        // Vertical Wheel
        0x09, 0x38, // Usage (Wheel)
        0x15, 0x81.toByte(), // Logical Minimum (-127)
        0x25, 0x7F, // Logical Maximum (127)
        0x75, 0x08, // Report Size (8)
        0x95.toByte(), 0x01, // Report Count (1)
        0x81.toByte(), 0x06, // Input (Data, Variable, Relative)
        // Horizontal Wheel
        0x05, 0x0C, // Usage Page (Consumer)
        0x0A, 0x38, 0x02, // Usage (AC Pan)
        0x15, 0x81.toByte(), // Logical Minimum (-127)
        0x25, 0x7F, // Logical Maximum (127)
        0x75, 0x08, // Report Size (8)
        0x95.toByte(), 0x01, // Report Count (1)
        0x81.toByte(), 0x06, // Input (Data, Variable, Relative)
        0xC0.toByte(), // End Collection
        0xC0.toByte(), // End Collection

        // Consumer Control (Report ID 3)
        0x05, 0x0C, // Usage Page (Consumer)
        0x09, 0x01, // Usage (Consumer Control)
        0xA1.toByte(), 0x01, // Collection (Application)
        0x85.toByte(), 0x03, // Report Id (3)
        0x15, 0x00, // Logical Minimum (0)
        0x26, 0xFF.toByte(), 0x03, // Logical Maximum (0x03FF)
        0x19, 0x00, // Usage Minimum (0)
        0x2A, 0xFF.toByte(), 0x03, // Usage Maximum (0x03FF)
        0x75, 0x10, // Report Size (16 bits)
        0x95.toByte(), 0x01, // Report Count (1)
        0x81.toByte(), 0x00, // Input (Data, Array, Absolute)
        0xC0.toByte() // End Collection
    )"""

code = re.sub(r'    private val reportMap = byteArrayOf\([\s\S]*?\)\s*private val callback', report_map_new + "\n\n    private val callback", code)

# Update the send report methods to match the new Report IDs
# Keyboard is now Report Id (1), Mouse is Report Id (2)

code = re.sub(r'hidDevice\?\.sendReport\(connectedDevice, 1, report\)', r'hidDevice?.sendReport(connectedDevice, 2, report)', code)
code = re.sub(r'hidDevice\?\.sendReport\(connectedDevice, 2, report\)', r'hidDevice?.sendReport(connectedDevice, 1, report)', code)

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)
