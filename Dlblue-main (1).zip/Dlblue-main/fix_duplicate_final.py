with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Split by the first occurrence of privateShortcutButton function definition
import re
# Find all matches of @Composable\s*(private )?fun privateShortcutButton
parts = re.split(r'@Composable\s*(?:private\s*)?fun privateShortcutButton\s*\(', code)

if len(parts) > 1:
    # Everything before the first definition
    base_code = parts[0]
    
    private_shortcut = """@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF3B7CA6))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            }
            .height(48.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
"""
    with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
        f.write(base_code + private_shortcut)

