import re

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "r") as f:
    code = f.read()

code = code.replace("3 -> DisplaySettingsTab()", "3 -> DisplaySettingsTab(bluetoothViewModel)")
code = code.replace("fun DisplaySettingsTab() {", "fun DisplaySettingsTab(bluetoothViewModel: BluetoothViewModel) {")
code = code.replace("SettingsSwitchRow(\"Touch vibrations\", true)", "SettingsSwitchRow(\"Touch vibrations\", bluetoothViewModel.touchVibrations.value, onCheckedChange = { bluetoothViewModel.setTouchVibrations(it) })")

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "w") as f:
    f.write(code)
