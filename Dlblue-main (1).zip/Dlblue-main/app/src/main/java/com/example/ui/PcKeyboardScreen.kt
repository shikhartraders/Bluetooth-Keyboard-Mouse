package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import android.view.HapticFeedbackConstants

@Composable
fun PcKeyboardScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val keyMap = mapOf(
            "Esc" to 0x29, "F1" to 0x3A, "F2" to 0x3B, "F3" to 0x3C, "F4" to 0x3D, "F5" to 0x3E, "F6" to 0x3F, "F7" to 0x40, "F8" to 0x41, "F9" to 0x42, "F10" to 0x43, "F11" to 0x44, "F12" to 0x45, "Del" to 0x4C,
            "`" to 0x35, "1" to 0x1E, "2" to 0x1F, "3" to 0x20, "4" to 0x21, "5" to 0x22, "6" to 0x23, "7" to 0x24, "8" to 0x25, "9" to 0x26, "0" to 0x27, "-" to 0x2D, "=" to 0x2E, "Backspace" to 0x2A,
            "Tab" to 0x2B, "Q" to 0x14, "W" to 0x1A, "E" to 0x08, "R" to 0x15, "T" to 0x17, "Y" to 0x1C, "U" to 0x18, "I" to 0x0C, "O" to 0x12, "P" to 0x13, "[" to 0x2F, "]" to 0x30, "\\" to 0x31,
            "Caps" to 0x39, "A" to 0x04, "S" to 0x16, "D" to 0x07, "F" to 0x09, "G" to 0x0A, "H" to 0x0B, "J" to 0x0D, "K" to 0x0E, "L" to 0x0F, ";" to 0x33, "'" to 0x34, "Enter" to 0x28,
            "Shift" to 0xE1, "Z" to 0x1D, "X" to 0x1B, "C" to 0x06, "V" to 0x19, "B" to 0x05, "N" to 0x11, "M" to 0x10, "," to 0x36, "." to 0x37, "/" to 0x38,
            "Ctrl" to 0xE0, "Win" to 0xE3, "Alt" to 0xE2, "Space" to 0x2C, "Menu" to 0x76
        )
        val rows = listOf(
            listOf("Esc", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "Del"),
            listOf("`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "Backspace"),
            listOf("Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]", "\\"),
            listOf("Caps", "A", "S", "D", "F", "G", "H", "J", "K", "L", ";", "'", "Enter"),
            listOf("Shift", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "/", "Shift"),
            listOf("Ctrl", "Win", "Alt", "Space", "Alt", "Win", "Menu", "Ctrl")
        )

        rows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                row.forEach { key ->
                    val weight = when (key) {
                        "Space" -> 4f
                        "Backspace", "Enter", "Shift", "Caps" -> 1.5f
                        else -> 1f
                    }
                    PcKey(
                        text = key,
                        modifier = Modifier
                            .weight(weight)
                            .height(48.dp),
                        onClick = {
                            val keyCode = keyMap[key] ?: 0
                            var modifier: Byte = 0
                            var finalKeyCode = keyCode.toByte()
                            when (key) {
                                "Ctrl" -> { modifier = 0x01; finalKeyCode = 0 }
                                "Shift" -> { modifier = 0x02; finalKeyCode = 0 }
                                "Alt" -> { modifier = 0x04; finalKeyCode = 0 }
                                "Win" -> { modifier = 0x08; finalKeyCode = 0 }
                            }
                            if (finalKeyCode != 0.toByte() || modifier != 0.toByte()) {
                                bluetoothViewModel.sendKeyboardReportWithRelease(modifier, finalKeyCode)
                            }
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

@Composable
fun PcKey(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF3B7CA6))
            .clickable {
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
