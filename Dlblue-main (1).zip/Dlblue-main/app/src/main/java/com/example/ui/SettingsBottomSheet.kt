package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(bluetoothViewModel: BluetoothViewModel, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("Controls", "Mouse", "Keyboard", "Display")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(modifier = Modifier.fillMaxHeight(0.9f)) {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.Transparent
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title) }
                    )
                }
            }

            Box(modifier = Modifier.weight(1f).padding(16.dp)) {
                when (selectedTabIndex) {
                    0 -> ControlsSettingsTab()
                    1 -> MouseSettingsTab(bluetoothViewModel)
                    2 -> KeyboardSettingsTab()
                    3 -> DisplaySettingsTab(bluetoothViewModel)
                }
            }
        }
    }
}

@Composable
fun ControlsSettingsTab() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        SettingsSwitchRow("Show media control buttons", false)
        SettingsSwitchRow("Show shortcuts", true)
        SettingsSwitchRow("Show Android navigation buttons", true)
    }
}

@Composable
fun MouseSettingsTab(bluetoothViewModel: BluetoothViewModel) {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Air mouse", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        SettingsSwitchRow("Use Air Mouse", false)
        SettingsSliderRow("Air mouse sensitivity")
        
        Spacer(Modifier.height(16.dp))
        Text("Touch pad", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        SettingsSwitchRow("Touch pad mouse clicks", true)
        SettingsItemRow("Display mouse buttons", "Bottom")
        SettingsItemRow("Mouse buttons", "Left, Right")
        SettingsSliderRow("Pointer speed", value = bluetoothViewModel.pointerSpeed.floatValue, onValueChange = { bluetoothViewModel.setPointerSpeed(it) })
        SettingsSwitchRow("Natural scrolling (Reverse direction)", initialChecked = bluetoothViewModel.invertScroll.value, onCheckedChange = { bluetoothViewModel.setInvertScroll(it) })
    }
}

@Composable
fun KeyboardSettingsTab() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        SettingsItemRow("Keyboard language", "English US")
        SettingsItemRow("Show text input bar", "When keyboard is active")
        SettingsItemRow("Volume up button", "Volume up")
        SettingsItemRow("Volume down button", "Volume down")
    }
}

@Composable
fun DisplaySettingsTab(bluetoothViewModel: BluetoothViewModel) {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        SettingsItemRow("Theme color", "Default")
        SettingsItemRow("Design", "Light")
        SettingsSwitchRow("Tron style", false)
        SettingsSwitchRow("Start in full screen mode", false)
        SettingsSwitchRow("Keep screen on", false)
        SettingsSwitchRow("Show app over lock screen", true)
        SettingsSwitchRow("Touch vibrations", bluetoothViewModel.touchVibrations.value, onCheckedChange = { bluetoothViewModel.setTouchVibrations(it) })
    }
}

@Composable
fun SettingsSwitchRow(title: String, initialChecked: Boolean = false, onCheckedChange: ((Boolean) -> Unit)? = null) {
    var localChecked by remember { mutableStateOf(initialChecked) }
    val isChecked = if (onCheckedChange != null) initialChecked else localChecked
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = isChecked, onCheckedChange = { 
            localChecked = it
            onCheckedChange?.invoke(it)
        })
    }
}

@Composable
fun SettingsItemRow(title: String, subtitle: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
    }
}

@Composable
fun SettingsSliderRow(title: String, value: Float = 0.5f, onValueChange: (Float) -> Unit = {}) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Slider(value = value, onValueChange = onValueChange, valueRange = 0.1f..8.0f)
    }
}
