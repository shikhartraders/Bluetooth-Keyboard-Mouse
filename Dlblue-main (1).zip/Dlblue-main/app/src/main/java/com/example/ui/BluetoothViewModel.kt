package com.example.ui

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.IntentCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers

@SuppressLint("MissingPermission")
class BluetoothViewModel(application: Application) : AndroidViewModel(application) {
    private val bluetoothManager: BluetoothManager? = application.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _uiState = MutableStateFlow(BluetoothUiState())
    val uiState: StateFlow<BluetoothUiState> = _uiState.asStateFlow()
    private val prefs = application.getSharedPreferences("settings", Context.MODE_PRIVATE)
    val pointerSpeed = androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("pointerSpeed", 1.2f))
    val touchVibrations = androidx.compose.runtime.mutableStateOf(prefs.getBoolean("touchVibrations", true))
    val invertScroll = androidx.compose.runtime.mutableStateOf(prefs.getBoolean("invertScroll", true))
    fun setInvertScroll(enabled: Boolean) {
        invertScroll.value = enabled
        prefs.edit().putBoolean("invertScroll", enabled).apply()
    }
    fun setTouchVibrations(enabled: Boolean) {
        touchVibrations.value = enabled
        prefs.edit().putBoolean("touchVibrations", enabled).apply()
    }
    fun setPointerSpeed(speed: Float) {
        pointerSpeed.floatValue = speed
        prefs.edit().putFloat("pointerSpeed", speed).apply()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    if (state == BluetoothAdapter.STATE_ON) {
                        checkBluetoothStatus()
                        classicHidDevice?.start()
                    } else if (state == BluetoothAdapter.STATE_OFF) {
                        checkBluetoothStatus()
                        classicHidDevice?.stop()
                    }
                }
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = IntentCompat.getParcelableExtra(intent, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    device?.let {
                        val currentScanned = _uiState.value.scannedDevices.toMutableSet()
                        val deviceName = try { it.name } catch (e: SecurityException) { null }
                        if (deviceName != null) { // Filter out unnamed devices to avoid clutter
                            currentScanned.add(it)
                            _uiState.value = _uiState.value.copy(scannedDevices = currentScanned.toList())
                        }
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    _uiState.value = _uiState.value.copy(isScanning = true, scannedDevices = emptyList())
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _uiState.value = _uiState.value.copy(isScanning = false)
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val device: BluetoothDevice? = IntentCompat.getParcelableExtra(intent, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    val state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR)
                    if (state == BluetoothDevice.BOND_BONDED && device?.address == _uiState.value.connectedDevice?.address) {
                        // Bonding successful, attempt connection again
                        device?.let { classicHidDevice?.connect(it) }
                    }
                    refreshPairedDevices()
                }
            }
        }
    }

    private var classicHidDevice: ClassicHidDevice? = null

    init {
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        application.registerReceiver(receiver, filter)
        checkBluetoothStatus()
        
        classicHidDevice = ClassicHidDevice(application, bluetoothAdapter)
        classicHidDevice?.start()
        
        viewModelScope.launch {
            classicHidDevice?.connectionState?.collect { state ->
                if (state == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                    _uiState.value = _uiState.value.copy(
                        status = BluetoothStatus.CONNECTED,
                        connectedDevice = classicHidDevice?.connectedDevice
                    )
                } else if (state == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                    _uiState.value = _uiState.value.copy(
                        status = BluetoothStatus.DISCONNECTED,
                        connectedDevice = null
                    )
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            classicHidDevice?.stop()
            getApplication<Application>().unregisterReceiver(receiver)
        } catch (e: Exception) {
            // Ignore if not registered
        }
    }

    fun startScanning() {
        if (bluetoothAdapter?.isEnabled == true) {
            try {
                if (bluetoothAdapter.isDiscovering) {
                    bluetoothAdapter.cancelDiscovery()
                }
                bluetoothAdapter.startDiscovery()
            } catch (e: SecurityException) { }
        }
    }
    
    fun stopScanning() {
        if (bluetoothAdapter?.isEnabled == true) {
            try {
                if (bluetoothAdapter.isDiscovering) {
                    bluetoothAdapter.cancelDiscovery()
                }
            } catch (e: SecurityException) { }
        }
    }

    fun checkBluetoothStatus() {
        if (bluetoothAdapter == null) {
            _uiState.value = _uiState.value.copy(status = BluetoothStatus.NOT_SUPPORTED)
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            _uiState.value = _uiState.value.copy(status = BluetoothStatus.DISABLED)
            return
        }
        
        _uiState.value = _uiState.value.copy(status = BluetoothStatus.DISCONNECTED)
        refreshPairedDevices()
    }

    fun refreshPairedDevices() {
        if (bluetoothAdapter?.isEnabled == true) {
            try {
                val pairedDevices = bluetoothAdapter.bondedDevices
                val deviceList = pairedDevices?.toList() ?: emptyList()
                _uiState.value = _uiState.value.copy(pairedDevices = deviceList)
            } catch (e: SecurityException) {
                // Handle permission denial
            }
        }
    }

    fun connectToDevice(device: BluetoothDevice) {
        stopScanning() // Stop scanning when trying to connect
        _uiState.value = _uiState.value.copy(
            status = BluetoothStatus.CONNECTING,
            connectedDevice = device
        )
        if (device.bondState != BluetoothDevice.BOND_BONDED) {
            try { device.createBond() } catch (e: SecurityException) { }
            // Wait for bonding broadcast or just try to connect and let OS handle it
            // ClassicHidDevice connect will fail if not bonded, but sometimes it triggers pairing
        }
        classicHidDevice?.connect(device)
    }
    
    fun disconnect() {
        classicHidDevice?.disconnect()
        _uiState.value = _uiState.value.copy(
            status = BluetoothStatus.DISCONNECTED,
            connectedDevice = null
        )
    }

    fun sendMouseReport(dx: Int, dy: Int, leftClick: Boolean = false, rightClick: Boolean = false, middleClick: Boolean = false, wheel: Int = 0, hwheel: Int = 0) {
        classicHidDevice?.sendMouseReport(dx, dy, leftClick, rightClick, middleClick, wheel, hwheel)
    }
    
    fun sendMediaReport(key: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            classicHidDevice?.sendMediaReport(key)
            kotlinx.coroutines.delay(50)
            classicHidDevice?.sendMediaReport(0) // Release
        }
    }

    fun sendKeyboardReport(modifier: Byte, keycode: Byte) {
        classicHidDevice?.sendKeyboardReport(modifier, keycode)
    }

    fun sendKeyboardReportWithRelease(modifier: Byte, keycode: Byte) {
        viewModelScope.launch(Dispatchers.IO) {
            classicHidDevice?.sendKeyboardReport(modifier, keycode)
            kotlinx.coroutines.delay(50)
            classicHidDevice?.sendKeyboardReport(0, 0)
        }
    }
    
        fun sendRightMouseClick() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            classicHidDevice?.sendMouseReport(0, 0, false, true, false, 0, 0)
            kotlinx.coroutines.delay(50)
            classicHidDevice?.sendMouseReport(0, 0, false, false, false, 0, 0)
        }
    }

    fun sendMouseClick() {
        viewModelScope.launch(Dispatchers.IO) {
            classicHidDevice?.sendMouseReport(0, 0, true, false, false, 0, 0)
            kotlinx.coroutines.delay(50)
            classicHidDevice?.sendMouseReport(0, 0, false, false, false, 0, 0)
        }

}
}

enum class BluetoothStatus {
    NOT_SUPPORTED, DISABLED, DISCONNECTED, CONNECTING, CONNECTED
}

data class BluetoothUiState(
    val status: BluetoothStatus = BluetoothStatus.NOT_SUPPORTED,
    val connectedDevice: android.bluetooth.BluetoothDevice? = null,
    val pairedDevices: List<android.bluetooth.BluetoothDevice> = emptyList(),
    val scannedDevices: List<android.bluetooth.BluetoothDevice> = emptyList(),
    val isScanning: Boolean = false
)
