package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.automirrored.filled.VolumeDown
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun MultimediaScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top media controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MediaControlButton(icon = Icons.AutoMirrored.Filled.VolumeDown, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xEA) })
            MediaControlButton(icon = Icons.AutoMirrored.Filled.VolumeMute, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xE2) })
            MediaControlButton(icon = Icons.AutoMirrored.Filled.VolumeUp, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xE9) })
        }
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MediaControlButton(icon = Icons.Default.SkipPrevious, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB6) })
            MediaControlButton(icon = Icons.Default.SkipNext, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB5) })
            MediaControlButton(icon = Icons.Default.FastRewind, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB6) })
            MediaControlButton(icon = Icons.Default.FastForward, modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0xB5) })
        }

        // Trackpad Area
                TrackpadArea(
            modifier = Modifier.weight(1f),
            onReport = { dx, dy, left, right, middle, wheel, hwheel ->
                bluetoothViewModel.sendMouseReport(dx, dy, left, right, middle, wheel, hwheel)
            },
            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            },
            onClick = { bluetoothViewModel.sendMouseClick() },
            onRightClick = { bluetoothViewModel.sendRightMouseClick() }
        )
        
        // D-Pad
        DPadArea(bluetoothViewModel)
        
        // Play/Pause Button
        val view = androidx.compose.ui.platform.LocalView.current
        Button(
            onClick = { 
                view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_PRESS)
                bluetoothViewModel.sendMediaReport(0xCD) // Play/Pause
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8BC34A))
        ) {
            Text("PLAY/PAUSE", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        
        // Bottom Navigation Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BottomNavButton(text = "BACK", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29) })
            BottomNavButton(text = "HOME", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendMediaReport(0x0223) })
            BottomNavButton(text = "MENU", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x65) })
        }
    }
}

@Composable
fun MediaControlButton(icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = androidx.compose.ui.platform.LocalView.current
    Button(
        onClick = { view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_PRESS); onClick() },
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(0.dp)
    ) {
        Icon(icon, contentDescription = null)
    }
}

@Composable
fun BottomNavButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = androidx.compose.ui.platform.LocalView.current
    Button(
        onClick = { view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_PRESS); onClick() },
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
    ) {
        Text(text, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun DPadArea(bluetoothViewModel: BluetoothViewModel) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(
            onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x52) },
            modifier = Modifier.size(80.dp, 60.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up")
        }
        
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) },
                modifier = Modifier.size(80.dp, 60.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Left")
            }
            
            Button(
                onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x28) },
                modifier = Modifier.size(80.dp, 60.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("OK", fontWeight = FontWeight.Bold)
            }
            
            Button(
                onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) },
                modifier = Modifier.size(80.dp, 60.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Right")
            }
        }
        
        Button(
            onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x51) },
            modifier = Modifier.size(80.dp, 60.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down")
        }
    }
}
