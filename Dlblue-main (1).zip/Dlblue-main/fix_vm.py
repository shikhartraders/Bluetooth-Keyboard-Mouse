import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Update sendMouseReport signature and internal calls
code = re.sub(
    r'fun sendMouseReport\(dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, wheel: Int\) \{[\s\S]*?\}',
    r'''fun sendMouseReport(dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) {
        classicHidDevice?.sendMouseReport(dx, dy, leftClick, rightClick, middleClick, wheel, hwheel)
    }
''', code)

code = re.sub(r'classicHidDevice\?\.sendMouseReport\(0, 0, false, true, 0\)', r'classicHidDevice?.sendMouseReport(0, 0, false, true, false, 0, 0)', code)
code = re.sub(r'classicHidDevice\?\.sendMouseReport\(0, 0, false, false, 0\)', r'classicHidDevice?.sendMouseReport(0, 0, false, false, false, 0, 0)', code)
code = re.sub(r'classicHidDevice\?\.sendMouseReport\(0, 0, true, false, 0\)', r'classicHidDevice?.sendMouseReport(0, 0, true, false, false, 0, 0)', code)

# Ensure sendMediaReport exists
if "fun sendMediaReport" not in code:
    code = code.replace("fun sendKeyboardReportWithRelease", """fun sendMediaReport(key: Int) {
        classicHidDevice?.sendMediaReport(key)
    }

    fun sendKeyboardReportWithRelease""")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)

