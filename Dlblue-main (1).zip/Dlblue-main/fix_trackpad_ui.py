import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

trackpad_icon_code = """
        Icon(
            imageVector = Icons.Default.Mouse,
            contentDescription = "Mouse",
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp),
            tint = iconColor.copy(alpha = 0.8f)
        )
"""

new_trackpad_ui = """
        Icon(
            imageVector = Icons.Default.Mouse,
            contentDescription = "Mouse",
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp),
            tint = iconColor.copy(alpha = 0.8f)
        )
        // Scrollbar on the right
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp, top = 24.dp, bottom = 24.dp)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = androidx.compose.material.icons.Icons.Default.KeyboardArrowUp,
                contentDescription = "Scroll Up",
                tint = iconColor,
                modifier = Modifier.size(24.dp)
            )
            Box(modifier = Modifier.weight(1f).width(2.dp).background(iconColor).padding(vertical = 8.dp))
            Icon(
                imageVector = androidx.compose.material.icons.Icons.Default.KeyboardArrowDown,
                contentDescription = "Scroll Down",
                tint = iconColor,
                modifier = Modifier.size(24.dp)
            )
        }
"""

if trackpad_icon_code in code:
    code = code.replace(trackpad_icon_code, new_trackpad_ui)
    
# Replace the blue color to match the screenshot
code = code.replace("Color(0xFF3B7CA6)", "Color(0xFF558AB2)") # Lightened blue for buttons
code = code.replace("Color(0xFF004975)", "Color(0xFF075482)") # Base dark blue for trackpad

# Add imports for KeyboardArrowUp, KeyboardArrowDown
imports_to_add = "import androidx.compose.material.icons.filled.KeyboardArrowUp\\nimport androidx.compose.material.icons.filled.KeyboardArrowDown\\n"
if "KeyboardArrowUp" not in code:
    code = code.replace("import androidx.compose.material.icons.filled.Mouse", "import androidx.compose.material.icons.filled.Mouse\\n" + imports_to_add)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
