import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

new_method = """    fun sendRightMouseClick() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            classicHidDevice?.sendMouseReport(0, 0, false, true, 0)
            kotlinx.coroutines.delay(20)
            classicHidDevice?.sendMouseReport(0, 0, false, false, 0)
        }
    }"""

if "sendRightMouseClick" not in code:
    code = code.replace("fun sendMouseClick() {", new_method + "\n\n    fun sendMouseClick() {")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)


with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

code = code.replace("""onClick = { bluetoothViewModel.sendMouseReport(0, 0, false, true, 0); bluetoothViewModel.sendMouseReport(0, 0, false, false, 0) }""",
"""onClick = { bluetoothViewModel.sendRightMouseClick() }""")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

