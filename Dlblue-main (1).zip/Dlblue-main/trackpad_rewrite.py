import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Replace the content of MouseKeyboardScreen
start_idx = code.find("fun MouseKeyboardScreen")
end_idx = code.find("    val view = LocalView.current\n    Box(")

new_screen = """fun MouseKeyboardScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel, showInputBar: Boolean = false) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TrackpadArea(
            modifier = Modifier.weight(1f),
            onReport = { dx, dy, left, right, middle, wheel, hwheel ->
                bluetoothViewModel.sendMouseReport(dx, dy, left, right, middle, wheel, hwheel)
            },
            onClick = { bluetoothViewModel.sendMouseClick() },
            onRightClick = { bluetoothViewModel.sendRightMouseClick() },
            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            }
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        // Row 1: Left and Right clicks
        Row(modifier = Modifier.fillMaxWidth().height(64.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            privateShortcutButton("", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendMouseClick() }
            privateShortcutButton("", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendRightMouseClick() }
        }
        Spacer(modifier = Modifier.height(8.dp))
        // Row 2: Undo, Redo, Copy
        Row(modifier = Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            privateShortcutButton("Undo", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x1D) } // CTRL+Z
            privateShortcutButton("Redo", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x1C) } // CTRL+Y
            privateShortcutButton("Copy", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x06) } // CTRL+C
        }
        Spacer(modifier = Modifier.height(8.dp))
        // Row 3: Paste
        Row(modifier = Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            privateShortcutButton("Paste", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x19) } // CTRL+V
        }
        Spacer(modifier = Modifier.height(8.dp))
        // Row 4: Left arrow, Right arrow
        Row(modifier = Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            privateShortcutButton("←", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) } // Left Arrow
            privateShortcutButton("→", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) } // Right Arrow
        }
        Spacer(modifier = Modifier.height(8.dp))
        // Row 5: Unlock Back, Home, Menu
        Row(modifier = Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            privateShortcutButton("Unlock Back", modifier = Modifier.weight(1.5f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29) } // Esc/Back
            privateShortcutButton("Home", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4A) } // Home
            privateShortcutButton("Menu", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x65) } // Menu/App
        }
    }
}

@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
"""

if start_idx != -1 and end_idx != -1:
    with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
        f.write(code[:start_idx] + new_screen + code[end_idx:])
