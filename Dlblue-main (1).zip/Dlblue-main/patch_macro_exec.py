import re

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "r") as f:
    content = f.read()

old_exec = """                                            "keypress" -> {
                                                bluetoothViewModel.sendKeyboardReport(
                                                    action.modifiers?.toByte() ?: 0,
                                                    action.keycode?.toByte() ?: 0
                                                )
                                                delay(50) // Small delay between key presses

                                                delay(50)
                                            }"""

new_exec = """                                            "keypress" -> {
                                                bluetoothViewModel.sendKeyboardReportWithRelease(
                                                    action.modifiers?.toByte() ?: 0,
                                                    action.keycode?.toByte() ?: 0
                                                )
                                                delay(100) // Small delay between key presses
                                            }"""

if old_exec in content:
    content = content.replace(old_exec, new_exec)
    print("Replaced execution!")
else:
    print("Could not find execution to replace.")

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "w") as f:
    f.write(content)
