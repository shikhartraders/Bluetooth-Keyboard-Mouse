import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

correct_block = """    fun charToHid(c: Char): Pair<Byte, Byte>? {
        val shift: Byte = 0x02
        return when (c) {
            in 'a'..'z' -> Pair(0.toByte(), (c - 'a' + 0x04).toByte())
            in 'A'..'Z' -> Pair(shift, (c - 'A' + 0x04).toByte())
            in '1'..'9' -> Pair(0.toByte(), (c - '1' + 0x1E).toByte())
            '0' -> Pair(0.toByte(), 0x27)
            ' ' -> Pair(0.toByte(), 0x2C)
            '\\n' -> Pair(0.toByte(), 0x28)
            '-' -> Pair(0.toByte(), 0x2D)
            '=' -> Pair(0.toByte(), 0x2E)
            '[' -> Pair(0.toByte(), 0x2F)
            ']' -> Pair(0.toByte(), 0x30)
            '\\\\' -> Pair(0.toByte(), 0x31)
            ';' -> Pair(0.toByte(), 0x33)
            '\\'' -> Pair(0.toByte(), 0x34)
            '`' -> Pair(0.toByte(), 0x35)
            ',' -> Pair(0.toByte(), 0x36)
            '.' -> Pair(0.toByte(), 0x37)
            '/' -> Pair(0.toByte(), 0x38)
            '!' -> Pair(shift, 0x1E)
            '@' -> Pair(shift, 0x1F)
            '#' -> Pair(shift, 0x20)
            '$' -> Pair(shift, 0x21)
            '%' -> Pair(shift, 0x22)
            '^' -> Pair(shift, 0x23)
            '&' -> Pair(shift, 0x24)
            '*' -> Pair(shift, 0x25)
            '(' -> Pair(shift, 0x26)
            ')' -> Pair(shift, 0x27)
            '_' -> Pair(shift, 0x2D)
            '+' -> Pair(shift, 0x2E)
            '{' -> Pair(shift, 0x2F)
            '}' -> Pair(shift, 0x30)
            '|' -> Pair(shift, 0x31)
            ':' -> Pair(shift, 0x33)
            '"' -> Pair(shift, 0x34)
            '~' -> Pair(shift, 0x35)
            '<' -> Pair(shift, 0x36)
            '>' -> Pair(shift, 0x37)
            '?' -> Pair(shift, 0x38)
            else -> null
        }
    }"""

code = re.sub(r'fun charToHid\(c: Char\): Pair<Byte, Byte>\? \{[\s\S]*?else -> null\s*\}\s*\}', correct_block, code)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
