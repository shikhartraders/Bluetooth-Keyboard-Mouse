import glob
import re

files = glob.glob("app/src/main/java/com/example/ui/*Screen.kt")
for file in files:
    with open(file, "r") as f:
        code = f.read()

    # Keyboard
    # replace pattern: bluetoothViewModel.sendKeyboardReport(X, Y); bluetoothViewModel.sendKeyboardReport(0, 0)
    # Be careful with line breaks if any, but they are mostly on one line or two lines.
    
    # Let's just use regex substitution.
    code = re.sub(
        r'bluetoothViewModel\.sendKeyboardReport\(([^,]+),\s*([^)]+)\)\s*(?:;|)\s*bluetoothViewModel\.sendKeyboardReport\(0,\s*0\)',
        r'bluetoothViewModel.sendKeyboardReportWithRelease(\1, \2)',
        code
    )

    # For multi-line replacements
    code = re.sub(
        r'bluetoothViewModel\.sendKeyboardReport\(([^,]+),\s*([^)]+)\)\n\s*bluetoothViewModel\.sendKeyboardReport\(0,\s*0\)',
        r'bluetoothViewModel.sendKeyboardReportWithRelease(\1, \2)',
        code
    )
    
    # Mouse
    code = re.sub(
        r'bluetoothViewModel\.sendMouseReport\(0,\s*0,\s*true,\s*false,\s*0\)\s*(?:;|)\s*bluetoothViewModel\.sendMouseReport\(0,\s*0,\s*false,\s*false,\s*0\)',
        r'bluetoothViewModel.sendMouseClick()',
        code
    )
    
    with open(file, "w") as f:
        f.write(code)

