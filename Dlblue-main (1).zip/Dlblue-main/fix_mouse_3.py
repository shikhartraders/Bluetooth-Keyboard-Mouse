with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    lines = f.readlines()

new_lines = []
skip = False
for line in lines:
    if line.strip() == "else {":
        if "Icon(" in new_lines[-1] or "}" in new_lines[-1]: # it's the bad block
            # Pop back to the end of TrackpadArea
            while "}" not in new_lines[-1]:
                new_lines.pop()
            skip = True
            continue
    if skip:
        if "@Composable" in line and "fun CustomShortcutsArea" in lines[lines.index(line) + 1]:
            skip = False
        elif "fun TextInputBar" in line:
            skip = False
        
    if not skip:
        new_lines.append(line)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.writelines(new_lines)
