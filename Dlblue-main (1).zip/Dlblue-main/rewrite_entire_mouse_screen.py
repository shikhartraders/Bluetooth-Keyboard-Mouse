import os

code = """package com.example.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.input.pointer.pointerInput

@Composable
fun MouseKeyboardScreen(navController: NavController, bluetoothViewModel: BluetoothViewModel, showInputBar: Boolean = false) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TrackpadArea(
            modifier = Modifier.weight(1f),
            onReport = { dx, dy, left, right, wheel ->
                bluetoothViewModel.sendMouseReport(dx, dy, left, right, wheel)
            },
            onClick = { bluetoothViewModel.sendMouseClick() },
            onRightClick = { bluetoothViewModel.sendRightMouseClick() }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Mouse Buttons (Left, Right)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MouseClickButton(
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendMouseClick() }
            )
            MouseClickButton(
                modifier = Modifier.weight(1f).height(64.dp),
                onClick = { bluetoothViewModel.sendRightMouseClick() }
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        CustomShortcutsArea(bluetoothViewModel)
        
        if (showInputBar) {
            Spacer(modifier = Modifier.height(8.dp))
            TextInputBar(bluetoothViewModel)
        }
    }
}

@Composable
fun MouseClickButton(modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF3B7CA6))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
    }
}

@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (Int, Int, Boolean, Boolean, Int) -> Unit = { _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {}
) {
    val trackpadColor = Color(0xFF004975)
    val iconColor = Color.White
    val view = LocalView.current
    
    var lastTapTime by remember { mutableStateOf(0L) }
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(trackpadColor)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startTime = System.currentTimeMillis()
                    var isTwoFingers = false
                    var isDragging = false
                    var moved = false
                    
                    var lastX = down.position.x
                    var lastY = down.position.y
                    var leftoverX = 0f
                    var leftoverY = 0f
                    
                    // Double tap to drag
                    if (startTime - lastTapTime < 250) {
                        isDragging = true
                        onReport(0, 0, true, false, 0) // Left click down
                    }
                    
                    do {
                        val event = awaitPointerEvent()
                        val pointers = event.changes
                        
                        if (pointers.size >= 2) {
                            isTwoFingers = true
                            val currentX = pointers[0].position.x
                            val currentY = pointers[0].position.y
                            val dx = currentX - lastX
                            val dy = currentY - lastY
                            if (kotlin.math.abs(dx) > 2f || kotlin.math.abs(dy) > 2f) moved = true
                            
                            leftoverY += dy
                            val wheel = -(leftoverY / 20f).toInt() // Smoother scrolling
                            if (wheel != 0) {
                                onReport(0, 0, false, false, wheel)
                                leftoverY += wheel * 20f
                            }
                            lastX = currentX
                            lastY = currentY
                        } else if (pointers.size == 1) {
                            val currentX = pointers[0].position.x
                            val currentY = pointers[0].position.y
                            val dx = currentX - lastX
                            val dy = currentY - lastY
                            
                            if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                            
                            val dist = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                            val accel = (dist / 10f).coerceIn(1.0f, 3.0f)
                            val baseSensitivity = 1.2f
                            
                            leftoverX += dx * baseSensitivity * accel
                            leftoverY += dy * baseSensitivity * accel
                            
                            val outX = leftoverX.toInt()
                            val outY = leftoverY.toInt()
                            
                            if (outX != 0 || outY != 0) {
                                onReport(outX, outY, isDragging, false, 0)
                                leftoverX -= outX
                                leftoverY -= outY
                            }
                            lastX = currentX
                            lastY = currentY
                        }
                        pointers.forEach { it.consume() }
                    } while (event.changes.any { it.pressed })
                    
                    val endTime = System.currentTimeMillis()
                    if (isDragging) {
                        onReport(0, 0, false, false, 0) // Release left click
                    } else if (!moved && endTime - startTime < 200) {
                        if (isTwoFingers) {
                            onRightClick()
                        } else {
                            lastTapTime = endTime
                            onClick()
                        }
                    }
                }
            }
    ) {
        Icon(
            imageVector = Icons.Default.Mouse,
            contentDescription = "Mouse",
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp),
            tint = iconColor.copy(alpha = 0.8f)
        )
    }
}

@Composable
fun TextInputBar(bluetoothViewModel: BluetoothViewModel) {
    var text by remember { mutableStateOf("") }
    
    fun charToHid(c: Char): Pair<Byte, Byte>? {
        val shift: Byte = 0x02
        return when (c) {
            in 'a'..'z' -> Pair(0.toByte(), (c - 'a' + 0x04).toByte())
            in 'A'..'Z' -> Pair(shift, (c - 'A' + 0x04).toByte())
            in '1'..'9' -> Pair(0.toByte(), (c - '1' + 0x1E).toByte())
            '0' -> Pair(0.toByte(), 0x27)
            ' ' -> Pair(0.toByte(), 0x2C)
            '\n' -> Pair(0.toByte(), 0x28)
            '-' -> Pair(0.toByte(), 0x2D)
            '=' -> Pair(0.toByte(), 0x2E)
            '[' -> Pair(0.toByte(), 0x2F)
            ']' -> Pair(0.toByte(), 0x30)
            '\\' -> Pair(0.toByte(), 0x31)
            ';' -> Pair(0.toByte(), 0x33)
            '\'' -> Pair(0.toByte(), 0x34)
            '`' -> Pair(0.toByte(), 0x35)
            ',' -> Pair(0.toByte(), 0x36)
            '.' -> Pair(0.toByte(), 0x37)
            '/' -> Pair(0.toByte(), 0x38)
            '!' -> Pair(shift, 0x1E)
            '@' -> Pair(shift, 0x1F)
            '#' -> Pair(shift, 0x20)
            '$' -> Pair(shift, 0x21)
            '%' -> Pair(shift, 0x22)
            '^' -> Pair(shift, 0x23)
            '&' -> Pair(shift, 0x24)
            '*' -> Pair(shift, 0x25)
            '(' -> Pair(shift, 0x26)
            ')' -> Pair(shift, 0x27)
            '_' -> Pair(shift, 0x2D)
            '+' -> Pair(shift, 0x2E)
            '{' -> Pair(shift, 0x2F)
            '}' -> Pair(shift, 0x30)
            '|' -> Pair(shift, 0x31)
            ':' -> Pair(shift, 0x33)
            '"' -> Pair(shift, 0x34)
            '~' -> Pair(shift, 0x35)
            '<' -> Pair(shift, 0x36)
            '>' -> Pair(shift, 0x37)
            '?' -> Pair(shift, 0x38)
            else -> null
        }
    }
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MaterialTheme.colorScheme.surface),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .weight(0.3f)
                .fillMaxHeight()
                .background(Color(0xFFD6E8F4), RoundedCornerShape(28.dp))
                .clickable { },
            contentAlignment = Alignment.Center
        ) {
            Text("Direct", color = Color(0xFF3B7CA6), fontSize = 16.sp)
        }
        
        OutlinedTextField(
            value = text,
            onValueChange = { newText -> 
                if (newText.length > text.length) {
                    val added = newText.substring(text.length)
                    added.forEach { c ->
                        charToHid(c)?.let { (mod, key) ->
                            bluetoothViewModel.sendKeyboardReportWithRelease(mod, key)
                        }
                    }
                } else if (newText.length < text.length) {
                    repeat(text.length - newText.length) {
                        bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2A) // Backspace
                    }
                }
                text = newText
            },
            placeholder = { Text("Enter...") },
            modifier = Modifier
                .weight(0.5f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(8.dp),
            keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Done),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.Gray,
                focusedBorderColor = Color.Gray
            )
        )
        
        IconButton(onClick = { text = "" }) {
            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
        }
    }
}

@Composable
fun CustomShortcutsArea(bluetoothViewModel: BluetoothViewModel) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            privateShortcutButton(text = "UNDO", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x1D) }) // Ctrl+Z
            privateShortcutButton(text = "REDO", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x1C) }) // Ctrl+Y
            privateShortcutButton(text = "COPY", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x06) }) // Ctrl+C
            privateShortcutButton(text = "PASTE", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0x19) }) // Ctrl+V
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            privateShortcutButton(text = "←", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) }) // Left
            privateShortcutButton(text = "→", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) }) // Right
            privateShortcutButton(text = "Esc", modifier = Modifier.weight(1.5f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29) })
            privateShortcutButton(text = "Home", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4A) })
            privateShortcutButton(text = "Menu", modifier = Modifier.weight(1f), onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x76) })
        }
    }
}

@Composable
private fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF3B7CA6))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            }
            .height(48.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
"""

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

