with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if "enum class BluetoothStatus" in line:
        break
    new_lines.append(line)

code = "".join(new_lines)
# count { and } in code
open_count = code.count("{")
close_count = code.count("}")

print("Open:", open_count, "Close:", close_count)

while close_count < open_count:
    code += "}\n"
    close_count += 1
while close_count > open_count:
    # remove a trailing }
    code = code.rsplit("}", 1)[0]
    close_count -= 1

code += """
enum class BluetoothStatus {
    NOT_SUPPORTED, DISABLED, DISCONNECTED, CONNECTING, CONNECTED
}

data class BluetoothUiState(
    val status: BluetoothStatus = BluetoothStatus.NOT_SUPPORTED,
    val connectedDevice: android.bluetooth.BluetoothDevice? = null,
    val pairedDevices: List<android.bluetooth.BluetoothDevice> = emptyList(),
    val scannedDevices: List<android.bluetooth.BluetoothDevice> = emptyList(),
    val isScanning: Boolean = false
)
"""

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)
