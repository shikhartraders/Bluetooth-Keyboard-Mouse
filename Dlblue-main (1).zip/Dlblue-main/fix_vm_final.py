import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Fix sendMouseClick missing braces
code = code.replace("""    fun sendMouseClick() {
        viewModelScope.launch(Dispatchers.IO) {
            classicHidDevice?.sendMouseReport(0, 0, true, false, 0)
            kotlinx.coroutines.delay(20)
            classicHidDevice?.sendMouseReport(0, 0, false, false, 0)
        }""", """    fun sendMouseClick() {
        viewModelScope.launch(Dispatchers.IO) {
            classicHidDevice?.sendMouseReport(0, 0, true, false, 0)
            kotlinx.coroutines.delay(20)
            classicHidDevice?.sendMouseReport(0, 0, false, false, 0)
        }
    }
}""")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)

