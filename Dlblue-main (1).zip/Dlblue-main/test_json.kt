import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val tools: List<JsonObject>? = null,
    val systemInstruction: Content? = null
)
@Serializable
data class Content(val parts: List<Part>)
@Serializable
data class Part(val text: String? = null)
@Serializable
data class ResponseFormat(val text: ResponseFormatText? = null)
@Serializable
data class ResponseFormatText(val mimeType: String, val schema: JsonObject? = null)
@Serializable
data class GenerationConfig(val responseFormat: ResponseFormat? = null)

fun main() {
    val req = GenerateContentRequest(contents=listOf(Content(listOf(Part("hello")))))
    println(Json.encodeToString(GenerateContentRequest.serializer(), req))
}
