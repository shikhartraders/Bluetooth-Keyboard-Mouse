import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

code = re.sub(r'addAction\(BluetoothAdapter\.ACTION_STATE_CHANGED -> \{[\s\S]*?BluetoothDevice\.ACTION_FOUND\)',
              'addAction(BluetoothAdapter.ACTION_STATE_CHANGED)\n            addAction(BluetoothDevice.ACTION_FOUND)',
              code)

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)
