import re
with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

code = code.replace('"Bluetooth Keyboard/Mouse"', '"SPS BT Input V2"')

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)
