import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Add ACTION_STATE_CHANGED to intent filter and handle it
new_receiver_code = """
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    if (state == BluetoothAdapter.STATE_ON) {
                        checkBluetoothStatus()
                        classicHidDevice?.start()
                    } else if (state == BluetoothAdapter.STATE_OFF) {
                        checkBluetoothStatus()
                        classicHidDevice?.stop()
                    }
                }
                BluetoothDevice.ACTION_FOUND
"""

code = code.replace("BluetoothDevice.ACTION_FOUND", new_receiver_code.strip())

new_filter_code = """
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothDevice.ACTION_FOUND)
"""

code = code.replace("addAction(BluetoothDevice.ACTION_FOUND)", new_filter_code.strip())

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)
