import re

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()

code = code.replace("bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29)")
# In case it missed the bottom nav buttons
code = code.replace("bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4A)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4A)")
code = code.replace("bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x65)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x65)")
# Let's just fix the Dpad which uses sendKeyboardReport instead of sendKeyboardReportWithRelease for some reason?
# Wait, the error is: Unresolved reference 'sendKeyboardReportWithRelease' in MultimediaScreen.kt
# Ah! I didn't update the calls in MultimediaScreen properly if they are still failing.
pass
