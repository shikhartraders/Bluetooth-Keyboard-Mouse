import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Fix MouseKeyboardScreen calls
code = code.replace("TextInputBar(bluetoothViewModel, activeModifiers, ::resetModifiers)", "TextInputBar(bluetoothViewModel, activeModifiers, { resetModifiers() })")
code = code.replace("ControlPanels(bluetoothViewModel, activeModifiers, ::toggleModifier, ::resetModifiers)", "ControlPanels(bluetoothViewModel, activeModifiers, { toggleModifier(it) }, { resetModifiers() })")

# Fix ControlPanels calls (I might have replaced it incorrectly before)
code = code.replace("0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, ::toggleModifier, ::resetModifiers)", "0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, toggleModifier, resetModifiers)")

# Fix FullKeyboardPanel calls
code = code.replace("TextInputBar(bluetoothViewModel, activeModifiers, ::resetModifiers)", "TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)")
# The error said: e: file:///app/src/main/java/com/example/ui/MouseKeyboardScreen.kt:461:81 References to variables aren't supported yet
# That was line 461 which is in ControlPanels: 0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, ::toggleModifier, ::resetModifiers)
# The second one was 512: TextInputBar(bluetoothViewModel, activeModifiers, ::resetModifiers)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
