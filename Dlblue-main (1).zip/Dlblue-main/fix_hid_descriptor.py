import re

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

# Current report map ends with:
#         0x05, 0x07, // Usage Page (Key Codes)
#         0x19, 0x00, // Usage Minimum (0)
#         0x29, 0x65, // Usage Maximum (101)
#         0x81.toByte(), 0x00, // Input (Data, Array)
#         0xC0.toByte() // End Collection
#     )

# We want to add Consumer Control (Report ID 3)
consumer_control = """        // Consumer Control
        0x05, 0x0C, // Usage Page (Consumer)
        0x09, 0x01, // Usage (Consumer Control)
        0xA1.toByte(), 0x01, // Collection (Application)
        0x85.toByte(), 0x03, // Report Id (3)
        0x15, 0x00, // Logical Minimum (0)
        0x25, 0x01, // Logical Maximum (1)
        0x75, 0x01, // Report Size (1)
        0x95.toByte(), 0x07, // Report Count (7)
        0x09, 0xB5.toByte(), // Usage (Scan Next Track)
        0x09, 0xB6.toByte(), // Usage (Scan Previous Track)
        0x09, 0xB7.toByte(), // Usage (Stop)
        0x09, 0xCD.toByte(), // Usage (Play/Pause)
        0x09, 0xE2.toByte(), // Usage (Mute)
        0x09, 0xEA.toByte(), // Usage (Volume Down)
        0x09, 0xE9.toByte(), // Usage (Volume Up)
        0x81.toByte(), 0x02, // Input (Data, Variable, Absolute)
        0x95.toByte(), 0x01, // Report Count (1)
        0x75, 0x01, // Report Size (1)
        0x81.toByte(), 0x03, // Input (Constant) - Padding bit
        0xC0.toByte() // End Collection
    )"""

code = code.replace("""        0x81.toByte(), 0x00, // Input (Data, Array)
        0xC0.toByte() // End Collection
    )""", """        0x81.toByte(), 0x00, // Input (Data, Array)
        0xC0.toByte(), // End Collection
""" + consumer_control)

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)

