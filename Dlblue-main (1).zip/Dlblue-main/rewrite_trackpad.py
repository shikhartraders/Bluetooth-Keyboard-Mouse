import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

trackpad_logic = """@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, wheel: Int) -> Unit = { _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {}
)"""

# Instead of relying on exact signature match, let's just use regex to replace TrackpadArea
trackpad_regex = r'@Composable\s*fun TrackpadArea.*?\)\s*\{\s*Icon\(.*?\}\s*\}'

new_trackpad = """@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {},
    onMiddleClick: () -> Unit = {}
) {
    val trackpadColor = Color(0xFF004975)
    val iconColor = Color.White
    val view = LocalView.current
    
    var lastTapTime by remember { mutableLongStateOf(0L) }
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(trackpadColor)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val downEvent = awaitFirstDown(requireUnconsumed = false)
                        val startTime = System.currentTimeMillis()
                        
                        var isTwoFingers = false
                        var isThreeFingers = false
                        var isDragging = false
                        var moved = false
                        
                        var lastX = downEvent.position.x
                        var lastY = downEvent.position.y
                        
                        var leftoverX = 0f
                        var leftoverY = 0f
                        var wheelLeftoverY = 0f
                        var wheelLeftoverX = 0f
                        
                        val tapTimeout = 200L
                        val dragTimeout = 250L
                        
                        if (startTime - lastTapTime < dragTimeout) {
                            isDragging = true
                            onReport(0, 0, true, false, false, 0, 0)
                        }
                        
                        do {
                            val event = awaitPointerEvent()
                            val pointers = event.changes
                            
                            val activePointers = pointers.filter { it.pressed }
                            
                            if (activePointers.size >= 3) {
                                isThreeFingers = true
                            } else if (activePointers.size == 2) {
                                isTwoFingers = true
                                val currentX = (activePointers[0].position.x + activePointers[1].position.x) / 2
                                val currentY = (activePointers[0].position.y + activePointers[1].position.y) / 2
                                
                                val dx = currentX - lastX
                                val dy = currentY - lastY
                                
                                if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                                
                                wheelLeftoverY += dy
                                wheelLeftoverX += dx
                                
                                val wheel = -(wheelLeftoverY / 15f).toInt()
                                val hwheel = (wheelLeftoverX / 15f).toInt()
                                
                                if (wheel != 0 || hwheel != 0) {
                                    onReport(0, 0, false, false, false, wheel, hwheel)
                                    wheelLeftoverY += wheel * 15f
                                    wheelLeftoverX -= hwheel * 15f
                                }
                                
                                lastX = currentX
                                lastY = currentY
                                
                            } else if (activePointers.size == 1) {
                                val currentX = activePointers[0].position.x
                                val currentY = activePointers[0].position.y
                                val dx = currentX - lastX
                                val dy = currentY - lastY
                                
                                if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                                
                                val dist = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                val accel = (dist / 10f).coerceIn(1.0f, 4.0f)
                                val baseSensitivity = 1.2f
                                
                                leftoverX += dx * baseSensitivity * accel
                                leftoverY += dy * baseSensitivity * accel
                                
                                val outX = leftoverX.toInt()
                                val outY = leftoverY.toInt()
                                
                                if (outX != 0 || outY != 0) {
                                    onReport(outX, outY, isDragging, false, false, 0, 0)
                                    leftoverX -= outX
                                    leftoverY -= outY
                                }
                                lastX = currentX
                                lastY = currentY
                            }
                            
                            pointers.forEach { it.consume() }
                        } while (event.changes.any { it.pressed })
                        
                        val endTime = System.currentTimeMillis()
                        
                        if (isDragging) {
                            onReport(0, 0, false, false, false, 0, 0)
                            lastTapTime = 0L
                        } else if (!moved && endTime - startTime < tapTimeout) {
                            if (isThreeFingers) {
                                onMiddleClick()
                            } else if (isTwoFingers) {
                                onRightClick()
                            } else {
                                lastTapTime = endTime
                                onClick()
                            }
                        }
                    }
                }
            }
    ) {
        Icon(
            imageVector = Icons.Default.Mouse,
            contentDescription = "Mouse",
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp),
            tint = iconColor.copy(alpha = 0.8f)
        )
    }
}"""

code = re.sub(r'@Composable\s*fun TrackpadArea.*?\)\s*\{\s*Icon\(.*?\s*\}\s*\}', new_trackpad, code, flags=re.DOTALL)

# Fix the call in MouseKeyboardScreen
code = re.sub(
    r'TrackpadArea\(\s*modifier = Modifier.weight\(1f\),\s*onReport = \{ dx, dy, left, right, wheel ->\s*bluetoothViewModel.sendMouseReport\(dx, dy, left, right, wheel\)\s*\},\s*onClick = \{ bluetoothViewModel.sendMouseClick\(\) \},\s*onRightClick = \{ bluetoothViewModel.sendRightMouseClick\(\) \}\s*\)',
    """TrackpadArea(
            modifier = Modifier.weight(1f),
            onReport = { dx, dy, left, right, middle, wheel, hwheel ->
                bluetoothViewModel.sendMouseReport(dx, dy, left, right, middle, wheel, hwheel)
            },
            onClick = { bluetoothViewModel.sendMouseClick() },
            onRightClick = { bluetoothViewModel.sendRightMouseClick() },
            onMiddleClick = { bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0); bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0) }
        )""",
    code, flags=re.DOTALL
)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

