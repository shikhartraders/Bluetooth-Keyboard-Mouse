import re

with open("app/src/main/java/com/example/ui/GeminiApiService.kt", "r") as f:
    content = f.read()

content = content.replace(
    "val responseFormat: ResponseFormat? = null,",
    "val responseFormat: ResponseFormat? = null,\n    val responseMimeType: String? = null,\n    val responseSchema: kotlinx.serialization.json.JsonObject? = null,"
)

with open("app/src/main/java/com/example/ui/GeminiApiService.kt", "w") as f:
    f.write(content)
