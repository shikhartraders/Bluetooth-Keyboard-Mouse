import re

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "r") as f:
    code = f.read()

# Change the slider range for Pointer speed
# Currently it's 0.1f..3.0f in SettingsSliderRow

# Let's change SettingsSliderRow valueRange to 0.1f..10.0f maybe? 
# Wait, if we change the generic SettingsSliderRow valueRange, it will affect Air mouse sensitivity too.
# Let's see if Air mouse sensitivity uses it.
code = code.replace("valueRange = 0.1f..3.0f", "valueRange = 0.1f..8.0f")

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "w") as f:
    f.write(code)
