import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Fix the char literals
code = code.replace(r"''' ->", r"'\'' ->")  # not quite right, let me just do a manual replace
# The file has: '\' -> Pair(0.toByte(), 0x31)
# which should be '\\' -> Pair(0.toByte(), 0x31)
code = code.replace(r"    '\' -> Pair", r"    '\\\\' -> Pair")
code = code.replace(r"    '''' -> Pair", r"    '\\'' -> Pair")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
