import re

with open("app/src/main/java/com/example/ui/BluetoothConnectionDialog.kt", "r") as f:
    code = f.read()

# Replace device.name with safe method
code = code.replace("""Text(text = device.name ?: "Unknown Device", fontWeight = if (isConnected) FontWeight.Bold else FontWeight.Normal)""",
"""val deviceName = try { device.name ?: "Unknown Device" } catch (e: SecurityException) { "Unknown Device" }
            Text(text = deviceName, fontWeight = if (isConnected) FontWeight.Bold else FontWeight.Normal)""")

with open("app/src/main/java/com/example/ui/BluetoothConnectionDialog.kt", "w") as f:
    f.write(code)
