import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Add try-catch around it.name
code = code.replace("""if (it.name != null) {""", """val deviceName = try { it.name } catch (e: SecurityException) { null }
                        if (deviceName != null) {""")

# Add try-catch around startScanning
code = code.replace("""if (bluetoothAdapter.isDiscovering) {
                bluetoothAdapter.cancelDiscovery()
            }
            bluetoothAdapter.startDiscovery()""", """try {
                if (bluetoothAdapter.isDiscovering) {
                    bluetoothAdapter.cancelDiscovery()
                }
                bluetoothAdapter.startDiscovery()
            } catch (e: SecurityException) { }""")

# Add try-catch around stopScanning
code = code.replace("""if (bluetoothAdapter?.isEnabled == true && bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }""", """if (bluetoothAdapter?.isEnabled == true) {
            try {
                if (bluetoothAdapter.isDiscovering) {
                    bluetoothAdapter.cancelDiscovery()
                }
            } catch (e: SecurityException) { }
        }""")

# Add try-catch around device.createBond()
code = code.replace("""device.createBond()""", """try { device.createBond() } catch (e: SecurityException) { }""")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)
