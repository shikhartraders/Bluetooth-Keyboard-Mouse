import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

new_text_input = """fun TextInputBar(bluetoothViewModel: BluetoothViewModel) {
    var text by remember { mutableStateOf("") }
    
    // Simple ASCII to HID keycode mapping
    fun charToHid(c: Char): Pair<Byte, Byte>? {
        val shift: Byte = 0x02
        return when (c) {
            in 'a'..'z' -> Pair(0.toByte(), (c - 'a' + 0x04).toByte())
            in 'A'..'Z' -> Pair(shift, (c - 'A' + 0x04).toByte())
            in '1'..'9' -> Pair(0.toByte(), (c - '1' + 0x1E).toByte())
            '0' -> Pair(0.toByte(), 0x27)
            ' ' -> Pair(0.toByte(), 0x2C)
            '\n' -> Pair(0.toByte(), 0x28)
            '-' -> Pair(0.toByte(), 0x2D)
            '=' -> Pair(0.toByte(), 0x2E)
            '[' -> Pair(0.toByte(), 0x2F)
            ']' -> Pair(0.toByte(), 0x30)
            '\\\\' -> Pair(0.toByte(), 0x31)
            ';' -> Pair(0.toByte(), 0x33)
            '\'' -> Pair(0.toByte(), 0x34)
            '`' -> Pair(0.toByte(), 0x35)
            ',' -> Pair(0.toByte(), 0x36)
            '.' -> Pair(0.toByte(), 0x37)
            '/' -> Pair(0.toByte(), 0x38)
            '!' -> Pair(shift, 0x1E)
            '@' -> Pair(shift, 0x1F)
            '#' -> Pair(shift, 0x20)
            '$' -> Pair(shift, 0x21)
            '%' -> Pair(shift, 0x22)
            '^' -> Pair(shift, 0x23)
            '&' -> Pair(shift, 0x24)
            '*' -> Pair(shift, 0x25)
            '(' -> Pair(shift, 0x26)
            ')' -> Pair(shift, 0x27)
            '_' -> Pair(shift, 0x2D)
            '+' -> Pair(shift, 0x2E)
            '{' -> Pair(shift, 0x2F)
            '}' -> Pair(shift, 0x30)
            '|' -> Pair(shift, 0x31)
            ':' -> Pair(shift, 0x33)
            '"' -> Pair(shift, 0x34)
            '~' -> Pair(shift, 0x35)
            '<' -> Pair(shift, 0x36)
            '>' -> Pair(shift, 0x37)
            '?' -> Pair(shift, 0x38)
            else -> null
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MaterialTheme.colorScheme.surface),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .weight(0.3f)
                .fillMaxHeight()
                .background(Color(0xFFD6E8F4), RoundedCornerShape(28.dp))
                .clickable { },
            contentAlignment = Alignment.Center
        ) {
            Text("Direct", color = Color(0xFF3B7CA6), fontSize = 16.sp)
        }
        
        OutlinedTextField(
            value = text,
            onValueChange = { newText -> 
                if (newText.length > text.length) {
                    val added = newText.substring(text.length)
                    added.forEach { c ->
                        charToHid(c)?.let { (mod, key) ->
                            bluetoothViewModel.sendKeyboardReportWithRelease(mod, key)
                        }
                    }
                } else if (newText.length < text.length) {
                    // Backspace
                    repeat(text.length - newText.length) {
                        bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2A) // Backspace
                    }
                }
                text = newText
            },
            placeholder = { Text("Enter...") },
            modifier = Modifier
                .weight(0.5f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(8.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.Gray,
                focusedBorderColor = Color.Gray
            )
        )
        
        IconButton(onClick = { text = "" }) {
            Icon(Icons.Default.Visibility, contentDescription = "Clear", tint = Color.Gray)
        }
    }
}
"""

code = re.sub(r'fun TextInputBar.*?\}\s*\}', new_text_input, code, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
