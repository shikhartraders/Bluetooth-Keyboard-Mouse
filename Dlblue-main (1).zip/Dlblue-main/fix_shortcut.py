import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

bad_str = """    val view = LocalView.current
    val currentPointerSpeed by rememberUpdatedState(pointerSpeed)
    val context = androidx.compose.ui.platform.LocalContext.current"""

good_str = """    val view = LocalView.current
    val context = androidx.compose.ui.platform.LocalContext.current"""

if bad_str in code:
    code = code.replace(bad_str, good_str)
    print("Fixed bad str")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
