import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Remove the incorrectly placed imports
code = code.replace("import androidx.compose.material3.TabRow\nimport androidx.compose.material3.Tab\n", "")

# Insert them after package com.example.ui
code = code.replace("package com.example.ui", "package com.example.ui\nimport androidx.compose.material3.TabRow\nimport androidx.compose.material3.Tab\n")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

