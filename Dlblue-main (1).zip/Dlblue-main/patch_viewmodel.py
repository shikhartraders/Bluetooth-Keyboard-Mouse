import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Add pointerSpeed to BluetoothViewModel
if "val pointerSpeed =" not in code:
    code = code.replace("val uiState: StateFlow<BluetoothUiState> = _uiState.asStateFlow()",
                        "val uiState: StateFlow<BluetoothUiState> = _uiState.asStateFlow()\n    private val prefs = application.getSharedPreferences(\"settings\", Context.MODE_PRIVATE)\n    val pointerSpeed = androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat(\"pointerSpeed\", 1.2f))\n    fun setPointerSpeed(speed: Float) {\n        pointerSpeed.floatValue = speed\n        prefs.edit().putFloat(\"pointerSpeed\", speed).apply()\n    }")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)
