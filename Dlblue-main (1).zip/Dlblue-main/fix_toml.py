import re

with open("gradle/libs.versions.toml", "r") as f:
    code = f.read()

code = code.replace("androidx-core-splashscreen = { group = \"androidx.core\", name = \"core-splashscreen\", version = \"1.0.1\" }", "")
code = code.replace("[plugins]", "androidx-core-splashscreen = { group = \"androidx.core\", name = \"core-splashscreen\", version = \"1.0.1\" }\n[plugins]")

with open("gradle/libs.versions.toml", "w") as f:
    f.write(code)
