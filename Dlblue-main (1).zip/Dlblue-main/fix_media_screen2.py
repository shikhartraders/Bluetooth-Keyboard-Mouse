import re

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()

# Add missing ShortcutButton private back for MultimediaScreen or use ManageShortcutButton
code = code.replace("ShortcutButton(", "ManageShortcutButton(")

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "w") as f:
    f.write(code)
