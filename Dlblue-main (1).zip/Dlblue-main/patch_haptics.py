import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# 1. We need to pass bluetoothViewModel to TrackpadArea, or just touchVibrations: Boolean
code = code.replace("onMiddleClick: () -> Unit = {},\n    pointerSpeed: Float = 1.2f",
                    "onMiddleClick: () -> Unit = {},\n    pointerSpeed: Float = 1.2f,\n    hapticEnabled: Boolean = true")

code = code.replace("            pointerSpeed = bluetoothViewModel.pointerSpeed.floatValue",
                    "            pointerSpeed = bluetoothViewModel.pointerSpeed.floatValue,\n            hapticEnabled = bluetoothViewModel.touchVibrations.value")

# Update privateShortcutButton to accept hapticEnabled
code = code.replace("fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {",
                    "fun privateShortcutButton(text: String, modifier: Modifier = Modifier, hapticEnabled: Boolean = true, onClick: () -> Unit = {}) {")

# Update Haptic Feedback logic in privateShortcutButton
code = code.replace("view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)",
                    "if (hapticEnabled) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)")

# Let's add haptic feedback to TrackpadArea
# Let's see where onClick, onRightClick, onMiddleClick are called in TrackpadArea
trackpad_haptics = """                        if (!moved && endTime - startTime < tapTimeout) {
                            if (isThreeFingers) {
                                if (hapticEnabled) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                                onMiddleClick()
                            } else if (isTwoFingers) {
                                if (hapticEnabled) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                                onRightClick()
                            } else {
                                lastTapTime = endTime
                                if (hapticEnabled) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                                onClick()
                            }
                        }"""
code = re.sub(r"                        if \(!moved && endTime - startTime < tapTimeout\) \{\s+if \(isThreeFingers\) \{\s+onMiddleClick\(\)\s+\} else if \(isTwoFingers\) \{\s+onRightClick\(\)\s+\} else \{\s+lastTapTime = endTime\s+onClick\(\)\s+\}\s+\}", trackpad_haptics, code)

# We also need to add hapticEnabled to the calls to privateShortcutButton in MouseKeyboardScreen.
# Rather than modifying 30 calls, let's just use CompositionLocal or pass it everywhere?
# Actually, wait. I can just pass it by adding it as a parameter, but in Kotlin I can just use a default argument!
# I already changed `hapticEnabled: Boolean = true`.
# Wait, I want it to read from `bluetoothViewModel.touchVibrations.value` by default, but `bluetoothViewModel` is not accessible inside `privateShortcutButton` unless I pass it.
# How about I change `privateShortcutButton` to accept `hapticEnabled: Boolean` and pass it in all calls?
# That's too many calls.
# Alternative: Define a global or CompositionLocal.
# Better Alternative: Update `privateShortcutButton` inside `MouseKeyboardScreen` to just use `LocalContext` to read SharedPreferences? Or just leave it for now, let's look at `privateShortcutButton` usage.
