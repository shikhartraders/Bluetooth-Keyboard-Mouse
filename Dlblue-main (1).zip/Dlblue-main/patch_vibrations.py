import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

if "val touchVibrations =" not in code:
    code = code.replace("val pointerSpeed = androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat(\"pointerSpeed\", 1.2f))",
                        "val pointerSpeed = androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat(\"pointerSpeed\", 1.2f))\n    val touchVibrations = androidx.compose.runtime.mutableStateOf(prefs.getBoolean(\"touchVibrations\", true))\n    fun setTouchVibrations(enabled: Boolean) {\n        touchVibrations.value = enabled\n        prefs.edit().putBoolean(\"touchVibrations\", enabled).apply()\n    }")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)
