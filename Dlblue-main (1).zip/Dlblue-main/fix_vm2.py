import re

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# Fix Dispatchers import if needed
if "import kotlinx.coroutines.Dispatchers" not in code:
    code = code.replace("import kotlinx.coroutines.launch", "import kotlinx.coroutines.launch\nimport kotlinx.coroutines.Dispatchers")

# Fix duplicate sendMediaReport
code = re.sub(
    r'(\s*fun sendMediaReport\(key: Int\) \{[\s\S]*?\})\s*fun sendMediaReport\(key: Int\) \{[\s\S]*?\}',
    r'\1',
    code,
    flags=re.MULTILINE
)

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)

