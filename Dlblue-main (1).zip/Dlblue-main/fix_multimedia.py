import re

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()

code = re.sub(
    r'onReport = \{ dx, dy, left, right, wheel ->\s*bluetoothViewModel.sendMouseReport\(dx, dy, left, right, wheel\)\s*\},',
    """onReport = { dx, dy, left, right, middle, wheel, hwheel ->
                bluetoothViewModel.sendMouseReport(dx, dy, left, right, middle, wheel, hwheel)
            },
            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            },""",
    code, flags=re.DOTALL
)

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "w") as f:
    f.write(code)
