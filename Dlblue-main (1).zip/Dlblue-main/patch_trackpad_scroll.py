import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# We need to get the size of the trackpad. 
# Box( modifier = modifier.fillMaxWidth().clip(...).background(trackpadColor).pointerInput(Unit) { ... } )
# Inside pointerInput(Unit) { awaitPointerEventScope { ... size.width ... } }
# `size` is available in awaitPointerEventScope! `size.width` is the width in pixels.

# Let's replace the 1-finger logic to check for edge scroll.
old_1_finger = """                            } else if (activePointers.size == 1) {
                                val currentX = activePointers[0].position.x
                                val currentY = activePointers[0].position.y
                                val dx = currentX - lastX
                                val dy = currentY - lastY
                                
                                if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                                
                                val dist = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                val accel = (dist / 10f).coerceIn(1.0f, 4.0f)
                                val baseSensitivity = pointerSpeed
                                
                                leftoverX += dx * baseSensitivity * accel
                                leftoverY += dy * baseSensitivity * accel
                                
                                val outX = leftoverX.toInt()
                                val outY = leftoverY.toInt()
                                
                                if (outX != 0 || outY != 0) {
                                    onReport(outX, outY, isDragging, false, false, 0, 0)
                                    leftoverX -= outX
                                    leftoverY -= outY
                                }
                                lastX = currentX
                                lastY = currentY
                            }"""

new_1_finger = """                            } else if (activePointers.size == 1) {
                                val currentX = activePointers[0].position.x
                                val currentY = activePointers[0].position.y
                                val dx = currentX - lastX
                                val dy = currentY - lastY
                                
                                if (kotlin.math.abs(dx) > 1f || kotlin.math.abs(dy) > 1f) moved = true
                                
                                // Edge scrolling (if started on the right 15% of the screen)
                                val edgeThreshold = size.width * 0.85f
                                if (activePointersInitial[0].position.x > edgeThreshold) {
                                    wheelLeftoverY += dy
                                    // Invert wheel if needed (Natural scrolling)
                                    val invertScroll = prefs.getBoolean("invertScroll", true)
                                    val wheelDir = if (invertScroll) 1 else -1
                                    val wheel = wheelDir * (wheelLeftoverY / 15f).toInt()
                                    
                                    if (wheel != 0) {
                                        onReport(0, 0, false, false, false, wheel, 0)
                                        wheelLeftoverY -= (wheel / wheelDir) * 15f
                                    }
                                } else {
                                    val dist = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                    val accel = (dist / 10f).coerceIn(1.0f, 4.0f)
                                    val baseSensitivity = pointerSpeed
                                    
                                    leftoverX += dx * baseSensitivity * accel
                                    leftoverY += dy * baseSensitivity * accel
                                    
                                    val outX = leftoverX.toInt()
                                    val outY = leftoverY.toInt()
                                    
                                    if (outX != 0 || outY != 0) {
                                        onReport(outX, outY, isDragging, false, false, 0, 0)
                                        leftoverX -= outX
                                        leftoverY -= outY
                                    }
                                }
                                lastX = currentX
                                lastY = currentY
                            }"""

if old_1_finger in code:
    code = code.replace(old_1_finger, new_1_finger)
    print("Replaced 1 finger")
else:
    print("Could not find 1 finger logic")

# Update 2-finger scroll to use invertScroll as well
old_2_finger = """                                wheelLeftoverY += dy
                                wheelLeftoverX += dx
                                
                                val wheel = -(wheelLeftoverY / 15f).toInt()
                                val hwheel = (wheelLeftoverX / 15f).toInt()
                                
                                if (wheel != 0 || hwheel != 0) {
                                    onReport(0, 0, false, false, false, wheel, hwheel)
                                    wheelLeftoverY += wheel * 15f
                                    wheelLeftoverX -= hwheel * 15f
                                }"""

new_2_finger = """                                wheelLeftoverY += dy
                                wheelLeftoverX += dx
                                
                                val invertScroll = prefs.getBoolean("invertScroll", true)
                                val wheelDir = if (invertScroll) 1 else -1
                                
                                val wheel = wheelDir * (wheelLeftoverY / 15f).toInt()
                                val hwheel = (wheelLeftoverX / 15f).toInt()
                                
                                if (wheel != 0 || hwheel != 0) {
                                    onReport(0, 0, false, false, false, wheel, hwheel)
                                    wheelLeftoverY -= (wheel / wheelDir) * 15f
                                    wheelLeftoverX -= hwheel * 15f
                                }"""

if old_2_finger in code:
    code = code.replace(old_2_finger, new_2_finger)
    print("Replaced 2 finger")
else:
    print("Could not find 2 finger logic")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
