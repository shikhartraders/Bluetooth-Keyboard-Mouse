import re

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "r") as f:
    code = f.read()

code = code.replace("bluetoothViewModel.sendKeyboardReport(\n                                                    0,\n                                                    keyCode.toByte()\n                                                )", "bluetoothViewModel.sendKeyboardReportWithRelease(0, keyCode.toByte())")
code = code.replace("                                                bluetoothViewModel.sendKeyboardReport(0, 0) // release", "")

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "w") as f:
    f.write(code)
