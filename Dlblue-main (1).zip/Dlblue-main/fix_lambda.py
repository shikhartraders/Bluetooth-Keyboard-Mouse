import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

code = code.replace("TextInputBar(bluetoothViewModel, activeModifiers, resetModifiers)", "TextInputBar(bluetoothViewModel, activeModifiers, ::resetModifiers)")
code = code.replace("0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, toggleModifier, resetModifiers)", "0 -> FullKeyboardPanel(bluetoothViewModel, activeModifiers, ::toggleModifier, ::resetModifiers)")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
