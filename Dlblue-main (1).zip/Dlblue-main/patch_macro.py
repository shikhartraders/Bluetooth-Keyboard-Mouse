import re

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "r") as f:
    content = f.read()

old_config = """        generationConfig = GenerationConfig(
            responseFormat = ResponseFormat(
                text = ResponseFormatText(
                    mimeType = "application/json",
                    schema = schemaJson
                )
            ),
            temperature = 0.2f
        ),"""

new_config = """        generationConfig = GenerationConfig(
            responseMimeType = "application/json",
            responseSchema = schemaJson,
            temperature = 0.2f
        ),"""

if old_config in content:
    content = content.replace(old_config, new_config)
    print("Replaced generation config!")
else:
    print("Could not find generation config to replace.")

with open("app/src/main/java/com/example/ui/AiMacroScreen.kt", "w") as f:
    f.write(content)
