import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

imports = """
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.input.pointer.pointerInteropFilter
import android.view.MotionEvent
"""

code = code.replace("import android.view.HapticFeedbackConstants", "import android.view.HapticFeedbackConstants\n" + imports.strip())

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
