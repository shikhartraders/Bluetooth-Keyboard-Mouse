import re

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

new_method = """    fun sendMediaReport(key: Int) {
        if (connectedDevice == null || hidDevice == null) return
        
        val report = byteArrayOf(key.toByte())
        
        try {
            hidDevice?.sendReport(connectedDevice, 3, report)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send media report: ${e.message}")
        }
    }"""

if "sendMediaReport" not in code:
    code = code.replace("    fun sendKeyboardReport", new_method + "\n\n    fun sendKeyboardReport")

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

new_vm_method = """    fun sendMediaReport(key: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            classicHidDevice?.sendMediaReport(key)
            kotlinx.coroutines.delay(20)
            classicHidDevice?.sendMediaReport(0) // Release
        }
    }"""

if "sendMediaReport" not in code:
    code = code.replace("    fun sendKeyboardReport", new_vm_method + "\n\n    fun sendKeyboardReport")

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)
