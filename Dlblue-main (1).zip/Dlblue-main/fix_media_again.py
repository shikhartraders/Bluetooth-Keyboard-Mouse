with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()
code = code.replace("ManageShortcutButton", "privateShortcutButton")
with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "w") as f:
    f.write(code)
