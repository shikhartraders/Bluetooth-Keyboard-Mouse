with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

old_button = """@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF558AB2))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}"""

old_button2 = """@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, hapticEnabled: Boolean = true, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF558AB2))
            .clickable { 
                if (hapticEnabled) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}"""

new_button = """@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = context.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
    val hapticEnabled = prefs.getBoolean("touchVibrations", true)
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF558AB2))
            .clickable { 
                if (hapticEnabled) {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                }
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}"""

if old_button in code:
    code = code.replace(old_button, new_button)
elif old_button2 in code:
    code = code.replace(old_button2, new_button)
else:
    print("Could not find button")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
