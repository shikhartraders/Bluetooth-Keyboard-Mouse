import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# 1. Add currentPointerSpeed
if "val currentPointerSpeed by rememberUpdatedState(pointerSpeed)" not in code:
    code = code.replace("val view = LocalView.current",
                        "val view = LocalView.current\n    val currentPointerSpeed by rememberUpdatedState(pointerSpeed)")

# 2. Use currentPointerSpeed in pointerInput
code = code.replace("val baseSensitivity = pointerSpeed", "val baseSensitivity = currentPointerSpeed")

# 3. If baseSensitivity is modified, also maybe increase it slightly or let the slider do it.
# Actually, the user says "THE POINTER SPEED IS TO SLOW", so maybe we should also increase the accel multiplier or just rely on the user changing it in settings, BUT let's also increase the slider range in settings.

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
