with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

import re

# Remove onTap from TrackpadArea because it causes accidental clicks (opening apps/writing)
# The user said "trackpad should work as a trackpad and the right side lines should work as a scrolling"
# and "for keyboard there is a special button" (meaning dedicated buttons for actions)
new_code = code.replace("""                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { offset ->
                            if (offset.x < scrollThreshold) {
                                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                                onClick()
                            }
                        }
                    )
                }""", """                // Tap-to-click removed to prevent accidental clicks. Dedicated buttons are below.""")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(new_code)
