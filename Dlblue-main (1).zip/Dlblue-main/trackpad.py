import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Let's make sure the icon name logic works
code = code.replace("Icons.Default.Mouse", "androidx.compose.material.icons.Icons.Default.Mouse")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

