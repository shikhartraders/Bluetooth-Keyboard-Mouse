import re

with open("app/src/main/java/com/example/ui/PcKeyboardScreen.kt", "r") as f:
    code = f.read()

code = code.replace("bluetoothViewModel.sendKeyboardReport(0, keyCode.toByte())\n                                bluetoothViewModel.sendKeyboardReport(0, 0)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, keyCode.toByte())")

with open("app/src/main/java/com/example/ui/PcKeyboardScreen.kt", "w") as f:
    f.write(code)
