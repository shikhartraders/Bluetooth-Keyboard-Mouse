import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Update FullKeyboardPanel row 1 modifiers and keys
old_row1 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Esc", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x29) }
            privateShortcutButton("Tab", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2B) }
            privateShortcutButton("Caps", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x39) }
            privateShortcutButton("Shift", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x02, 0) }
            privateShortcutButton("Ctrl", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x01, 0) }
            privateShortcutButton("Alt", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x04, 0) }
            privateShortcutButton("Win", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0x08, 0) }
        }"""

new_row1 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Esc", modifier = Modifier.weight(1f)) { sendKey(0x29) }
            privateShortcutButton("Tab", modifier = Modifier.weight(1f)) { sendKey(0x2B) }
            privateShortcutButton("Caps", modifier = Modifier.weight(1f)) { sendKey(0x39) }
            privateShortcutButton("Shift", modifier = Modifier.weight(1f), isActive = (activeModifiers and 0x02) != 0) { toggleModifier(0x02) }
            privateShortcutButton("Ctrl", modifier = Modifier.weight(1f), isActive = (activeModifiers and 0x01) != 0) { toggleModifier(0x01) }
            privateShortcutButton("Alt", modifier = Modifier.weight(1f), isActive = (activeModifiers and 0x04) != 0) { toggleModifier(0x04) }
            privateShortcutButton("Win", modifier = Modifier.weight(1f), isActive = (activeModifiers and 0x08) != 0) { toggleModifier(0x08) }
        }"""

if old_row1 in code:
    code = code.replace(old_row1, new_row1)
    print("Replaced row 1")
else:
    print("Could not find row 1")

old_row2 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("F1", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3A) }
            privateShortcutButton("F2", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3B) }
            privateShortcutButton("F3", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3C) }
            privateShortcutButton("F4", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3D) }
            privateShortcutButton("F5", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x3E) }
            privateShortcutButton("PrtSc", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x46) }
            privateShortcutButton("Ins", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x49) }
        }"""

new_row2 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("F1", modifier = Modifier.weight(1f)) { sendKey(0x3A) }
            privateShortcutButton("F2", modifier = Modifier.weight(1f)) { sendKey(0x3B) }
            privateShortcutButton("F3", modifier = Modifier.weight(1f)) { sendKey(0x3C) }
            privateShortcutButton("F4", modifier = Modifier.weight(1f)) { sendKey(0x3D) }
            privateShortcutButton("F5", modifier = Modifier.weight(1f)) { sendKey(0x3E) }
            privateShortcutButton("PrtSc", modifier = Modifier.weight(1f)) { sendKey(0x46) }
            privateShortcutButton("Ins", modifier = Modifier.weight(1f)) { sendKey(0x49) }
        }"""
        
if old_row2 in code:
    code = code.replace(old_row2, new_row2)
    print("Replaced row 2")

old_row3 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Home", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendMediaReport(0x0223) }
            privateShortcutButton("End", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4D) }
            privateShortcutButton("PgUp", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4B) }
            privateShortcutButton("PgDn", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4E) }
            privateShortcutButton("Del", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4C) }
            privateShortcutButton("Bksp", modifier = Modifier.weight(1.5f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2A) }
        }"""
        
new_row3 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Home", modifier = Modifier.weight(1f)) { sendKey(0x4A) }
            privateShortcutButton("End", modifier = Modifier.weight(1f)) { sendKey(0x4D) }
            privateShortcutButton("PgUp", modifier = Modifier.weight(1f)) { sendKey(0x4B) }
            privateShortcutButton("PgDn", modifier = Modifier.weight(1f)) { sendKey(0x4E) }
            privateShortcutButton("Del", modifier = Modifier.weight(1f)) { sendKey(0x4C) }
            privateShortcutButton("Bksp", modifier = Modifier.weight(1.5f)) { sendKey(0x2A) }
        }"""
        
if old_row3 in code:
    code = code.replace(old_row3, new_row3)
    print("Replaced row 3")

old_row4 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Space", modifier = Modifier.weight(2f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2C) }
            privateShortcutButton("Enter", modifier = Modifier.weight(1.5f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x28) }
            privateShortcutButton("↑", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x52) }
            privateShortcutButton("↓", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x51) }
            privateShortcutButton("←", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) }
            privateShortcutButton("→", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) }
        }"""
        
new_row4 = """        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            privateShortcutButton("Space", modifier = Modifier.weight(2f)) { sendKey(0x2C) }
            privateShortcutButton("Enter", modifier = Modifier.weight(1.5f)) { sendKey(0x28) }
            privateShortcutButton("↑", modifier = Modifier.weight(1f)) { sendKey(0x52) }
            privateShortcutButton("↓", modifier = Modifier.weight(1f)) { sendKey(0x51) }
            privateShortcutButton("←", modifier = Modifier.weight(1f)) { sendKey(0x50) }
            privateShortcutButton("→", modifier = Modifier.weight(1f)) { sendKey(0x4F) }
        }"""
        
if old_row4 in code:
    code = code.replace(old_row4, new_row4)
    print("Replaced row 4")
    
# We should also update TextInputBar to use the active modifiers when typing individual characters.
# Oh wait, TextInputBar is a separate composable. It might be better to just pass activeModifiers and a reset function, OR just leave text input as regular typing and only use the virtual buttons for shortcuts.

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
