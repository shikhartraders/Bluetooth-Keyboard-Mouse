import re

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "r") as f:
    code = f.read()

# Fix the duplicate catch block in ClassicHidDevice.kt
code = re.sub(r'\} catch \(e: Exception\) \{\s*Log.e\(TAG, "Failed to send mouse report: \$\{e.message\}"\)\s*\}\s*\} catch \(e: Exception\) \{\s*Log.e\(TAG, "Failed to send mouse report: \$\{e.message\}"\)\s*\}',
    r'} catch (e: Exception) {\n            Log.e(TAG, "Failed to send mouse report: ${e.message}")\n        }', code, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/ClassicHidDevice.kt", "w") as f:
    f.write(code)
