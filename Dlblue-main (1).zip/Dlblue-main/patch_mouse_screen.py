import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Replace baseSensitivity = 1.2f with bluetoothViewModel.pointerSpeed.floatValue
if "val baseSensitivity = 1.2f" in code:
    code = code.replace("val baseSensitivity = 1.2f", "val baseSensitivity = bluetoothViewModel.pointerSpeed.floatValue")

# Add TextInputBar at the bottom of MouseKeyboardScreen
if "if (showInputBar)" not in code:
    code = code.replace("privateShortcutButton(\"Menu\", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x65) } // Menu/App\n        }",
                        "privateShortcutButton(\"Menu\", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x65) } // Menu/App\n        }\n        if (showInputBar) {\n            Spacer(modifier = Modifier.height(16.dp))\n            TextInputBar(bluetoothViewModel)\n        }")

# Fix Home button
code = code.replace("privateShortcutButton(\"Home\", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4A) }",
                    "privateShortcutButton(\"Home\", modifier = Modifier.weight(1f)) { bluetoothViewModel.sendMediaReport(0x0223) }")


with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
