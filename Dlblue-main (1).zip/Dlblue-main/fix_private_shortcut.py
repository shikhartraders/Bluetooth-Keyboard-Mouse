import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

private_shortcut = """
@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF3B7CA6))
            .clickable { 
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            }
            .height(48.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
"""

code += "\n" + private_shortcut

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)

