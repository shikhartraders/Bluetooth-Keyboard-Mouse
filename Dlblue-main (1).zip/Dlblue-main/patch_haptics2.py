import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# I will modify privateShortcutButton to read from SharedPreferences directly!
new_button = """@Composable
fun privateShortcutButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val view = LocalView.current
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = context.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
    val hapticEnabled = prefs.getBoolean("touchVibrations", true)
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF558AB2))
            .clickable { 
                if (hapticEnabled) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}"""

# Need to replace existing privateShortcutButton
code = re.sub(r"@Composable\s+fun privateShortcutButton\(text: String, modifier: Modifier = Modifier, hapticEnabled: Boolean = true, onClick: \(\) -> Unit = \{\}\) \{.*?\n\}", new_button, code, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
