import re

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "r") as f:
    code = f.read()

# Replace SettingsSwitchRow definition
old_row = """@Composable
fun SettingsSwitchRow(title: String, initialChecked: Boolean) {
    var checked by remember { mutableStateOf(initialChecked) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = { checked = it })
    }
}"""

new_row = """@Composable
fun SettingsSwitchRow(title: String, initialChecked: Boolean = false, onCheckedChange: ((Boolean) -> Unit)? = null) {
    var localChecked by remember { mutableStateOf(initialChecked) }
    val isChecked = if (onCheckedChange != null) initialChecked else localChecked
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = isChecked, onCheckedChange = { 
            localChecked = it
            onCheckedChange?.invoke(it)
        })
    }
}"""

if old_row in code:
    code = code.replace(old_row, new_row)
else:
    print("Could not find old_row")

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "w") as f:
    f.write(code)
