import re

# Update AppNavigation to accept BluetoothViewModel
with open("app/src/main/java/com/example/ui/AppNavigation.kt", "r") as f:
    nav_code = f.read()

nav_code = nav_code.replace("fun AppNavigation() {", "fun AppNavigation(bluetoothViewModel: BluetoothViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {")
nav_code = nav_code.replace("val bluetoothViewModel: BluetoothViewModel = viewModel()", "") # Remove local creation
nav_code = nav_code.replace("import androidx.lifecycle.viewmodel.compose.viewModel", "import androidx.lifecycle.viewmodel.compose.viewModel")

with open("app/src/main/java/com/example/ui/AppNavigation.kt", "w") as f:
    f.write(nav_code)


# Update MainActivity
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    main_code = f.read()

# Add imports
main_code = main_code.replace("import android.os.Bundle", "import android.os.Bundle\nimport android.view.KeyEvent\nimport androidx.lifecycle.viewmodel.compose.viewModel\nimport com.example.ui.BluetoothViewModel")

# Add property and dispatchKeyEvent
main_code = main_code.replace("class MainActivity : ComponentActivity() {", """class MainActivity : ComponentActivity() {
    private var bluetoothViewModel: BluetoothViewModel? = null

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> {
                    bluetoothViewModel?.sendMediaReport(0x40) // Volume Up
                    return true
                }
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    bluetoothViewModel?.sendMediaReport(0x20) // Volume Down
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
""")

main_code = main_code.replace("AppNavigation()", """val vm: BluetoothViewModel = viewModel()
        bluetoothViewModel = vm
        AppNavigation(bluetoothViewModel = vm)""")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(main_code)
