import re
with open("app/src/main/java/com/example/ui/AppNavigation.kt", "r") as f:
    code = f.read()

code = code.replace("""Screen.InfoHelp.route -> "Info & Help\"""", """Screen.InfoHelp.route -> "Info & Help"\n                                        Screen.Terms.route -> "Terms & Conditions\"""")

with open("app/src/main/java/com/example/ui/AppNavigation.kt", "w") as f:
    f.write(code)
