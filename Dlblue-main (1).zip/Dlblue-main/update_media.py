import re

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()

# Replace keyboard report with media report for media controls
code = code.replace("""onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x51) }""", """onClick = { bluetoothViewModel.sendMediaReport(0x20) }""") # Volume Down (bit 5)
code = code.replace("""onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x10) }""", """onClick = { bluetoothViewModel.sendMediaReport(0x10) }""") # Mute (bit 4)
code = code.replace("""onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x52) }""", """onClick = { bluetoothViewModel.sendMediaReport(0x40) }""") # Volume Up (bit 6)

code = code.replace("""onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) }""", """onClick = { bluetoothViewModel.sendMediaReport(0x02) }""") # Prev Track (bit 1)
code = code.replace("""onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) }""", """onClick = { bluetoothViewModel.sendMediaReport(0x01) }""") # Next Track (bit 0)
code = code.replace("""onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50) }""", """onClick = { bluetoothViewModel.sendMediaReport(0x02) }""") # Fast rewind (mapping to prev)
code = code.replace("""onClick = { bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F) }""", """onClick = { bluetoothViewModel.sendMediaReport(0x01) }""") # Fast forward (mapping to next)

code = code.replace("""bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x2C)""", """bluetoothViewModel.sendMediaReport(0x08)""") # Play/Pause (bit 3)

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "w") as f:
    f.write(code)

