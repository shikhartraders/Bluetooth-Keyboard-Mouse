with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "r") as f:
    code = f.read()

# I will find the class declaration and find the matching closing brace, or just remove extra braces before enum class.
code = code.replace("}\n}\n}\n\nenum class BluetoothStatus", "}\n}\n\nenum class BluetoothStatus")
code = code.replace("}\n}\n\nenum class BluetoothStatus", "}\n\nenum class BluetoothStatus")
# Wait, let's just make sure there is exactly ONE closing brace before enum class.
import re
code = re.sub(r'(\}\s*)+enum class BluetoothStatus', r'}\n\nenum class BluetoothStatus', code)

with open("app/src/main/java/com/example/ui/BluetoothViewModel.kt", "w") as f:
    f.write(code)

