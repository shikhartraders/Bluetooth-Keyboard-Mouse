import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

old_call = """            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            },
            pointerSpeed = bluetoothViewModel.pointerSpeed.floatValue"""

new_call = """            onMiddleClick = {
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = true, 0, 0)
                bluetoothViewModel.sendMouseReport(0, 0, leftClick = false, rightClick = false, middleClick = false, 0, 0)
            },
            onThreeFingerSwipe = { dx, dy ->
                if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                    if (dx > 0) {
                        // Swipe Right: Switch Desktop Right (Win + Ctrl + Right Arrow)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x09, 0x4F)
                    } else {
                        // Swipe Left: Switch Desktop Left (Win + Ctrl + Left Arrow)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x09, 0x50)
                    }
                } else {
                    if (dy > 0) {
                        // Swipe Down: Show Desktop (Win + D)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x08, 0x07)
                    } else {
                        // Swipe Up: Task View (Win + Tab)
                        bluetoothViewModel.sendKeyboardReportWithRelease(0x08, 0x2B)
                    }
                }
            },
            pointerSpeed = bluetoothViewModel.pointerSpeed.floatValue"""

if old_call in code:
    code = code.replace(old_call, new_call)
    print("Replaced TrackpadArea call")
else:
    print("Could not find TrackpadArea call")

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
