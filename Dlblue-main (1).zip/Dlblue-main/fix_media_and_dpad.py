import re

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "r") as f:
    code = f.read()

# Fix Play/Pause
code = code.replace("""bluetoothViewModel.sendKeyboardReport(0, 0x2C) // Space
                bluetoothViewModel.sendKeyboardReport(0, 0)""", """bluetoothViewModel.sendMediaReport(0x08) // Play/Pause""")

# Fix D-Pad
# We will do targeted replacements by finding DPadArea and modifying inside it.
def fix_dpad(match):
    dpad_code = match.group(0)
    # Up
    dpad_code = dpad_code.replace("bluetoothViewModel.sendMediaReport(0x40)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x52)")
    # Down
    dpad_code = dpad_code.replace("bluetoothViewModel.sendMediaReport(0x20)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x51)")
    # Left
    dpad_code = dpad_code.replace("bluetoothViewModel.sendMediaReport(0x02)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x50)")
    # Right
    dpad_code = dpad_code.replace("bluetoothViewModel.sendMediaReport(0x01)", "bluetoothViewModel.sendKeyboardReportWithRelease(0, 0x4F)")
    return dpad_code

code = re.sub(r'@Composable\s*fun DPadArea.*?^}', fix_dpad, code, flags=re.MULTILINE | re.DOTALL)

with open("app/src/main/java/com/example/ui/MultimediaScreen.kt", "w") as f:
    f.write(code)

