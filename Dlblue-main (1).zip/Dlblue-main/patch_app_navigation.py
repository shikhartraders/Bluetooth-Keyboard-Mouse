import re

with open("app/src/main/java/com/example/ui/AppNavigation.kt", "r") as f:
    code = f.read()

old_nav = """                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu")
                            }
                        },"""

new_nav = """                        navigationIcon = {
                            if (currentRoute == Screen.MouseKeyboard.route) {
                                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                    Icon(Icons.Default.Menu, contentDescription = "Menu")
                                }
                            } else {
                                IconButton(onClick = { 
                                    navController.navigate(Screen.MouseKeyboard.route) {
                                        popUpTo(navController.graph.startDestinationId)
                                        launchSingleTop = true
                                    }
                                }) {
                                    Icon(Icons.Default.Home, contentDescription = "Home")
                                }
                            }
                        },"""

if old_nav in code:
    code = code.replace(old_nav, new_nav)
    print("Replaced navigationIcon")
else:
    print("Could not find navigationIcon")

with open("app/src/main/java/com/example/ui/AppNavigation.kt", "w") as f:
    f.write(code)
