import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Fix the broken newline literal
code = code.replace("'\\n' -> Pair(0.toByte(), 0x28)", "'\\n' -> Pair(0.toByte(), 0x28)")
code = code.replace("'\n' -> Pair(0.toByte(), 0x28)", "'\\n' -> Pair(0.toByte(), 0x28)")


with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
