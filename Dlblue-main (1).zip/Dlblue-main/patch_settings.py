import re

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "r") as f:
    code = f.read()

# Change signature
code = code.replace("fun SettingsBottomSheet(onDismiss: () -> Unit) {", "fun SettingsBottomSheet(bluetoothViewModel: BluetoothViewModel, onDismiss: () -> Unit) {")

# Pass to MouseSettingsTab
code = code.replace("1 -> MouseSettingsTab()", "1 -> MouseSettingsTab(bluetoothViewModel)")

code = code.replace("fun MouseSettingsTab() {", "fun MouseSettingsTab(bluetoothViewModel: BluetoothViewModel) {")

# Change slider call
code = code.replace("SettingsSliderRow(\"Pointer speed\")",
                    "SettingsSliderRow(\"Pointer speed\", value = bluetoothViewModel.pointerSpeed.floatValue, onValueChange = { bluetoothViewModel.setPointerSpeed(it) })")

# Update SettingsSliderRow definition
code = code.replace("fun SettingsSliderRow(title: String) {",
                    "fun SettingsSliderRow(title: String, value: Float = 0.5f, onValueChange: (Float) -> Unit = {}) {")

code = code.replace("var value by remember { mutableStateOf(0.5f) }\n    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {\n        Text(title, style = MaterialTheme.typography.bodyLarge)\n        Slider(value = value, onValueChange = { value = it })",
                    "Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {\n        Text(title, style = MaterialTheme.typography.bodyLarge)\n        Slider(value = value, onValueChange = onValueChange, valueRange = 0.1f..3.0f)") # Give it a range!

with open("app/src/main/java/com/example/ui/SettingsBottomSheet.kt", "w") as f:
    f.write(code)
