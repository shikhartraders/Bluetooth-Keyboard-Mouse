import re

with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "r") as f:
    code = f.read()

# Add context and prefs inside TrackpadArea
trackpad_header = """@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {},
    onMiddleClick: () -> Unit = {},
    pointerSpeed: Float = 1.2f,
    hapticEnabled: Boolean = true
) {"""

if trackpad_header in code:
    print("Found header")
else:
    print("Header not found")

trackpad_header_no_haptic = """@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {},
    onMiddleClick: () -> Unit = {},
    pointerSpeed: Float = 1.2f
) {"""

if trackpad_header_no_haptic in code:
    code = code.replace(trackpad_header_no_haptic, """@Composable
fun TrackpadArea(
    modifier: Modifier = Modifier,
    onReport: (dx: Int, dy: Int, leftClick: Boolean, rightClick: Boolean, middleClick: Boolean, wheel: Int, hwheel: Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onClick: () -> Unit = {},
    onRightClick: () -> Unit = {},
    onMiddleClick: () -> Unit = {},
    pointerSpeed: Float = 1.2f
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = context.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
    val hapticEnabled = prefs.getBoolean("touchVibrations", true)""")

old_tap = """                        } else if (!moved && endTime - startTime < tapTimeout) {
                            if (isThreeFingers) {
                                onMiddleClick()
                            } else if (isTwoFingers) {
                                onRightClick()
                            } else {
                                lastTapTime = endTime
                                onClick()
                            }
                        }"""

new_tap = """                        } else if (!moved && endTime - startTime < tapTimeout) {
                            if (hapticEnabled) {
                                view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_PRESS)
                            }
                            if (isThreeFingers) {
                                onMiddleClick()
                            } else if (isTwoFingers) {
                                onRightClick()
                            } else {
                                lastTapTime = endTime
                                onClick()
                            }
                        }"""
if old_tap in code:
    code = code.replace(old_tap, new_tap)
else:
    print("Old tap not found!")
    
with open("app/src/main/java/com/example/ui/MouseKeyboardScreen.kt", "w") as f:
    f.write(code)
